# 🚗 W-DRIVER — Plataforma Oficial de Mobilidade Urbana

> **"Quem escolhe preço corre riscos. Quem escolhe a W-DRIVER escolhe chegar bem!"**  
> Fundador: Diego Wallace de Lima Vasconcelos | CNPJ: 55.348.639/0001-54 | João Pessoa - PB

---

## 📋 Sobre o Projeto

Plataforma completa de mobilidade urbana com:
- **App do Passageiro**: Solicitação de corridas nas categorias W-BIKE, W-MOTO, W-CARRO e W-TÁXI com taxímetro.
- **Radar do Motorista**: Aceite de corridas, GPS em tempo real e visualização de rotas.
- **Central de Controle 24h**: Gestão de publicidade local, comunicados/alertas para a frota, tráfego e bloqueios de segurança por CPF/IMEI.
- **W-BANK**: Carteira digital com repasse transparente de 90% para os motoristas parceiros.
- **Validação Anti-Fraude**: Biometria facial, verificação gov.br e botão W-SOS com telemetria criptografada.

---

## 🚀 Como Rodar Localmente

### Pré-requisitos
- [Node.js](https://nodejs.org/) versão 18 ou superior instalado
- [Git](https://git-scm.com/) instalado

### Passo a passo:
```bash
# 1. Clone o repositório
git clone https://github.com/SEU-USUARIO/wdriver-mobilidade.git

# 2. Acesse a pasta do projeto
cd wdriver-mobilidade

# 3. Instale as dependências
npm install

# 4. Inicie o servidor de desenvolvimento
npm run dev
```

Abra seu navegador em: **`http://localhost:3000`** (ou a porta informada no terminal).

---

## 🌐 Como Subir para o seu GitHub

Se você já criou um repositório vazio no GitHub (ex: `wdriver-mobilidade`), execute os seguintes comandos no terminal da pasta do seu projeto:

```bash
# 1. Inicialize o repositório Git
git init

# 2. Adicione todos os arquivos
git add .

# 3. Crie o primeiro commit
git commit -m "feat: lancamento oficial W-DRIVER"

# 4. Renomeie a branch principal para main
git branch -M main

# 5. Conecte ao seu repositório no GitHub (substitua pelo link do seu repositório)
git remote add origin https://github.com/SEU-USUARIO/wdriver-mobilidade.git

# 6. Envie o código
git push -u origin main
```

---

## ⚡ Como Ativar o Site no GitHub Pages (Hospedagem Gratuita)

O projeto já inclui o arquivo `.github/workflows/deploy.yml` pronto:

1. No seu repositório no GitHub, vá em **Settings** (Configurações).
2. Na barra lateral esquerda, clique em **Pages**.
3. Em **Build and deployment > Source**, selecione **GitHub Actions**.
4. Faça qualquer novo push na branch `main` ou clique em **Actions > Deploy to GitHub Pages > Run workflow**.
5. O GitHub irá gerar o link público do seu aplicativo automaticamente (ex: `https://seu-usuario.github.io/wdriver-mobilidade/`).

---

## 📦 Gerar Versão de Produção Manualmente (Build)

Para gerar os arquivos estáticos prontos para qualquer servidor web (Apache, Nginx, Vercel, Netlify):

```bash
npm run build
```
Os arquivos gerados estarão na pasta `dist/`.
