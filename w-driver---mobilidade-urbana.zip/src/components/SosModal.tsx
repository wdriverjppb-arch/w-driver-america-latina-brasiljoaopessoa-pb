import React, { useState } from 'react';
import { X, AlertTriangle, ShieldAlert, PhoneCall, Radio, CheckCircle, Navigation, MapPin } from 'lucide-react';

interface SosModalProps {
  isOpen: boolean;
  onClose: () => void;
  userRole?: 'passageiro' | 'motorista';
}

export const SosModal: React.FC<SosModalProps> = ({ isOpen, onClose, userRole = 'passageiro' }) => {
  const [triggered, setTriggered] = useState(false);
  const [calling, setCalling] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleTriggerSOS = () => {
    setTriggered(true);
  };

  const handleCall = (service: string) => {
    setCalling(service);
    setTimeout(() => {
      setCalling(null);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-[#121212] border-2 border-red-500 rounded-3xl shadow-[0_0_30px_rgba(239,68,68,0.4)] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-red-950/80 px-5 py-4 border-b border-red-500/50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white animate-pulse">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-red-100 tracking-wide uppercase">
                🚨 Central de Emergência W-SOS
              </h3>
              <p className="text-[10px] text-red-300 font-medium">
                Protocolo Blindado 24h • João Pessoa - PB
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-red-300 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {!triggered ? (
            <>
              <div className="p-3.5 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
                  <MapPin className="w-4 h-4 text-red-400" />
                  <span>Geolocalização Criptografada Ativa:</span>
                </div>
                <div className="text-[11px] font-mono text-neutral-400 bg-neutral-950 p-2 rounded-lg border border-neutral-800">
                  Latitude: -7.1153 | Longitude: -34.8231 (Cabo Branco, JP)
                </div>
                <p className="text-[11px] text-neutral-400">
                  Ao acionar o W-SOS, o áudio e rota em tempo real serão transmitidos instantaneamente para a Central de Segurança W-DRIVER e órgãos competentes.
                </p>
              </div>

              <button
                onClick={handleTriggerSOS}
                className="w-full py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 active:scale-98 text-white font-black text-sm tracking-wider uppercase shadow-[0_0_20px_rgba(239,68,68,0.5)] transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <AlertTriangle className="w-5 h-5" />
                <span>Confirmar e Disparar Alerta SOS</span>
              </button>
            </>
          ) : (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 bg-red-950/60 border border-red-500/60 rounded-2xl text-center space-y-2">
                <div className="w-12 h-12 mx-auto rounded-full bg-red-600/30 border border-red-500 flex items-center justify-center text-red-400 animate-bounce">
                  <Radio className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-black text-white uppercase">
                  Alerta W-SOS Transmitido com Sucesso!
                </h4>
                <p className="text-xs text-red-200">
                  A Central de Segurança 24h já está gravando as coordenadas e monitorando o veículo em tempo real.
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                  Discagem de Emergência Rápida:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleCall('Polícia 190')}
                    className="p-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-left transition-colors flex items-center gap-2.5 cursor-pointer"
                  >
                    <PhoneCall className="w-4 h-4 text-blue-400" />
                    <div>
                      <div className="text-xs font-bold text-white">Polícia Militar</div>
                      <div className="text-[10px] text-neutral-400">Ligar 190</div>
                    </div>
                  </button>

                  <button
                    onClick={() => handleCall('SAMU 192')}
                    className="p-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-left transition-colors flex items-center gap-2.5 cursor-pointer"
                  >
                    <PhoneCall className="w-4 h-4 text-red-400" />
                    <div>
                      <div className="text-xs font-bold text-white">SAMU Resgate</div>
                      <div className="text-[10px] text-neutral-400">Ligar 192</div>
                    </div>
                  </button>
                </div>
              </div>

              {calling && (
                <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs text-center font-semibold">
                  📞 Simulando conexão com {calling}...
                </div>
              )}
            </div>
          )}

          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Fechar Painel W-SOS
          </button>
        </div>
      </div>
    </div>
  );
};
