import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  Crosshair, ShieldAlert, Navigation2, MapPin, ExternalLink, 
  Compass, MousePointerClick, RefreshCw, Check 
} from 'lucide-react';
import { getUniversalGoogleMapsRouteUrl, getWazeRouteUrl, calculateHaversineDistanceKm } from '../utils/geo';

interface InteractiveMapProps {
  origem: string;
  destino: string;
  distanciaKm: number;
  tempoMin: number;
  valorEstimado: number;
  origemCoords?: [number, number];
  destinoCoords?: [number, number];
  onUpdateCoords?: (type: 'origem' | 'destino', coords: [number, number], label?: string) => void;
  onUpdateDistance?: (km: number) => void;
  onSosClick?: () => void;
  className?: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  origem,
  destino,
  distanciaKm,
  tempoMin,
  valorEstimado,
  origemCoords = [-7.1238, -34.8647], // Padrão: Matriz Torre João Pessoa
  destinoCoords = [-7.1166, -34.8242], // Padrão: Orla de Tambaú
  onUpdateCoords,
  onUpdateDistance,
  onSosClick,
  className = '',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const origemMarkerRef = useRef<L.Marker | null>(null);
  const destinoMarkerRef = useRef<L.Marker | null>(null);
  const routeLineRef = useRef<L.Polyline | null>(null);

  const [currentOrigemCoords, setCurrentOrigemCoords] = useState<[number, number]>(origemCoords);
  const [currentDestinoCoords, setCurrentDestinoCoords] = useState<[number, number]>(destinoCoords);
  const [clickMode, setClickMode] = useState<'destino' | 'origem'>('destino');
  const [isLocating, setIsLocating] = useState(false);
  const [showSosModal, setShowSosModal] = useState(false);

  // Sincroniza se as props mudarem externamente
  useEffect(() => {
    if (origemCoords && (origemCoords[0] !== currentOrigemCoords[0] || origemCoords[1] !== currentOrigemCoords[1])) {
      setCurrentOrigemCoords(origemCoords);
    }
  }, [origemCoords]);

  useEffect(() => {
    if (destinoCoords && (destinoCoords[0] !== currentDestinoCoords[0] || destinoCoords[1] !== currentDestinoCoords[1])) {
      setCurrentDestinoCoords(destinoCoords);
    }
  }, [destinoCoords]);

  // Inicialização do Mapa Leaflet
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    // Cria a instância do mapa em João Pessoa
    const map = L.map(mapContainerRef.current, {
      center: currentOrigemCoords,
      zoom: 13,
      zoomControl: false,
    });

    // Adiciona controle de zoom discreto no canto inferior direito
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Tiles 100% livres e gratuitos do OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    // Ícones customizados HTML / CSS
    const createCustomIcon = (color: string, label: string, isOrigin: boolean) => {
      return L.divIcon({
        className: 'custom-leaflet-marker',
        html: `
          <div style="display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -100%); pointer-events: auto;">
            <div style="background: ${color}; color: #000; font-size: 10px; font-weight: 800; padding: 2px 6px; border-radius: 9999px; box-shadow: 0 2px 8px rgba(0,0,0,0.5); white-space: nowrap; border: 1px solid #000; margin-bottom: 2px;">
              ${label}
            </div>
            <div style="width: 24px; height: 24px; border-radius: 50%; background: #0a0a0a; border: 3px solid ${color}; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 12px ${color};">
              <div style="width: 8px; height: 8px; border-radius: 50%; background: ${color};"></div>
            </div>
            <div style="width: 2px; height: 6px; background: ${color};"></div>
          </div>
        `,
        iconSize: [24, 40],
        iconAnchor: [12, 40],
      });
    };

    // Marcador de Origem (Azul Claro)
    const markerOrigem = L.marker(currentOrigemCoords, {
      draggable: true,
      icon: createCustomIcon('#38bdf8', '📍 ORIGEM', true),
    }).addTo(map);

    markerOrigem.on('dragend', (e) => {
      const marker = e.target;
      const pos = marker.getLatLng();
      const newCoords: [number, number] = [pos.lat, pos.lng];
      setCurrentOrigemCoords(newCoords);
      onUpdateCoords?.('origem', newCoords, `GPS (${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)})`);
    });

    // Marcador de Destino (Verde Limão Oficial W-DRIVER)
    const markerDestino = L.marker(currentDestinoCoords, {
      draggable: true,
      icon: createCustomIcon('#a3e635', '🏁 DESTINO W-DRIVER', false),
    }).addTo(map);

    markerDestino.on('dragend', (e) => {
      const marker = e.target;
      const pos = marker.getLatLng();
      const newCoords: [number, number] = [pos.lat, pos.lng];
      setCurrentDestinoCoords(newCoords);
      onUpdateCoords?.('destino', newCoords, `Local selecionado (${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)})`);
    });

    // Linha de Rota conectando os dois pontos
    const routePolyline = L.polyline([currentOrigemCoords, currentDestinoCoords], {
      color: '#a3e635',
      weight: 5,
      opacity: 0.85,
      dashArray: '8, 8',
    }).addTo(map);

    origemMarkerRef.current = markerOrigem;
    destinoMarkerRef.current = markerDestino;
    routeLineRef.current = routePolyline;
    mapInstanceRef.current = map;

    // Enquadra a visão nos dois pontos
    try {
      const bounds = L.latLngBounds([currentOrigemCoords, currentDestinoCoords]);
      map.fitBounds(bounds, { padding: [50, 50] });
    } catch {
      // safe fallback
    }

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Atualiza mapa quando coordenadas mudam
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    if (origemMarkerRef.current) {
      origemMarkerRef.current.setLatLng(currentOrigemCoords);
    }
    if (destinoMarkerRef.current) {
      destinoMarkerRef.current.setLatLng(currentDestinoCoords);
    }
    if (routeLineRef.current) {
      routeLineRef.current.setLatLngs([currentOrigemCoords, currentDestinoCoords]);
    }

    // Recalcula distância com fórmula Haversine
    const newDistance = calculateHaversineDistanceKm(
      currentOrigemCoords[0],
      currentOrigemCoords[1],
      currentDestinoCoords[0],
      currentDestinoCoords[1]
    );
    onUpdateDistance?.(newDistance);

    // Ajusta o enquadramento
    try {
      const bounds = L.latLngBounds([currentOrigemCoords, currentDestinoCoords]);
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
    } catch {
      // safe
    }
  }, [currentOrigemCoords, currentDestinoCoords]);

  // Captura cliques no mapa para alterar origem ou destino
  useEffect(() => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current;

    const handleMapClick = (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;
      const coords: [number, number] = [lat, lng];

      if (clickMode === 'origem') {
        setCurrentOrigemCoords(coords);
        onUpdateCoords?.('origem', coords, `Local no mapa (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
        setClickMode('destino'); // alterna para destino para facilitar o fluxo
      } else {
        setCurrentDestinoCoords(coords);
        onUpdateCoords?.('destino', coords, `Destino no mapa (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
      }
    };

    map.on('click', handleMapClick);
    return () => {
      map.off('click', handleMapClick);
    };
  }, [clickMode, onUpdateCoords]);

  // Captura a geolocalização do aparelho nativo
  const handleGetCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocalização não suportada pelo seu navegador.');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsLocating(false);
        const { latitude, longitude } = position.coords;
        const coords: [number, number] = [latitude, longitude];
        setCurrentOrigemCoords(coords);
        onUpdateCoords?.('origem', coords, 'Meu GPS Atual (Localização Real)');
        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView(coords, 15);
        }
      },
      (error) => {
        setIsLocating(false);
        // Fallback elegante para João Pessoa
        alert('Não foi possível obter a localização exata do GPS. Mantendo ponto em João Pessoa.');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const googleMapsUrl = getUniversalGoogleMapsRouteUrl(origem, destino);
  const wazeUrl = getWazeRouteUrl(destino);

  return (
    <div className={`relative w-full h-80 sm:h-96 rounded-2xl overflow-hidden border border-neutral-800/80 bg-[#0a0a0a] shadow-inner select-none ${className}`}>
      {/* MAPA NATIVO LEAFLET / OPENSTREETMAP */}
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {/* FLOATING TOP CONTROLS */}
      <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between gap-2 z-[400] pointer-events-none">
        {/* ROTA ATUAL HINT */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/85 backdrop-blur-md border border-neutral-800 text-xs text-neutral-200 shadow-lg pointer-events-auto max-w-[65%] truncate">
          <Navigation2 className="w-3.5 h-3.5 text-[#a3e635] shrink-0 fill-[#a3e635]" />
          <span className="truncate font-semibold text-[11px]">
            {origem.split(',')[0]} ➔ {destino.split(',')[0]}
          </span>
        </div>

        {/* CLICK MODE TOGGLE & GPS BUTTONS */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* Botão de Localização GPS do Celular */}
          <button
            type="button"
            onClick={handleGetCurrentLocation}
            disabled={isLocating}
            className="p-2 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 border border-neutral-700 text-[#38bdf8] backdrop-blur-md shadow-lg transition-all cursor-pointer flex items-center gap-1 text-xs font-bold"
            title="Usar meu GPS atual como Origem"
          >
            {isLocating ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Crosshair className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">Meu GPS</span>
          </button>

          {/* Botão W-SOS */}
          <button
            type="button"
            onClick={() => {
              setShowSosModal(true);
              onSosClick?.();
            }}
            className="p-2 rounded-xl border border-red-500/50 bg-red-950/80 hover:bg-red-900 text-red-400 backdrop-blur-md shadow-lg transition-all flex items-center justify-center cursor-pointer"
            title="W-SOS Segurança 24h"
          >
            <ShieldAlert className="w-4 h-4 text-red-400" />
            <span className="text-[9px] font-black text-red-200 ml-1">SOS</span>
          </button>
        </div>
      </div>

      {/* MODO DE CLIQUE NO MAPA (ORIGEM / DESTINO) */}
      <div className="absolute top-12 left-2.5 z-[400] pointer-events-auto flex items-center gap-1 bg-neutral-950/90 border border-neutral-800 p-1 rounded-xl shadow-md text-[10px]">
        <span className="text-neutral-400 font-bold px-1.5">Clique no mapa:</span>
        <button
          type="button"
          onClick={() => setClickMode('origem')}
          className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
            clickMode === 'origem'
              ? 'bg-[#0284c7] text-white shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          📍 Origem
        </button>
        <button
          type="button"
          onClick={() => setClickMode('destino')}
          className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
            clickMode === 'destino'
              ? 'bg-[#a3e635] text-neutral-950 shadow-sm'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          🏁 Destino
        </button>
      </div>

      {/* FLOATING BOTTOM: ESTIMATIVA E BOTÕES DE NAVEGAÇÃO UNIVERSAL */}
      <div className="absolute bottom-2.5 left-2.5 right-2.5 z-[400] flex flex-col gap-1.5 pointer-events-auto">
        <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2 bg-neutral-950/95 backdrop-blur-md border border-neutral-800 rounded-xl shadow-2xl text-xs">
          <div className="flex items-center gap-2.5 text-neutral-200">
            <span className="flex items-center gap-1 text-[#a3e635] font-extrabold">
              <span className="inline-block w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
              {tempoMin} min
            </span>
            <span className="text-neutral-600">•</span>
            <span className="font-bold">{distanciaKm.toFixed(1)} km</span>
            <span className="text-neutral-600">•</span>
            <span className="text-neutral-400 text-[11px]">R$ {valorEstimado.toFixed(2).replace('.', ',')}</span>
          </div>

          {/* Links de Navegação Externa Completa (Origem + Destino) */}
          <div className="flex items-center gap-1.5 text-[11px]">
            <a
              href={googleMapsUrl}
              target="_blank"
              rel="noreferrer"
              className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[#38bdf8] font-bold flex items-center gap-1 transition-colors border border-sky-500/30"
              title="Abrir rota completa (Origem ➔ Destino) no Google Maps"
            >
              <ExternalLink className="w-3 h-3" />
              <span>Google Maps</span>
            </a>
            <a
              href={wazeUrl}
              target="_blank"
              rel="noreferrer"
              className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[#a3e635] font-bold flex items-center gap-1 transition-colors border border-lime-500/30"
              title="Abrir navegação no Waze"
            >
              <Compass className="w-3 h-3" />
              <span>Waze</span>
            </a>
          </div>
        </div>
      </div>

      {/* MODAL W-SOS */}
      {showSosModal && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 z-[500] animate-fadeIn">
          <div className="bg-neutral-900 border border-red-500/40 rounded-2xl p-5 max-w-xs text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-950/80 border border-red-500/60 flex items-center justify-center mx-auto mb-3">
              <ShieldAlert className="w-7 h-7 text-red-400 animate-pulse" />
            </div>
            <h4 className="text-white font-extrabold text-base mb-1">Central W-SOS 24h</h4>
            <p className="text-neutral-300 text-xs mb-4 leading-relaxed">
              Geolocalização GPS ativa com OpenStreetMap. Sua rota e coordenadas são transmitidas para a Central 24h e forças de segurança.
            </p>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  alert('Central W-SOS acionada com sucesso. Prioridade máxima em João Pessoa.');
                  setShowSosModal(false);
                }}
                className="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-lg cursor-pointer"
              >
                Disparar Alerta Prioritário
              </button>
              <button
                type="button"
                onClick={() => setShowSosModal(false)}
                className="w-full py-2 rounded-xl bg-neutral-800 text-neutral-400 hover:text-white text-xs font-semibold cursor-pointer"
              >
                Fechar / Voltar ao Mapa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
