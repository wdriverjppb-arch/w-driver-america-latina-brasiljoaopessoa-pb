import React, { useState } from 'react';
import { 
  Wallet, DollarSign, ArrowUpRight, ArrowDownLeft, ShieldCheck, 
  CheckCircle2, Clock, Landmark, QrCode, ArrowLeft, RefreshCw,
  FileText, AlertCircle, Sparkles
} from 'lucide-react';
import { RideData } from '../types';
import { PIX_CONFIG } from '../utils/pix';

interface WBankViewProps {
  rides: RideData[];
  onBackToHome: () => void;
  onGoToPassengerApp: () => void;
}

export const WBankView: React.FC<WBankViewProps> = ({
  rides,
  onBackToHome,
  onGoToPassengerApp,
}) => {
  const [pixKeyToWithdraw, setPixKeyToWithdraw] = useState('042.881.992-01');
  const [withdrawSuccess, setWithdrawSuccess] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Completed or in-progress rides
  const completedRides = rides.filter((r) => r.status === 'concluida');
  const inProgressRides = rides.filter((r) => ['paga_central', 'despachada', 'motorista_a_caminho', 'motorista_no_local', 'em_viagem'].includes(r.status));

  // 90% goes to the driver
  const saldoDisponivel = completedRides.reduce((acc, r) => acc + r.repasseMotorista, 0) + 185.40; // baseline demonstrativo
  const saldoEmCustodia = inProgressRides.reduce((acc, r) => acc + r.repasseMotorista, 0);
  const totalHistorico = saldoDisponivel + saldoEmCustodia;

  const handleRequestWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pixKeyToWithdraw.trim()) return;
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setWithdrawSuccess(`✅ TED/PIX de R$ ${saldoDisponivel.toFixed(2).replace('.', ',')} enviado com sucesso para a chave ${pixKeyToWithdraw}! Comprovante autenticado no Banco Central.`);
      setTimeout(() => setWithdrawSuccess(null), 6000);
    }, 1200);
  };

  return (
    <div className="w-full space-y-5 animate-fadeIn pb-6">
      {/* HEADER DO W-BANK */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToHome}
          className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Início</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
          <span className="text-[11px] font-black text-[#a3e635] uppercase tracking-wider">
            W-BANK PIX 24H CONECTADO
          </span>
        </div>
      </div>

      {/* CARD PRINCIPAL DE SALDO */}
      <div className="p-6 sm:p-7 rounded-3xl bg-gradient-to-br from-[#122209] via-neutral-900 to-neutral-950 border border-[#a3e635]/40 shadow-2xl relative overflow-hidden space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase text-neutral-400 tracking-wider block">
                Carteira Digital Integrada
              </span>
              <h1 className="text-lg font-black text-white">W-BANK FINANCEIRO</h1>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[11px] font-black uppercase">
            Repasse Líquido 90%
          </span>
        </div>

        {/* VALORES DE SALDO */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800">
            <span className="text-[10px] text-neutral-400 font-medium block">Saldo Disponível p/ Saque:</span>
            <div className="text-2xl font-black text-[#a3e635] mt-1">
              R$ {saldoDisponivel.toFixed(2).replace('.', ',')}
            </div>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1 font-semibold">
              <CheckCircle2 className="w-3 h-3" />
              Liberado instantâneo
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800">
            <span className="text-[10px] text-neutral-400 font-medium block">Em Custódia (Viagens Ativas):</span>
            <div className="text-2xl font-black text-amber-300 mt-1">
              R$ {saldoEmCustodia.toFixed(2).replace('.', ',')}
            </div>
            <span className="text-[10px] text-amber-400 flex items-center gap-1 mt-1 font-semibold">
              <Clock className="w-3 h-3" />
              Libera ao concluir
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800">
            <span className="text-[10px] text-neutral-400 font-medium block">Total Acumulado na Rede:</span>
            <div className="text-2xl font-black text-white mt-1">
              R$ {totalHistorico.toFixed(2).replace('.', ',')}
            </div>
            <span className="text-[10px] text-neutral-400 block mt-1">
              Sem taxa de anuidade ou adesão
            </span>
          </div>
        </div>

        {/* FEEDBACK DE SAQUE */}
        {withdrawSuccess && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-500/50 rounded-2xl text-xs font-bold text-emerald-300 flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{withdrawSuccess}</span>
          </div>
        )}

        {/* FORMULÁRIO RÁPIDO DE SAQUE PIX */}
        <form onSubmit={handleRequestWithdraw} className="p-4 rounded-2xl bg-neutral-950/90 border border-neutral-800/90 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-white flex items-center gap-1.5">
              <ArrowUpRight className="w-4 h-4 text-[#a3e635]" />
              Transferência PIX Instantânea para sua Conta
            </span>
            <span className="text-[10px] text-neutral-400 font-mono">Taxa: R$ 0,00</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={pixKeyToWithdraw}
              onChange={(e) => setPixKeyToWithdraw(e.target.value)}
              placeholder="Digite sua chave PIX (CPF, Telefone ou E-mail)..."
              className="flex-1 p-2.5 bg-neutral-900 border border-neutral-700 rounded-xl text-xs text-white outline-none focus:border-[#a3e635]"
              required
            />
            <button
              type="submit"
              disabled={isProcessing || saldoDisponivel <= 0}
              className="px-5 py-2.5 bg-[#a3e635] hover:bg-[#bef264] disabled:opacity-50 text-neutral-950 font-black text-xs rounded-xl transition-all cursor-pointer shadow-md flex items-center justify-center gap-1.5"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Processando...</span>
                </>
              ) : (
                <>
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Sacar R$ {saldoDisponivel.toFixed(2).replace('.', ',')}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* CONTA JURÍDICA E TRANSPARÊNCIA INSTITUCIONAL */}
      <div className="p-4 rounded-3xl bg-neutral-900 border border-[#a3e635]/30 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-black text-white uppercase tracking-wider">
            <Landmark className="w-4 h-4 text-[#a3e635]" />
            <span>Transparência & Conciliação PIX Central</span>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
            Certificada Bacen
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-neutral-950 p-3 rounded-2xl border border-neutral-800">
          <div>
            <span className="text-[10px] text-neutral-500 block">Favorecido Oficial:</span>
            <strong className="text-white text-[11px] block">{PIX_CONFIG.favorecido}</strong>
            <span className="text-[10px] text-neutral-400">W-DRIVER AMÉRICA LATINA BRASIL</span>
          </div>
          <div>
            <span className="text-[10px] text-neutral-500 block">Chave Pix Jurídica:</span>
            <strong className="text-[#a3e635] font-mono text-xs block">{PIX_CONFIG.cnpjFormatado}</strong>
            <span className="text-[10px] text-neutral-400">Banco Santander / Banco Inter</span>
          </div>
        </div>

        <p className="text-[11px] text-neutral-400 leading-relaxed">
          🔒 Cada pagamento de viagem no aplicativo é direcionado diretamente para a conta jurídica da empresa sob o CNPJ <strong>{PIX_CONFIG.cnpjFormatado}</strong>. A Central 24h confirma o crédito, retém apenas os 10% operacionais da plataforma e repassa automaticamente 90% líquidos ao motorista no W-BANK sem burocracia ou intermediários predatórios.
        </p>
      </div>

      {/* EXTRATO DE REPASSES E TRANSAÇÕES */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-[#a3e635]" />
            Extrato de Repasses e Viagens
          </h2>
          <span className="text-[11px] text-neutral-400">
            {rides.length} transações registradas
          </span>
        </div>

        <div className="space-y-2">
          {rides.map((ride) => {
            const isCompleted = ride.status === 'concluida';
            const isPending = ride.status === 'aguardando_pix';

            return (
              <div
                key={ride.id}
                className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                    isCompleted 
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                      : 'bg-neutral-800 text-neutral-300'
                  }`}>
                    {isCompleted ? <ArrowDownLeft className="w-5 h-5" /> : <Clock className="w-5 h-5 text-amber-400" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-white">{ride.categoria.name}</span>
                      <span className="text-[10px] text-neutral-500 font-mono">#{ride.id.slice(-6).toUpperCase()}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                        isCompleted ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {isCompleted ? 'Repassado 90%' : 'Em Custódia'}
                      </span>
                    </div>
                    <div className="text-[10px] text-neutral-400 truncate max-w-xs sm:max-w-md">
                      {ride.origemBairro} ➔ {ride.destinoBairro} • {ride.distanciaKm} km
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-neutral-800">
                  <div className="text-right">
                    <span className="text-[9px] text-neutral-500 block">Crédito Motorista (90%):</span>
                    <strong className="text-[#a3e635] text-xs font-black">
                      + R$ {ride.repasseMotorista.toFixed(2).replace('.', ',')}
                    </strong>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-neutral-500 block">Total da Corrida:</span>
                    <span className="text-neutral-300 text-xs font-semibold">
                      R$ {ride.valorTotal.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
