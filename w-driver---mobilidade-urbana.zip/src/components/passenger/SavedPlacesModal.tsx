import React, { useState } from 'react';
import { Home, Briefcase, Star, Plus, Trash2, Edit2, X, Check, MapPin } from 'lucide-react';
import { SavedPlace } from '../../types';

interface SavedPlacesModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedPlaces: SavedPlace[];
  onSelectPlace: (address: string) => void;
  onSavePlace: (place: SavedPlace) => void;
  onDeletePlace: (id: string) => void;
}

export const SavedPlacesModal: React.FC<SavedPlacesModalProps> = ({
  isOpen,
  onClose,
  savedPlaces,
  onSelectPlace,
  onSavePlace,
  onDeletePlace,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newType, setNewType] = useState<'casa' | 'trabalho' | 'favorito'>('favorito');
  const [newTitle, setNewTitle] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  if (!isOpen) return null;

  const handleStartEdit = (place: SavedPlace) => {
    setEditingId(place.id);
    setNewType(place.type);
    setNewTitle(place.title);
    setNewAddress(place.address);
    setIsAdding(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddress.trim()) {
      alert('Informe o endereço do local.');
      return;
    }

    const id = editingId || `place-${Date.now()}`;
    const defaultTitles = {
      casa: 'Casa',
      trabalho: 'Trabalho',
      favorito: newTitle.trim() || 'Lugar Favorito',
    };

    onSavePlace({
      id,
      type: newType,
      title: newTitle.trim() || defaultTitles[newType],
      address: newAddress.trim(),
    });

    setIsAdding(false);
    setEditingId(null);
    setNewTitle('');
    setNewAddress('');
  };

  const getIcon = (type: 'casa' | 'trabalho' | 'favorito') => {
    switch (type) {
      case 'casa':
        return <Home className="w-4 h-4 text-[#a3e635]" />;
      case 'trabalho':
        return <Briefcase className="w-4 h-4 text-sky-400" />;
      default:
        return <Star className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center text-[#a3e635]">
              <Star className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white">Lugares Salvos</h2>
              <p className="text-[11px] text-neutral-400">
                Seus endereços rápidos em João Pessoa
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl bg-neutral-900 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* List of Places */}
        <div className="space-y-2">
          {savedPlaces.map((place) => (
            <div
              key={place.id}
              className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-2 hover:border-neutral-700 transition-colors"
            >
              <div
                onClick={() => {
                  onSelectPlace(place.address);
                  onClose();
                }}
                className="flex items-center gap-3 flex-1 cursor-pointer"
              >
                <div className="p-2 rounded-xl bg-neutral-950 border border-neutral-800 shrink-0">
                  {getIcon(place.type)}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>{place.title}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 uppercase font-semibold">
                      {place.type}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-400 truncate">
                    {place.address}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => handleStartEdit(place)}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white"
                  title="Editar endereço"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onDeletePlace(place.id)}
                  className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400"
                  title="Excluir"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add or Edit Form */}
        {isAdding ? (
          <form onSubmit={handleSave} className="p-3.5 rounded-2xl bg-neutral-900 border border-[#a3e635]/40 space-y-3">
            <div className="text-xs font-bold text-white">
              {editingId ? 'Editar Local' : 'Adicionar Novo Local'}
            </div>

            <div className="flex gap-2">
              {(['casa', 'trabalho', 'favorito'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setNewType(t)}
                  className={`flex-1 py-1.5 rounded-xl text-[10px] font-bold uppercase transition-colors ${
                    newType === t
                      ? 'bg-[#a3e635] text-neutral-950 font-black'
                      : 'bg-neutral-950 text-neutral-400 hover:text-white border border-neutral-800'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="Nome do local (ex: Casa da Mãe, Academia)"
              className="w-full py-2 px-3 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-white placeholder:text-neutral-600 outline-none"
            />

            <input
              type="text"
              value={newAddress}
              onChange={(e) => setNewAddress(e.target.value)}
              placeholder="Endereço completo (Rua, Número, Bairro)"
              className="w-full py-2 px-3 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-white placeholder:text-neutral-600 outline-none"
            />

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setEditingId(null);
                }}
                className="flex-1 py-2 rounded-xl bg-neutral-800 text-neutral-300 font-bold text-xs"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-[#a3e635] text-neutral-950 font-black text-xs"
              >
                Salvar Local
              </button>
            </div>
          </form>
        ) : (
          <button
            onClick={() => {
              setIsAdding(true);
              setEditingId(null);
              setNewTitle('');
              setNewAddress('');
            }}
            className="w-full py-3 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 border-dashed text-[#a3e635] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Adicionar Novo Endereço</span>
          </button>
        )}
      </div>
    </div>
  );
};
