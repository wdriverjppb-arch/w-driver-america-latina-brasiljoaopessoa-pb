import React, { useState } from 'react';
import { Crown, X, Check, Calendar, Users, MapPin, Shield, Phone, FileText, CheckCircle2, Building2, Bike, Car, Truck } from 'lucide-react';
import { LuxuryContract } from '../../types';

interface LuxuryContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitContract: (contract: LuxuryContract) => void;
  initialCategory?: string;
}

export const ALL_CONTRACT_CATEGORIES = [
  { id: 'W-BIKE', label: 'W-BIKE', desc: 'Mobilidade ecológica & entregas rápidas de pequenos pacotes sob contrato', icon: Bike },
  { id: 'W-MOTO COMUM', label: 'W-MOTO COMUM', desc: 'Deslocamento ágil e serviços de entrega contínua com motoboy dedicado', icon: Bike },
  { id: 'W-MOTO PRIME', label: 'W-MOTO PRIME', desc: 'Motos de média/alta cilindrada com equipamentos e baú reforçado', icon: Bike },
  { id: 'W-CARRO COMUM', label: 'W-CARRO COMUM', desc: 'Contratos corporativos e locação com motorista para deslocamento de equipe', icon: Car },
  { id: 'W-CARRO PRIME', label: 'W-CARRO PRIME', desc: 'Sedans e hatches novos com alto padrão de acabamento e climatização', icon: Car },
  { id: 'W-EXECUTIVO', label: 'W-EXECUTIVO', desc: 'Sedans executivos pretos para transporte de diretoria, clientes VIP e aeroporto', icon: Car },
  { id: 'W-TÁXI', label: 'W-TÁXI', desc: 'Frota de táxis credenciados com autorização para faixas exclusivas e eventos', icon: Car },
  { id: 'W-LUXO', label: 'W-LUXO', desc: 'SUVs de 7 a 8 lugares (SW4, Trailblazer) blindadas e motoristas com terno', icon: Crown },
  { id: 'W-DELIVERY', label: 'W-DELIVERY (Empresas)', desc: 'Logística corporativa, entregas de e-commerce, malotes e faturamento quinzenal para empresas', icon: Building2 },
];

export const LuxuryContractModal: React.FC<LuxuryContractModalProps> = ({
  isOpen,
  onClose,
  onSubmitContract,
  initialCategory = 'W-LUXO',
}) => {
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [nome, setNome] = useState('');
  const [empresa, setEmpresa] = useState('');
  const [cnpjCpf, setCnpjCpf] = useState('');
  const [telefone, setTelefone] = useState('');
  const [tipoViagem, setTipoViagem] = useState('corporativo_mensal');
  const [veiculo, setVeiculo] = useState('Veículo Padrão da Frota W-DRIVER');
  const [diarias, setDiarias] = useState(1);
  const [observacoes, setObservacoes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const serviceTypes = [
    { id: 'corporativo_mensal', title: 'Contrato Corporativo & Faturamento Faturado', desc: 'Ideal para empresas, logística W-DELIVERY e transporte de colaboradores' },
    { id: 'passeio_litoral_sul', title: 'Passeio Turístico - Litoral Sul', desc: 'Coqueirinho, Tambaba, Tabatinga, Praia do Amor e Carapibus' },
    { id: 'passeio_litoral_norte', title: 'Passeio Turístico - Litoral Norte', desc: 'Praia Fluvial do Jacaré (Bolero de Ravel), Areia Vermelha e Cabedelo' },
    { id: 'executivo_aeroporto', title: 'Translados & Reuniões de Negócios (Aeroporto JPA/REC)', desc: 'Atendimento pontual com motorista bilíngue e recepção personalizada' },
    { id: 'viagem_estadual', title: 'Viagens Estaduais (Paraíba)', desc: 'Campina Grande, Bananeiras, Areia, Patos e Sertão Paraibano' },
    { id: 'viagem_interestadual', title: 'Viagens Interestaduais (Nordeste)', desc: 'Recife/Porto de Galinhas (PE), Natal/Pipa (RN), Fortaleza (CE)' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome.trim() || !telefone.trim()) {
      alert('Por favor, informe seu nome e telefone para contato.');
      return;
    }

    let baseDailyRate = 250;
    if (selectedCategory === 'W-BIKE') baseDailyRate = 80;
    else if (selectedCategory === 'W-MOTO COMUM') baseDailyRate = 120;
    else if (selectedCategory === 'W-MOTO PRIME') baseDailyRate = 160;
    else if (selectedCategory === 'W-CARRO COMUM') baseDailyRate = 220;
    else if (selectedCategory === 'W-CARRO PRIME') baseDailyRate = 320;
    else if (selectedCategory === 'W-EXECUTIVO') baseDailyRate = 480;
    else if (selectedCategory === 'W-TÁXI') baseDailyRate = 300;
    else if (selectedCategory === 'W-LUXO') baseDailyRate = 750;
    else if (selectedCategory === 'W-DELIVERY') baseDailyRate = 280;

    const estimatedBase = diarias * baseDailyRate;

    const contract: LuxuryContract = {
      id: `ctr-${Date.now()}`,
      clienteNome: empresa.trim() ? `${nome.trim()} (${empresa.trim()})` : nome.trim(),
      telefone: telefone.trim(),
      veiculo: `${selectedCategory} • ${veiculo}`,
      tipoViagem: `${selectedCategory} - ${tipoViagem}`,
      dataInicio: new Date().toLocaleDateString('pt-BR'),
      diarias,
      valorEstimado: estimatedBase,
      status: 'solicitado',
      observacoes: `CNPJ/CPF: ${cnpjCpf || 'Não informado'} | Obs: ${observacoes.trim()}`,
    };

    onSubmitContract(contract);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl bg-neutral-950 border border-[#a3e635]/40 rounded-3xl p-5 sm:p-6 shadow-[0_0_40px_rgba(163,230,53,0.15)] max-h-[92vh] overflow-y-auto space-y-4">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#142608] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white flex items-center gap-1.5 uppercase tracking-wide">
                <span>Contratos Oficiais W-DRIVER</span>
                <span className="px-2 py-0.5 rounded-full bg-[#a3e635]/20 text-[#a3e635] text-[10px] font-bold">
                  8 Categorias + W-DELIVERY
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Atendimento personalizado para pessoas físicas e empresas com emissão de nota e contrato
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-4 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-[#142608] border border-[#a3e635]/60 text-[#a3e635] flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(163,230,53,0.3)]">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-white">Solicitação de Contrato Registrada!</h3>
            <p className="text-xs text-neutral-300 max-w-md mx-auto leading-relaxed">
              Obrigado, <strong className="text-white">{nome}</strong>. A Central Administrativa da W-DRIVER recebeu seu pedido para a categoria <strong className="text-[#a3e635]">{selectedCategory}</strong> e entrará em contato via WhatsApp no número <strong className="text-[#a3e635]">{telefone}</strong> para envio da minuta do contrato.
            </p>
            <div className="p-3.5 bg-neutral-900 border border-neutral-800 rounded-2xl text-xs text-neutral-300 text-left space-y-1.5">
              <div>• Categoria: <span className="text-[#a3e635] font-bold">{selectedCategory}</span></div>
              <div>• Duração: <span className="text-white font-semibold">{diarias} diária(s) / período</span></div>
              {empresa && <div>• Empresa: <span className="text-white font-semibold">{empresa}</span></div>}
              <div>• Seguro total de frota e rastreamento W-DRIVER 24h incluso</div>
            </div>
            <button
              onClick={onClose}
              className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer shadow-lg"
            >
              Concluir e Fechar
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* 1. SELEÇÃO DA CATEGORIA (TODAS AS 8 CATEGORIAS + W-DELIVERY) */}
            <div>
              <label className="text-[11px] font-black uppercase text-neutral-300 block mb-2 tracking-wider flex items-center justify-between">
                <span>1. Escolha a Categoria do Contrato (8 Categorias + Empresas):</span>
                <span className="text-[#a3e635] font-bold text-[10px]">{selectedCategory}</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {ALL_CONTRACT_CATEGORIES.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-[#142608] border-[#a3e635] text-white shadow-[0_0_12px_rgba(163,230,53,0.25)]'
                          : 'bg-neutral-900/80 border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-[#a3e635]' : 'text-neutral-500'}`} />
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#a3e635]" />}
                      </div>
                      <div className="font-bold text-xs leading-tight">{cat.label}</div>
                      <div className="text-[9px] text-neutral-500 leading-tight mt-1 line-clamp-2">{cat.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Informação de Garantia */}
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-300 text-[11px] leading-relaxed flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-[#a3e635] shrink-0 mt-0.5" />
              <span>
                <strong>Garantia Jurídica W-DRIVER:</strong> Contratos com motoristas qualificados, veículos inspecionados, cobertura securitária integral e emissão de nota fiscal para empresas e pessoas físicas.
              </span>
            </div>

            {/* Dados de Contato e Empresa */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                  Seu Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Roberto Albuquerque"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-[#a3e635] outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                  WhatsApp com DDD *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="(83) 98888-0000"
                  value={telefone}
                  onChange={(e) => setTelefone(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-[#a3e635] outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                  Empresa / Razão Social (Opcional para W-DELIVERY)
                </label>
                <input
                  type="text"
                  placeholder="Ex: Farmácia ou Loja Ltda"
                  value={empresa}
                  onChange={(e) => setEmpresa(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-[#a3e635] outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                  CPF ou CNPJ
                </label>
                <input
                  type="text"
                  placeholder="00.000.000/0001-00"
                  value={cnpjCpf}
                  onChange={(e) => setCnpjCpf(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-[#a3e635] outline-none"
                />
              </div>
            </div>

            {/* Modalidade de Atendimento */}
            <div>
              <label className="text-[11px] font-bold text-neutral-300 block mb-1.5">
                Modalidade de Atendimento:
              </label>
              <div className="space-y-1.5">
                {serviceTypes.map((st) => (
                  <label
                    key={st.id}
                    className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                      tipoViagem === st.id
                        ? 'bg-[#142608] border-[#a3e635] text-white'
                        : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="radio"
                        name="tipoViagem"
                        checked={tipoViagem === st.id}
                        onChange={() => setTipoViagem(st.id)}
                        className="accent-[#a3e635]"
                      />
                      <div>
                        <div className="font-bold text-white text-xs">{st.title}</div>
                        <div className="text-[10px] text-neutral-400">{st.desc}</div>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Diárias e Observações */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                  Quantidade de Diárias:
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setDiarias((prev) => Math.max(1, prev - 1))}
                    className="w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 text-white font-bold flex items-center justify-center hover:bg-neutral-800 cursor-pointer"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min={1}
                    value={diarias}
                    onChange={(e) => setDiarias(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-16 p-2 text-center rounded-xl bg-neutral-900 border border-neutral-800 text-white font-bold outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setDiarias((prev) => prev + 1)}
                    className="w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 text-white font-bold flex items-center justify-center hover:bg-neutral-800 cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                  Veículo ou Requisitos Específicos
                </label>
                <input
                  type="text"
                  placeholder="Ex: Sedan preto, SUV 7 lugares, Baú refrigerado..."
                  value={veiculo}
                  onChange={(e) => setVeiculo(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-[#a3e635] outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-neutral-300 block mb-1">
                Observações ou Rotas Programadas:
              </label>
              <textarea
                rows={2}
                placeholder="Informe horários de embarque, paradas programadas ou necessidade de faturamento quinzenal..."
                value={observacoes}
                onChange={(e) => setObservacoes(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-100 placeholder-neutral-600 focus:border-[#a3e635] outline-none resize-none text-xs"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(163,230,53,0.3)] cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Solicitar Contrato Oficial para {selectedCategory}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
