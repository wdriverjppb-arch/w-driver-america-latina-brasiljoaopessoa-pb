import React from 'react';
import { 
  X, MapPin, Clock, Wallet, RotateCcw, Star, Share2, 
  HelpCircle, Gift, Tag, Crown, Shield, FileText, BookOpen, 
  User, ChevronRight, PhoneCall, ExternalLink
} from 'lucide-react';
import { WDriverLogo } from '../WDriverLogo';

interface PassengerMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSavedPlaces: () => void;
  onOpenHistory: () => void;
  onOpenCredits: () => void;
  onOpenRefund: () => void;
  onOpenRatings: () => void;
  onShareRide: () => void;
  onOpenLostItems: () => void;
  onOpenReferral: () => void;
  onOpenPromotions: () => void;
  onOpenContracts: () => void;
  onOpenHelp: () => void;
  onOpenTerms: () => void;
  onOpenBio: () => void;
  userName?: string;
  userCredits?: number;
}

export const PassengerMenuDrawer: React.FC<PassengerMenuDrawerProps> = ({
  isOpen,
  onClose,
  onOpenSavedPlaces,
  onOpenHistory,
  onOpenCredits,
  onOpenRefund,
  onOpenRatings,
  onShareRide,
  onOpenLostItems,
  onOpenReferral,
  onOpenPromotions,
  onOpenContracts,
  onOpenHelp,
  onOpenTerms,
  onOpenBio,
  userName = 'Passageiro W-DRIVER',
  userCredits = 15.0,
}) => {
  if (!isOpen) return null;

  const menuItems = [
    { label: 'Lugares salvos', icon: MapPin, action: onOpenSavedPlaces, badge: '3 salvos' },
    { label: 'Histórico de viagens', icon: Clock, action: onOpenHistory },
    { label: 'Meus Créditos', icon: Wallet, action: onOpenCredits, badge: `R$ ${userCredits.toFixed(2).replace('.', ',')}`, highlight: true },
    { label: 'Solicitar Reembolso', icon: RotateCcw, action: onOpenRefund },
    { label: 'Minhas Avaliações', icon: Star, action: onOpenRatings },
    { label: 'Compartilhar Viagem', icon: Share2, action: onShareRide },
    { label: 'Objetos Esquecidos', icon: HelpCircle, action: onOpenLostItems },
    { label: 'Indique e Ganhe', icon: Gift, action: onOpenReferral, badge: 'R$ 5,00/indicação' },
    { label: 'Promoções & Cupons', icon: Tag, action: onOpenPromotions, badge: 'Novo' },
    { label: 'Contratos W-LUXO', icon: Crown, action: onOpenContracts, badge: 'VIP' },
    { label: 'Central de Ajuda 24h', icon: PhoneCall, action: onOpenHelp },
    { label: 'Biografia Oficial do Fundador', icon: BookOpen, action: onOpenBio },
    { label: 'Termos e Privacidade', icon: FileText, action: onOpenTerms },
  ];

  return (
    <div className="fixed inset-0 z-50 flex animate-fadeIn">
      {/* Backdrop */}
      <div 
        onClick={onClose} 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer Body */}
      <div className="relative w-4/5 max-w-xs bg-[#0b0f0b] text-neutral-100 h-full border-r border-neutral-800 shadow-2xl flex flex-col z-10 overflow-hidden">
        {/* Header Profile */}
        <div className="p-5 border-b border-neutral-800 bg-[#121912] relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-xl bg-neutral-900 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-xl font-black text-[#a3e635]">
              <User className="w-6 h-6 text-[#a3e635]" />
            </div>
            <div>
              <div className="font-extrabold text-white text-sm">{userName}</div>
              <div className="text-[11px] text-[#a3e635] font-semibold flex items-center gap-1">
                <Shield className="w-3 h-3 text-[#a3e635]" />
                <span>Conta Verificada</span>
              </div>
            </div>
          </div>

          <div className="mt-3.5 p-2.5 rounded-xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between">
            <div className="text-[11px] text-neutral-400">Saldo de Créditos:</div>
            <div className="text-xs font-black text-[#a3e635]">
              R$ {userCredits.toFixed(2).replace('.', ',')}
            </div>
          </div>
        </div>

        {/* Menu Items List */}
        <div className="flex-1 overflow-y-auto py-2 px-3 space-y-1">
          {menuItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <button
                key={idx}
                onClick={() => {
                  onClose();
                  item.action();
                }}
                className="w-full p-2.5 rounded-xl text-left flex items-center justify-between hover:bg-neutral-900 transition-colors group cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${item.highlight ? 'text-[#a3e635]' : 'text-neutral-400 group-hover:text-white'}`} />
                  <span className="text-xs font-semibold text-neutral-200 group-hover:text-white">
                    {item.label}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge && (
                    <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${
                      item.highlight 
                        ? 'bg-[#a3e635]/20 text-[#a3e635] border border-[#a3e635]/30'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                  <ChevronRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-neutral-400" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-[#080c08] flex flex-col items-center gap-1 text-center">
          <WDriverLogo size="sm" />
          <div className="text-[10px] text-neutral-500 font-medium">
            W-DRIVER João Pessoa - PB • v2.6.0 Blindado
          </div>
        </div>
      </div>
    </div>
  );
};
