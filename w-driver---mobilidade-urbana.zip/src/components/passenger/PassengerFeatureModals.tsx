import React, { useState } from 'react';
import { 
  X, Check, Wallet, RotateCcw, Star, Share2, HelpCircle, 
  Gift, Tag, PhoneCall, Copy, CheckCircle2, Shield, AlertTriangle
} from 'lucide-react';
import { LostItemReport, RefundRequest, RideData } from '../../types';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// 1. MEUS CRÉDITOS
export const CreditsModal: React.FC<ModalProps & { balance: number; onAddCredits: (val: number) => void }> = ({
  isOpen,
  onClose,
  balance,
  onAddCredits,
}) => {
  const [amount, setAmount] = useState(20);
  const [successMsg, setSuccessMsg] = useState(false);

  if (!isOpen) return null;

  const handleAdd = () => {
    onAddCredits(amount);
    setSuccessMsg(true);
    setTimeout(() => {
      setSuccessMsg(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm bg-neutral-950 border border-[#a3e635]/40 rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-[#a3e635]" />
            <h3 className="text-sm font-black text-white">Meus Créditos W-DRIVER</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-4 rounded-2xl bg-neutral-900 text-center space-y-1">
          <span className="text-xs text-neutral-400">Saldo Disponível:</span>
          <div className="text-3xl font-black text-[#a3e635]">
            R$ {balance.toFixed(2).replace('.', ',')}
          </div>
          <span className="text-[10px] text-neutral-500 block">Pode ser abatido diretamente no valor das corridas</span>
        </div>

        {successMsg ? (
          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-center text-xs text-emerald-300 font-bold">
            ✅ Créditos adicionados com sucesso!
          </div>
        ) : (
          <div className="space-y-3">
            <span className="text-xs font-bold text-neutral-300 block">Recarregar Saldo via PIX:</span>
            <div className="grid grid-cols-3 gap-2">
              {[10, 20, 50].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(val)}
                  className={`py-2 rounded-xl text-xs font-bold border transition-colors ${
                    amount === val
                      ? 'bg-[#a3e635] text-neutral-950 border-[#a3e635]'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                  }`}
                >
                  R$ {val},00
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleAdd}
              className="w-full py-3 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              Confirmar Recarga de R$ {amount},00
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// 2. SOLICITAR REEMBOLSO
export const RefundModal: React.FC<ModalProps & { rides: RideData[]; onSubmitRefund: (data: RefundRequest) => void }> = ({
  isOpen,
  onClose,
  rides,
  onSubmitRefund,
}) => {
  const [motivo, setMotivo] = useState('Cobrança divergente');
  const [selectedRideId, setSelectedRideId] = useState(rides[0]?.id || '');
  const [detalhes, setDetalhes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const req: RefundRequest = {
      id: `ref-${Date.now()}`,
      corridaId: selectedRideId || 'GERAL',
      motivo: `${motivo}: ${detalhes}`,
      valor: rides.find((r) => r.id === selectedRideId)?.valorTotal || 15.5,
      data: new Date().toLocaleDateString('pt-BR'),
      status: 'em_analise',
    };
    onSubmitRefund(req);
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-black text-white">Solicitar Reembolso</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        {submitted ? (
          <div className="text-center py-4 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <div className="text-sm font-bold text-white">Solicitação Encaminhada!</div>
            <p className="text-xs text-neutral-400">
              A equipe financeira da Central W-DRIVER analisará seu pedido em até 2 horas. O estorno é creditado diretamente no seu W-BANK ou chave PIX.
            </p>
            <button
              onClick={onClose}
              className="mt-3 w-full py-2.5 rounded-xl bg-neutral-800 text-white text-xs font-bold"
            >
              Fechar
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3 text-xs">
            <div>
              <label className="text-neutral-400 font-bold block mb-1">Motivo do Reembolso:</label>
              <select
                value={motivo}
                onChange={(e) => setMotivo(e.target.value)}
                className="w-full py-2 px-3 bg-neutral-900 border border-neutral-800 rounded-xl text-white outline-none"
              >
                <option value="Cobrança divergente">Cobrança divergente do estimado</option>
                <option value="Motorista não compareceu">Motorista não compareceu ao embarque</option>
                <option value="Veículo em más condições">Veículo em desacordo com a categoria</option>
                <option value="Outros motivos">Outros motivos operacionais</option>
              </select>
            </div>

            <div>
              <label className="text-neutral-400 font-bold block mb-1">Detalhes do Ocorrido:</label>
              <textarea
                value={detalhes}
                onChange={(e) => setDetalhes(e.target.value)}
                placeholder="Descreva brevemente o que aconteceu..."
                rows={3}
                className="w-full py-2 px-3 bg-neutral-900 border border-neutral-800 rounded-xl text-white outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              Enviar Solicitação para Central
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

// 3. OBJETOS ESQUECIDOS
export const LostItemsModal: React.FC<ModalProps & { onSubmitReport: (report: LostItemReport) => void }> = ({
  isOpen,
  onClose,
  onSubmitReport,
}) => {
  const [item, setItem] = useState('');
  const [descricao, setDescricao] = useState('');
  const [telefone, setTelefone] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!item.trim() || !telefone.trim()) {
      alert('Informe o objeto e seu telefone de contato.');
      return;
    }
    onSubmitReport({
      id: `lost-${Date.now()}`,
      corridaId: 'Última viagem',
      item: item.trim(),
      descricao: descricao.trim(),
      telefoneContato: telefone.trim(),
      data: new Date().toLocaleDateString('pt-BR'),
      status: 'aberto',
    });
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-sky-400" />
            <h3 className="text-sm font-black text-white">Objetos Esquecidos</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        {submitted ? (
          <div className="text-center py-4 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-sky-400 mx-auto" />
            <div className="text-sm font-bold text-white">Alerta Notificado ao Motorista!</div>
            <p className="text-xs text-neutral-400">
              O motorista foi avisado no aplicativo de bordo e a Central W-DRIVER intermediará a devolução segura.
            </p>
            <button onClick={onClose} className="mt-3 w-full py-2.5 rounded-xl bg-neutral-800 text-white text-xs font-bold">
              Fechar
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3 text-xs">
            <div>
              <label className="text-neutral-400 font-bold block mb-1">Qual objeto foi deixado?</label>
              <input
                type="text"
                value={item}
                onChange={(e) => setItem(e.target.value)}
                placeholder="Ex: Celular Samsung, Mochila preta, Óculos..."
                className="w-full py-2 px-3 bg-neutral-900 border border-neutral-800 rounded-xl text-white outline-none"
                required
              />
            </div>

            <div>
              <label className="text-neutral-400 font-bold block mb-1">Detalhes ou banco onde estava:</label>
              <textarea
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                placeholder="Ex: No banco traseiro do lado direito..."
                rows={2}
                className="w-full py-2 px-3 bg-neutral-900 border border-neutral-800 rounded-xl text-white outline-none"
              />
            </div>

            <div>
              <label className="text-neutral-400 font-bold block mb-1">WhatsApp de Contato:</label>
              <input
                type="text"
                value={telefone}
                onChange={(e) => setTelefone(e.target.value)}
                placeholder="(83) 99999-0000"
                className="w-full py-2 px-3 bg-neutral-900 border border-neutral-800 rounded-xl text-white outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-sky-500 hover:bg-sky-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
            >
              Registrar Objeto Esquecido
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

// 4. INDIQUE E GANHE
export const ReferralModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const referralCode = 'WDRIVER-JP83';

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(`Baixe o app W-DRIVER João Pessoa e ganhe R$ 5,00 usando meu código oficial: ${referralCode}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm bg-neutral-950 border border-[#a3e635]/40 rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <Gift className="w-5 h-5 text-[#a3e635]" />
            <h3 className="text-sm font-black text-white">Indique e Ganhe</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-b from-[#142607] to-neutral-900 text-center space-y-2 border border-[#a3e635]/30">
          <div className="text-xs font-bold text-white">
            Indique amigos e ganhe créditos!
          </div>
          <p className="text-xs text-[#a3e635] font-semibold leading-relaxed">
            A cada 10 viagens concluídas pelo indicado, você ganha R$ 5,00 em créditos diretos na sua conta!
          </p>
        </div>

        <div className="space-y-1.5 text-center">
          <span className="text-[11px] text-neutral-400 font-bold uppercase tracking-wider block">
            Seu Código Exclusivo:
          </span>
          <div className="flex items-center gap-2 p-3 bg-neutral-900 border border-neutral-800 rounded-2xl">
            <span className="font-mono text-base font-black text-white flex-1 tracking-wider">
              {referralCode}
            </span>
            <button
              onClick={handleCopy}
              className="p-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 transition-colors"
              title="Copiar código de indicação"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          {copied && <span className="text-[10px] text-[#a3e635] font-bold">Copiado para a área de transferência!</span>}
        </div>

        <button
          onClick={handleCopy}
          className="w-full py-3 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
          <span>Compartilhar via WhatsApp</span>
        </button>
      </div>
    </div>
  );
};

// 5. PROMOÇÕES & CUPONS
export const PromotionsModal: React.FC<ModalProps & { onApplyCoupon: (code: string) => void }> = ({
  isOpen,
  onClose,
  onApplyCoupon,
}) => {
  const [code, setCode] = useState('');
  const [appliedMsg, setAppliedMsg] = useState('');

  if (!isOpen) return null;

  const coupons = [
    { code: 'BEMVINDO', desc: '10% de desconto na primeira corrida em João Pessoa', discount: 10 },
    { code: 'ORLAJP', desc: 'R$ 3,00 de desconto para viagens em Tambaú ou Cabo Branco', discount: 3 },
    { code: 'MOTOAGIL', desc: 'Tarifa especial para categorias W-MOTO e W-BIKE', discount: 15 },
  ];

  const handleApply = (c: string) => {
    onApplyCoupon(c);
    setAppliedMsg(`Cupom ${c} ativado com sucesso!`);
    setTimeout(() => {
      setAppliedMsg('');
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-[#a3e635]" />
            <h3 className="text-sm font-black text-white">Promoções & Cupons</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        {appliedMsg && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-center text-xs text-emerald-300 font-bold">
            {appliedMsg}
          </div>
        )}

        <div className="flex gap-2">
          <input
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="Digite o código do cupom"
            className="flex-1 py-2 px-3 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-white uppercase font-mono outline-none"
          />
          <button
            onClick={() => handleApply(code)}
            disabled={!code.trim()}
            className="px-3 py-2 bg-[#a3e635] text-neutral-950 font-black text-xs rounded-xl disabled:opacity-50"
          >
            Aplicar
          </button>
        </div>

        <div className="space-y-2">
          <span className="text-[11px] font-bold text-neutral-400 block">Cupons Disponíveis:</span>
          {coupons.map((c) => (
            <div
              key={c.code}
              className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between gap-2"
            >
              <div>
                <span className="font-mono text-xs font-black text-[#a3e635] block">{c.code}</span>
                <span className="text-[10px] text-neutral-400 block leading-tight">{c.desc}</span>
              </div>
              <button
                onClick={() => handleApply(c.code)}
                className="px-2.5 py-1 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-[#a3e635] text-[10px] font-bold shrink-0"
              >
                Usar
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 6. CENTRAL DE AJUDA
export const HelpCenterModal: React.FC<ModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-3xl p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <PhoneCall className="w-5 h-5 text-[#a3e635]" />
            <h3 className="text-sm font-black text-white">Central de Ajuda 24h</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white"><X className="w-4 h-4" /></button>
        </div>

        <div className="space-y-2 text-xs">
          <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
            <span className="text-[10px] text-neutral-500 font-bold uppercase block">Telefone de Atendimento:</span>
            <div className="text-base font-black text-white">0800 000 0000</div>
            <span className="text-[10px] text-[#a3e635] block">Ligação Gratuita • 24 Horas</span>
          </div>

          <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
            <span className="text-[10px] text-neutral-500 font-bold uppercase block">E-mail Oficial:</span>
            <div className="text-sm font-bold text-white">suporte@wdriver.com</div>
            <span className="text-[10px] text-neutral-400 block">Resposta média em até 15 minutos</span>
          </div>

          <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
            <span className="text-[10px] text-neutral-500 font-bold uppercase block">Operação Local:</span>
            <div className="text-xs font-bold text-white">João Pessoa - Paraíba (Brasil)</div>
            <span className="text-[10px] text-neutral-400 block">Cobertura em todos os bairros e praias</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs"
        >
          Fechar
        </button>
      </div>
    </div>
  );
};
