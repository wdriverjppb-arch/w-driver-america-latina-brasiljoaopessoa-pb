import React, { useState, useRef } from 'react';
import { 
  ShieldCheck, Lock, FileCheck, CheckCircle2, 
  AlertTriangle, Camera, ArrowRight, ShieldAlert,
  Bike, Car, Sparkles, Upload, Eye, FileText, Home,
  Check, X, RefreshCw, Clock
} from 'lucide-react';
import { UserRegistration, RegistrationCategory } from '../types';
import { TermsModal } from './TermsModal';

interface SecurityRegistrationProps {
  registration: UserRegistration;
  onUpdateRegistration: (data: Partial<UserRegistration>) => void;
  onGoToPassengerApp: () => void;
}

export const SecurityRegistration: React.FC<SecurityRegistrationProps> = ({
  registration,
  onUpdateRegistration,
  onGoToPassengerApp,
}) => {
  const [currentStep, setCurrentStep] = useState<'welcome' | 'form' | 'locked'>('welcome');
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [govBrLoading, setGovBrLoading] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<string | null>(null);

  // Hidden File Input Refs
  const profilePhotoInputRef = useRef<HTMLInputElement>(null);
  const cnhInputRef = useRef<HTMLInputElement>(null);
  const antecedentesInputRef = useRef<HTMLInputElement>(null);
  const residenciaInputRef = useRef<HTMLInputElement>(null);

  const CATEGORIES_LIST: { id: RegistrationCategory; name: string; icon: any; desc: string }[] = [
    { id: 'w_bike', name: 'W-BIKE', icon: Bike, desc: 'Bicicletas mecânicas e elétricas (até 4km)' },
    { id: 'w_moto', name: 'W-MOTO', icon: Sparkles, desc: 'Motocicletas ágeis e econômicas' },
    { id: 'w_carro', name: 'W-CARRO', icon: Car, desc: 'Sedans e hatches 4 portas com ar-condicionado' },
    { id: 'w_taxi', name: 'W-TÁXI', icon: Car, desc: 'Táxis cadastrados com permissão municipal oficial' },
    { id: 'w_luxo', name: 'W-LUXO', icon: Sparkles, desc: 'Veículos executivos e blindados de alto padrão' },
  ];

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: 'selfie' | 'cnh' | 'antecedentes' | 'residencia'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;

      if (type === 'selfie') {
        onUpdateRegistration({
          selfieEnviada: true,
          selfieUrl: dataUrl,
        });
        setUploadFeedback('✅ Foto de perfil (sem acessórios) anexada com sucesso!');
      } else if (type === 'cnh') {
        onUpdateRegistration({
          documentoEnviado: true,
          documentoUrl: dataUrl,
        });
        setUploadFeedback('✅ Documento CNH com EAR anexado com sucesso!');
      } else if (type === 'antecedentes') {
        onUpdateRegistration({
          antecedentesEnviados: true,
          antecedentesUrl: dataUrl,
        });
        setUploadFeedback('✅ Certidão de Antecedentes Criminais anexada!');
      } else if (type === 'residencia') {
        onUpdateRegistration({
          comprovanteResidenciaEnviado: true,
          comprovanteResidenciaUrl: dataUrl,
        });
        setUploadFeedback('✅ Comprovante de Residência anexado com sucesso!');
      }

      setTimeout(() => setUploadFeedback(null), 4000);
    };

    reader.readAsDataURL(file);
  };

  const handleAssinarGovBr = () => {
    setGovBrLoading(true);
    setTimeout(() => {
      setGovBrLoading(false);
      onUpdateRegistration({ govBrAssinado: true });
      setUploadFeedback('✅ Assinatura digital gov.br validada com certificado ICP-Brasil!');
      setTimeout(() => setUploadFeedback(null), 4000);
    }, 1200);
  };

  const handleEnviarCadastro = () => {
    if (!registration.nome || !registration.cpf) {
      alert('Por favor, preencha seu Nome Completo e CPF.');
      return;
    }
    if (!registration.selfieEnviada) {
      alert('É obrigatório anexar a Foto de Perfil (sem boné/óculos escuros).');
      return;
    }
    if (!registration.documentoEnviado) {
      alert('É obrigatório anexar a CNH com EAR.');
      return;
    }
    if (!registration.antecedentesEnviados) {
      alert('É obrigatório anexar a Certidão de Antecedentes Criminais.');
      return;
    }
    if (!registration.comprovanteResidenciaEnviado) {
      alert('É obrigatório anexar o Comprovante de Residência.');
      return;
    }
    if (!registration.termosAceitos) {
      alert('É necessário aceitar os Termos de Uso e Normas Anti-Calote.');
      return;
    }
    if (!registration.govBrAssinado) {
      alert('É obrigatório assinar digitalmente via gov.br antes de submeter.');
      return;
    }

    onUpdateRegistration({
      status: 'em_analise',
      dataSubmissao: new Date().toLocaleDateString('pt-BR'),
    });
    setCurrentStep('locked');
  };

  const handleAprovarImediatamenteSimulacao = () => {
    onUpdateRegistration({ status: 'aprovado' });
    alert('✅ Cadastro APROVADO pela Central W-DRIVER! Todas as funcionalidades e viagens liberadas.');
    onGoToPassengerApp();
  };

  return (
    <div className="w-full space-y-4 animate-fadeIn">
      {/* STEP 1: APRESENTAÇÃO E NORMAS DE SEGURANÇA */}
      {currentStep === 'welcome' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-2xl space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold text-[#a3e635] uppercase tracking-wider block">
                SISTEMA BLINDADO W-DRIVER
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Cadastro e Validação de Segurança
              </h2>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
            A W-DRIVER é uma plataforma corporativa regulamentada, operando com repasse justo de 90% ao motorista e segurança inegociável ao passageiro. Para atuar na rede, todos os motoristas passam por checagem documental biométrica e de antecedentes criminais.
          </p>

          <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-2xl space-y-2">
            <span className="text-xs font-black text-red-300 uppercase tracking-wide flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              Diretrizes Oficiais Obrigatórias de Upload
            </span>
            <ul className="text-xs text-neutral-300 space-y-1 list-disc list-inside">
              <li><strong>Foto de perfil:</strong> Rosto limpo, sem óculos escuros, sem boné ou chapéu.</li>
              <li><strong>CNH com EAR:</strong> Carteira Nacional de Habilitação válida com atividade remunerada.</li>
              <li><strong>Antecedentes criminais:</strong> Certidão negativa emitida nos últimos 90 dias.</li>
              <li><strong>Comprovante de residência:</strong> Em nome próprio ou com declaração de moradia em João Pessoa/PB.</li>
            </ul>
          </div>

          <button
            onClick={() => setCurrentStep('form')}
            className="w-full py-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs sm:text-sm uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(163,230,53,0.35)] cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Iniciar Formulário de Inscrição & Uploads</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* STEP 2: FORMULÁRIO DE INSCRIÇÃO COM UPLOADS FUNCIONAIS */}
      {currentStep === 'form' && (
        <div className="p-5 sm:p-7 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-2xl space-y-5">
          <div className="border-b border-neutral-800 pb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <Lock className="w-5 h-5 text-[#a3e635]" />
                <span>Formulário de Inscrição Oficial</span>
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Preencha seus dados cadastrais, selecione a categoria e anexe seus documentos.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setCurrentStep('welcome')}
              className="text-xs text-neutral-400 hover:text-white"
            >
              Voltar
            </button>
          </div>

          {/* Feedback de Upload */}
          {uploadFeedback && (
            <div className="p-3.5 bg-emerald-950/60 border border-emerald-500/50 rounded-2xl text-xs font-bold text-emerald-200 flex items-center gap-2 animate-fadeIn">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{uploadFeedback}</span>
            </div>
          )}

          {/* 1. SELEÇÃO DA CATEGORIA PRETENDIDA */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider">
              1. Categoria Pretendida na Plataforma:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {CATEGORIES_LIST.map((cat) => {
                const IconComponent = cat.icon;
                const isSelected = (registration.categoriaPretendida || 'w_carro') === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => onUpdateRegistration({ categoriaPretendida: cat.id })}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-2.5 ${
                      isSelected
                        ? 'bg-[#182a08] border-[#a3e635] shadow-[0_0_12px_rgba(163,230,53,0.25)]'
                        : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      isSelected ? 'bg-[#a3e635] text-neutral-950' : 'bg-neutral-900 text-neutral-400'
                    }`}>
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-black ${isSelected ? 'text-[#a3e635]' : 'text-white'}`}>
                          {cat.name}
                        </span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#a3e635]" />}
                      </div>
                      <p className="text-[10px] text-neutral-400 leading-tight mt-0.5">
                        {cat.desc}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. DADOS PESSOAIS */}
          <div className="space-y-3 pt-2">
            <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider">
              2. Dados Pessoais & Contato:
            </label>

            <div className="space-y-2.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
                  Nome Completo:
                </label>
                <input
                  type="text"
                  value={registration.nome}
                  onChange={(e) => onUpdateRegistration({ nome: e.target.value })}
                  placeholder="Seu nome completo como no documento"
                  className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-2xl text-white text-xs focus:border-[#a3e635] outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
                    CPF (Auditado pela Receita):
                  </label>
                  <input
                    type="text"
                    value={registration.cpf}
                    onChange={(e) => onUpdateRegistration({ cpf: e.target.value })}
                    placeholder="000.000.000-00"
                    className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-2xl text-white text-xs focus:border-[#a3e635] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
                    Telefone WhatsApp:
                  </label>
                  <input
                    type="text"
                    value={registration.telefone}
                    onChange={(e) => onUpdateRegistration({ telefone: e.target.value })}
                    placeholder="(83) 99999-0000"
                    className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-2xl text-white text-xs focus:border-[#a3e635] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
                    E-mail:
                  </label>
                  <input
                    type="email"
                    value={registration.email || ''}
                    onChange={(e) => onUpdateRegistration({ email: e.target.value })}
                    placeholder="seuemail@exemplo.com"
                    className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-2xl text-white text-xs focus:border-[#a3e635] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-neutral-400 mb-1">
                    Bairro / Cidade:
                  </label>
                  <input
                    type="text"
                    value={registration.bairro || registration.naturalidade}
                    onChange={(e) => onUpdateRegistration({ bairro: e.target.value, naturalidade: e.target.value })}
                    placeholder="Ex: Torre, João Pessoa - PB"
                    className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-2xl text-white text-xs focus:border-[#a3e635] outline-none"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 3. BOTÕES DE UPLOAD FUNCIONAIS */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider">
                3. Uploads Obrigatórios de Documentos:
              </label>
              <span className="text-[10px] text-[#a3e635] font-semibold">
                Anexe fotos ou PDFs
              </span>
            </div>

            {/* Hidden Input Elements */}
            <input
              ref={profilePhotoInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleFileUpload(e, 'selfie')}
            />
            <input
              ref={cnhInputRef}
              type="file"
              accept="image/*,.pdf"
              className="hidden"
              onChange={(e) => handleFileUpload(e, 'cnh')}
            />
            <input
              ref={antecedentesInputRef}
              type="file"
              accept="image/*,.pdf"
              className="hidden"
              onChange={(e) => handleFileUpload(e, 'antecedentes')}
            />
            <input
              ref={residenciaInputRef}
              type="file"
              accept="image/*,.pdf"
              className="hidden"
              onChange={(e) => handleFileUpload(e, 'residencia')}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* UPLOAD 1: FOTO DE PERFIL (SEM ACESSÓRIOS) */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
                      <Camera className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Foto de Perfil</h4>
                      <p className="text-[10px] text-neutral-400">Sem óculos escuros ou boné</p>
                    </div>
                  </div>
                  {registration.selfieEnviada && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-500/40 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Anexada
                    </span>
                  )}
                </div>

                {registration.selfieUrl ? (
                  <div className="flex items-center gap-3 p-2 bg-neutral-900 rounded-xl border border-neutral-800">
                    <img
                      src={registration.selfieUrl}
                      alt="Selfie"
                      className="w-12 h-12 rounded-lg object-cover border border-[#a3e635]/40"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-semibold text-white truncate">Foto de Perfil Válida</p>
                      <button
                        type="button"
                        onClick={() => profilePhotoInputRef.current?.click()}
                        className="text-[10px] text-[#a3e635] hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <RefreshCw className="w-3 h-3" /> Trocar foto
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => profilePhotoInputRef.current?.click()}
                    className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-dashed border-neutral-700 hover:border-[#a3e635] text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#a3e635]" />
                    <span>Selecionar Foto de Perfil</span>
                  </button>
                )}
              </div>

              {/* UPLOAD 2: CNH COM EAR */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
                      <FileCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">CNH com EAR</h4>
                      <p className="text-[10px] text-neutral-400">Atividade Remunerada (Frente/Verso)</p>
                    </div>
                  </div>
                  {registration.documentoEnviado && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-500/40 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Anexada
                    </span>
                  )}
                </div>

                {registration.documentoUrl ? (
                  <div className="flex items-center gap-3 p-2 bg-neutral-900 rounded-xl border border-neutral-800">
                    <div className="w-12 h-12 rounded-lg bg-neutral-800 flex items-center justify-center text-[#a3e635] shrink-0">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-semibold text-white truncate">CNH com EAR Anexada</p>
                      <button
                        type="button"
                        onClick={() => cnhInputRef.current?.click()}
                        className="text-[10px] text-[#a3e635] hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <RefreshCw className="w-3 h-3" /> Trocar documento
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => cnhInputRef.current?.click()}
                    className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-dashed border-neutral-700 hover:border-[#a3e635] text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#a3e635]" />
                    <span>Anexar CNH com EAR</span>
                  </button>
                )}
              </div>

              {/* UPLOAD 3: ANTECEDENTES CRIMINAIS */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Antecedentes Criminais</h4>
                      <p className="text-[10px] text-neutral-400">Certidão Federal e Estadual</p>
                    </div>
                  </div>
                  {registration.antecedentesEnviados && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-500/40 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Anexada
                    </span>
                  )}
                </div>

                {registration.antecedentesUrl ? (
                  <div className="flex items-center gap-3 p-2 bg-neutral-900 rounded-xl border border-neutral-800">
                    <div className="w-12 h-12 rounded-lg bg-neutral-800 flex items-center justify-center text-emerald-400 shrink-0">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-semibold text-white truncate">Certidão Negativa Anexada</p>
                      <button
                        type="button"
                        onClick={() => antecedentesInputRef.current?.click()}
                        className="text-[10px] text-[#a3e635] hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <RefreshCw className="w-3 h-3" /> Trocar certidão
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => antecedentesInputRef.current?.click()}
                    className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-dashed border-neutral-700 hover:border-[#a3e635] text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#a3e635]" />
                    <span>Anexar Antecedentes Criminais</span>
                  </button>
                )}
              </div>

              {/* UPLOAD 4: COMPROVANTE DE RESIDÊNCIA */}
              <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
                      <Home className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Comprovante de Residência</h4>
                      <p className="text-[10px] text-neutral-400">Água, luz ou gás recente</p>
                    </div>
                  </div>
                  {registration.comprovanteResidenciaEnviado && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 text-[10px] font-bold border border-emerald-500/40 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Anexada
                    </span>
                  )}
                </div>

                {registration.comprovanteResidenciaUrl ? (
                  <div className="flex items-center gap-3 p-2 bg-neutral-900 rounded-xl border border-neutral-800">
                    <div className="w-12 h-12 rounded-lg bg-neutral-800 flex items-center justify-center text-sky-400 shrink-0">
                      <Home className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-semibold text-white truncate">Comprovante de Residência</p>
                      <button
                        type="button"
                        onClick={() => residenciaInputRef.current?.click()}
                        className="text-[10px] text-[#a3e635] hover:underline flex items-center gap-1 mt-0.5"
                      >
                        <RefreshCw className="w-3 h-3" /> Trocar comprovante
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => residenciaInputRef.current?.click()}
                    className="w-full py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-dashed border-neutral-700 hover:border-[#a3e635] text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#a3e635]" />
                    <span>Anexar Comprovante Residência</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* 4. ASSINATURA DIGITAL GOV.BR */}
          <div className="p-3.5 bg-blue-950/30 border border-blue-500/40 rounded-2xl space-y-2">
            <label className="block text-xs font-bold text-blue-300 uppercase tracking-wider">
              4. Assinatura Digital Certificada (gov.br):
            </label>
            <button
              type="button"
              onClick={handleAssinarGovBr}
              disabled={govBrLoading || registration.govBrAssinado}
              className="w-full py-3 rounded-xl bg-[#1f6feb] hover:bg-[#388bfd] disabled:bg-neutral-800 text-white font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              {govBrLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Conectando ao Portal gov.br...</span>
                </>
              ) : registration.govBrAssinado ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Assinado Digitalmente via gov.br (ICP-Brasil Válido)</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Assinar Digitalmente via Portal gov.br</span>
                </>
              )}
            </button>
          </div>

          {/* 5. TERMOS DE CONFORMIDADE */}
          <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2">
            <div className="flex items-start gap-2.5">
              <input
                type="checkbox"
                id="termosConformidade"
                checked={registration.termosAceitos}
                onChange={(e) => onUpdateRegistration({ termosAceitos: e.target.checked })}
                className="mt-0.5 w-4 h-4 accent-[#a3e635] rounded cursor-pointer"
              />
              <label htmlFor="termosConformidade" className="text-xs text-neutral-300 leading-snug cursor-pointer">
                Declaro a veracidade de todos os dados e documentos anexados e concordo integralmente com os{' '}
                <button
                  type="button"
                  onClick={() => setShowTermsModal(true)}
                  className="text-[#a3e635] font-bold hover:underline"
                >
                  Termos de Uso, Normas Anti-Calote e Repasse Líquido de 90%
                </button>{' '}
                da W-DRIVER.
              </label>
            </div>
          </div>

          {/* BOTÃO FINAL DE SUBMISSÃO */}
          <button
            type="button"
            onClick={handleEnviarCadastro}
            className="w-full py-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs sm:text-sm uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(163,230,53,0.35)] cursor-pointer flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-5 h-5 stroke-[2.5]" />
            <span>Submeter Cadastro para Auditoria da Central W-DRIVER</span>
          </button>
        </div>
      )}

      {/* STEP 3: TELA DE ANÁLISE / CONFIRMAÇÃO */}
      {currentStep === 'locked' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-2xl text-center space-y-5">
          <div className="w-16 h-16 rounded-full bg-amber-950/60 border border-amber-500/50 text-amber-400 flex items-center justify-center mx-auto">
            <Clock className="w-8 h-8 animate-pulse" />
          </div>

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full bg-amber-950 text-amber-300 text-[10px] font-black uppercase tracking-wider border border-amber-500/40">
              Status: Cadastro em Auditoria 24h
            </span>
            <h3 className="text-xl font-black text-white">
              Documentos & Biometria Recebidos!
            </h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto">
              A equipe de compliance da Central W-DRIVER está conferindo sua CNH com EAR, antecedentes e foto sem acessórios.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 max-w-md mx-auto text-left space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-neutral-400">Nome:</span>
              <span className="font-bold text-white">{registration.nome}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">CPF:</span>
              <span className="font-bold text-white">{registration.cpf}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Categoria:</span>
              <span className="font-bold text-[#a3e635] uppercase">{registration.categoriaPretendida}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Assinatura Digital:</span>
              <span className="font-bold text-emerald-400">gov.br ICP-Brasil ✅</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleAprovarImediatamenteSimulacao}
              className="px-6 py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer"
            >
              Liberar Imediatamente (Aprovação Master)
            </button>
            <button
              type="button"
              onClick={() => setCurrentStep('form')}
              className="px-5 py-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold cursor-pointer"
            >
              Editar Documentos
            </button>
          </div>
        </div>
      )}

      {showTermsModal && (
        <TermsModal onClose={() => setShowTermsModal(false)} />
      )}
    </div>
  );
};
