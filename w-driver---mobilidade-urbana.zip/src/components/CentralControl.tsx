import React, { useState } from 'react';
import { 
  Building2, CheckCircle2, Clock, AlertTriangle, ShieldCheck, 
  UserCheck, ArrowRight, DollarSign, Activity, Zap, Ban, ShieldAlert, 
  FileText, Landmark, QrCode, Megaphone, Image as ImageIcon, Plus, 
  Trash2, Upload, ExternalLink, Users, Smartphone, Eye, MousePointer, 
  AlertCircle, Radio, Send, Edit3, Sliders, UserPlus
} from 'lucide-react';
import { RideData, UserRegistration, AdBanner, CentralAlert, ManagedUser, AdCategory, CategoryInfo } from '../types';
import { PIX_CONFIG } from '../utils/pix';
import { CATEGORIES } from '../data/categories';
import { CategoriesControlTab } from './central/CategoriesControlTab';
import { UserEditModal } from './central/UserEditModal';
import { AlertEditModal } from './central/AlertEditModal';
import { AdEditModal } from './central/AdEditModal';
import { CentralDashboardOverview } from './central/CentralDashboardOverview';
import { CentralSidebar, CentralMenuOption } from './central/CentralSidebar';

interface CentralControlProps {
  rides: RideData[];
  onApproveAndDispatch: (rideId: string) => void;
  onGoToDriverRadar: () => void;
  surgeMultiplier?: number;
  onChangeSurgeMultiplier?: (val: number) => void;
  registration?: UserRegistration;
  onUpdateRegistration?: (data: Partial<UserRegistration>) => void;
  ads: AdBanner[];
  onAddAd: (ad: AdBanner) => void;
  onUpdateAd?: (ad: AdBanner) => void;
  onToggleAd: (id: string) => void;
  onDeleteAd: (id: string) => void;
  alerts: CentralAlert[];
  onAddAlert: (alert: CentralAlert) => void;
  onUpdateAlert?: (alert: CentralAlert) => void;
  onToggleAlert: (id: string) => void;
  onDeleteAlert: (id: string) => void;
  managedUsers: ManagedUser[];
  onAddUser?: (user: ManagedUser) => void;
  onEditUser?: (user: ManagedUser) => void;
  onDeleteUser?: (id: string) => void;
  onUpdateUserStatus: (id: string, status: 'aprovado' | 'em_analise' | 'suspenso' | 'banido') => void;
  onAddBan: (cpf: string, imei: string, motivo: string) => void;
  categories?: CategoryInfo[];
  onUpdateCategories?: (cats: CategoryInfo[]) => void;
}

type CentralSubTab = 'visao_geral' | 'cadastros' | 'categorias' | 'dinamica' | 'pagamentos' | 'alertas' | 'publicidade';

export const CentralControl: React.FC<CentralControlProps> = ({
  rides,
  onApproveAndDispatch,
  onGoToDriverRadar,
  surgeMultiplier = 1.0,
  onChangeSurgeMultiplier,
  registration,
  onUpdateRegistration,
  ads,
  onAddAd,
  onUpdateAd,
  onToggleAd,
  onDeleteAd,
  alerts,
  onAddAlert,
  onUpdateAlert,
  onToggleAlert,
  onDeleteAlert,
  managedUsers,
  onAddUser,
  onEditUser,
  onDeleteUser,
  onUpdateUserStatus,
  onAddBan,
  categories = CATEGORIES,
  onUpdateCategories,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<CentralSubTab>('visao_geral');
  const [sidebarOption, setSidebarOption] = useState<CentralMenuOption>('visao_geral');
  const [auditFeedback, setAuditFeedback] = useState<string | null>(null);

  // Modais de Edição
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [selectedUserToEdit, setSelectedUserToEdit] = useState<ManagedUser | null>(null);

  const [docPreviewModal, setDocPreviewModal] = useState<{ title: string; url?: string; type: 'image' | 'doc' } | null>(null);

  const [alertModalOpen, setAlertModalOpen] = useState(false);
  const [selectedAlertToEdit, setSelectedAlertToEdit] = useState<CentralAlert | null>(null);

  const [adModalOpen, setAdModalOpen] = useState(false);
  const [selectedAdToEdit, setSelectedAdToEdit] = useState<AdBanner | null>(null);

  // States for Ban Tool
  const [banCpfInput, setBanCpfInput] = useState('');
  const [banImeiInput, setBanImeiInput] = useState('');
  const [banMotivoInput, setBanMotivoInput] = useState('Tentativa de Calote / Fraude no Desembarque');

  // States for New Alert
  const [alertTitulo, setAlertTitulo] = useState('');
  const [alertMensagem, setAlertMensagem] = useState('');
  const [alertDestinatario, setAlertDestinatario] = useState<'todos' | 'passageiros' | 'motoristas'>('todos');
  const [alertTipo, setAlertTipo] = useState<'urgente' | 'transito' | 'seguranca' | 'geral'>('transito');

  // States for New Ad Upload
  const [adTitulo, setAdTitulo] = useState('');
  const [adEmpresa, setAdEmpresa] = useState('');
  const [adCategoria, setAdCategoria] = useState<AdCategory>('espetinho');
  const [adImagemUrl, setAdImagemUrl] = useState('');
  const [adLinkWhatsApp, setAdLinkWhatsApp] = useState('');
  const [adCupom, setAdCupom] = useState('');
  const [adDescricao, setAdDescricao] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  // States for PIX QR Code Management (pixSettings)
  const [customPixQr, setCustomPixQr] = useState<string | null>(() => {
    return localStorage.getItem('wdriver_custom_pix_qr_code');
  });

  const handlePixQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      localStorage.setItem('wdriver_custom_pix_qr_code', base64);
      setCustomPixQr(base64);
      showNotification('✅ QR Code PIX carregado com sucesso! Já está visível na tela de pagamento dos passageiros.');
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePixQr = () => {
    localStorage.removeItem('wdriver_custom_pix_qr_code');
    setCustomPixQr(null);
    showNotification('ℹ️ QR Code personalizado removido. O sistema utilizará o QR Code dinâmico do Banco Central.');
  };

  // Financial calculations
  const pendingRides = rides.filter(
    (r) => r.status === 'solicitada' || r.status === 'aguardando_pix' || r.status === 'paga_central'
  );
  const totalFaturado = rides
    .filter((r) => r.status === 'concluida' || r.status === 'paga_central' || r.status === 'em_viagem')
    .reduce((acc, r) => acc + r.valorTotal, 0);

  const totalRepasse = rides
    .filter((r) => r.status === 'concluida' || r.status === 'paga_central' || r.status === 'em_viagem')
    .reduce((acc, r) => acc + r.repasseMotorista, 0);

  const totalTaxaCentral = rides
    .filter((r) => r.status === 'concluida' || r.status === 'paga_central' || r.status === 'em_viagem')
    .reduce((acc, r) => acc + r.taxaPlataforma, 0);

  const showNotification = (msg: string) => {
    setAuditFeedback(msg);
    setTimeout(() => setAuditFeedback(null), 4000);
  };

  // Handle Ban Submission
  const handleBanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!banCpfInput.trim() && !banImeiInput.trim()) {
      showNotification('⚠️ Informe pelo menos o CPF ou o IMEI para efetuar o banimento.');
      return;
    }
    onAddBan(banCpfInput.trim(), banImeiInput.trim(), banMotivoInput);
    showNotification(`🚫 Banimento executado com sucesso para CPF ${banCpfInput || 'N/A'} e IMEI ${banImeiInput || 'N/A'}!`);
    setBanCpfInput('');
    setBanImeiInput('');
  };

  // Handle New Alert
  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!alertTitulo.trim() || !alertMensagem.trim()) return;

    const newAlert: CentralAlert = {
      id: `alt-${Date.now()}`,
      tipo: alertTipo,
      titulo: alertTitulo.trim(),
      mensagem: alertMensagem.trim(),
      destinatario: alertDestinatario,
      criadoEm: 'Agora mesmo',
      ativo: true,
    };

    onAddAlert(newAlert);
    showNotification('📢 Comunicado transmitido com sucesso para os aplicativos!');
    setAlertTitulo('');
    setAlertMensagem('');
  };

  // Handle Image Upload for Ads
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = () => {
      setAdImagemUrl(reader.result as string);
      setIsUploading(false);
      showNotification('📷 Imagem do banner carregada com sucesso!');
    };
    reader.readAsDataURL(file);
  };

  // Handle New Ad Submission
  const handleCreateAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adTitulo.trim() || !adEmpresa.trim()) {
      showNotification('⚠️ Preencha os campos obrigatórios do anúncio.');
      return;
    }

    const fallbackImg = adImagemUrl || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&auto=format&fit=crop&q=80';

    const categoryLabels: Record<AdCategory, string> = {
      posto: 'Postos de Combustíveis',
      farmacia: 'Farmácias & Drogaria',
      espetinho: 'Gastronomia & Espetinhos',
      mercado: 'Supermercados & Atacarejo',
      outro: 'Comércio Local',
    };

    const newAd: AdBanner = {
      id: `ad-${Date.now()}`,
      titulo: adTitulo.trim(),
      empresa: adEmpresa.trim(),
      categoria: adCategoria,
      categoriaLabel: categoryLabels[adCategoria],
      imagemUrl: fallbackImg,
      linkWhatsApp: adLinkWhatsApp.trim() || undefined,
      cupom: adCupom.trim() || undefined,
      descricao: adDescricao.trim() || 'Parceiro comercial credenciado no ecossistema W-DRIVER.',
      ativo: true,
      cliques: 0,
      visualizacoes: 1,
      criadoEm: 'Hoje',
    };

    onAddAd(newAd);
    showNotification(`🎉 Banner do cliente "${adEmpresa}" ativado no ecossistema W-DRIVER!`);
    setAdTitulo('');
    setAdEmpresa('');
    setAdImagemUrl('');
    setAdLinkWhatsApp('');
    setAdCupom('');
    setAdDescricao('');
  };

  return (
    <div className="w-full space-y-5 animate-fadeIn pb-8">
      {/* HEADER MASTER DA CENTRAL */}
      <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black text-white">Central de Controle 24h</h1>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                Gestão Master Operacional
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              Autonomia total: auditoria antifraude por CPF/IMEI, despacho, dinâmica, PIX e módulo de publicidade
            </p>
          </div>
        </div>

        {/* INDICADOR TRILHA DINÂMICA */}
        <div className="flex items-center gap-2 bg-neutral-950 px-3 py-1.5 rounded-2xl border border-neutral-800">
          <span className="text-[10px] text-neutral-400 font-semibold">Dinâmica Atual:</span>
          <span className={`px-2 py-0.5 rounded-full text-xs font-black ${
            surgeMultiplier >= 3.5 
              ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
              : surgeMultiplier > 1.0 
              ? 'bg-amber-500/20 text-amber-300'
              : 'bg-emerald-500/20 text-emerald-400'
          }`}>
            {surgeMultiplier.toFixed(1)}x {surgeMultiplier >= 3.5 && '🔥 TRILHA ATIVA'}
          </span>
        </div>
      </div>

      {/* FEEDBACK BANNER */}
      {auditFeedback && (
        <div className="p-3.5 bg-neutral-900 border border-[#a3e635]/60 rounded-2xl text-xs font-bold text-[#a3e635] flex items-center gap-2 shadow-lg animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{auditFeedback}</span>
        </div>
      )}

      {/* 6 ABAS SUPERIORES DA CENTRAL (EXATAS À IMAGEM 2) */}
      <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 bg-neutral-950 p-1.5 rounded-2xl border border-neutral-800">
        <button
          type="button"
          onClick={() => { setActiveSubTab('visao_geral'); setSidebarOption('visao_geral'); }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'visao_geral'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Visão Geral</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveSubTab('dinamica'); setSidebarOption('mapa_geral'); }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'dinamica'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          <span>Monitoramento</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveSubTab('cadastros'); setSidebarOption('motoristas'); }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'cadastros'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Cadastros</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveSubTab('categorias'); setSidebarOption('status_viagens'); }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'categorias'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Corridas</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveSubTab('pagamentos'); setSidebarOption('receitas_transacoes'); }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'pagamentos'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>Financeiro</span>
        </button>

        <button
          type="button"
          onClick={() => { setActiveSubTab('publicidade'); setSidebarOption('anuncios'); }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            activeSubTab === 'publicidade'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40 shadow-sm'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>Configurações</span>
        </button>
      </div>

      {/* CORPO PRINCIPAL COM SIDEBAR DA CENTRAL (EXATO À IMAGEM 2) */}
      <div className="flex flex-col lg:flex-row gap-4 items-start">
        <CentralSidebar
          activeOption={sidebarOption}
          onSelectOption={(opt) => {
            setSidebarOption(opt);
            if (opt === 'visao_geral') setActiveSubTab('visao_geral');
            else if (opt === 'mapa_geral' || opt === 'chamadas_andamento' || opt === 'solicitacoes_pendentes' || opt === 'alertas_ocorrencias') setActiveSubTab('dinamica');
            else if (opt === 'motoristas' || opt === 'passageiros' || opt === 'documentos' || opt === 'aprovacao_motoristas' || opt === 'bloqueios' || opt === 'excluir_usuarios') setActiveSubTab('cadastros');
            else if (opt === 'status_viagens' || opt === 'relatorios') setActiveSubTab('categorias');
            else if (opt === 'receitas_transacoes' || opt === 'comissoes_taxas' || opt === 'extratos' || opt === 'carteira_digital') setActiveSubTab('pagamentos');
            else if (opt === 'anuncios' || opt === 'promocoes' || opt === 'indicacoes') setActiveSubTab('publicidade');
            else if (opt === 'wsos' || opt === 'mensagens' || opt === 'logs') setActiveSubTab('alertas');
          }}
          pendingApprovalsCount={managedUsers.filter((u) => u.status === 'em_analise').length}
          pendingRidesCount={pendingRides.length}
        />

        <div className="flex-1 w-full space-y-4 min-w-0">
          {/* VISÃO GERAL DASHBOARD MASTER */}
          {activeSubTab === 'visao_geral' && (
            <CentralDashboardOverview
              managedUsers={managedUsers}
              rides={rides}
              onApproveUser={(id) => {
                onUpdateUserStatus(id, 'aprovado');
                showNotification('✅ Usuário auditado e aprovado com sucesso!');
              }}
              onRejectUser={(id) => {
                onUpdateUserStatus(id, 'suspenso');
                showNotification('❌ Cadastro reprovado na auditoria.');
              }}
              onViewDocs={(u) => {
                setSelectedUserToEdit(u);
                setUserModalOpen(true);
              }}
              onSelectAction={(action) => {
                if (action === 'bloquear') { setActiveSubTab('cadastros'); setSidebarOption('bloqueios'); }
                else if (action === 'comunicado') { setActiveSubTab('alertas'); setSidebarOption('mensagens'); }
                else if (action === 'dinamica') { setActiveSubTab('dinamica'); setSidebarOption('mapa_geral'); }
                else if (action === 'tarifas') { setActiveSubTab('categorias'); setSidebarOption('status_viagens'); }
                else if (action === 'pix') { setActiveSubTab('pagamentos'); setSidebarOption('receitas_transacoes'); }
                else if (action === 'anuncio') { setActiveSubTab('publicidade'); setSidebarOption('anuncios'); }
                else if (action === 'aprovar_motoristas') { setActiveSubTab('cadastros'); setSidebarOption('aprovacao_motoristas'); }
                else if (action === 'sos') {
                  showNotification('🚨 Central W-SOS acionada. Monitoramento de ocorrências ativo.');
                } else {
                  showNotification(`⚙️ Módulo "${action}" carregado.`);
                }
              }}
            />
          )}

          {/* ======================================================== */}
          {/* 1. GESTÃO DE CADASTROS & BANIMENTO POR CPF/IMEI           */}
          {/* ======================================================== */}
          {activeSubTab === 'cadastros' && (
        <div className="space-y-4 animate-fadeIn">
          {/* PAINEL DE BANIMENTO RÁPIDO */}
          <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Ban className="w-5 h-5 text-red-400" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Bloqueio & Banimento Preventivo por CPF / IMEI
                </h3>
              </div>
              <span className="text-[10px] font-mono text-neutral-400 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
                Bloqueio via Hardware & Receita Federal
              </span>
            </div>

            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Ao banir por IMEI, o aparelho físico é travado na rede W-DRIVER, impedindo que o infrator crie novas contas ou tente dar calotes em outros motoristas na Paraíba.
            </p>

            <form onSubmit={handleBanSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1 font-bold">CPF do Alvo:</label>
                <input
                  type="text"
                  value={banCpfInput}
                  onChange={(e) => setBanCpfInput(e.target.value)}
                  placeholder="Ex: 042.881.992-01"
                  className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="text-[10px] text-neutral-400 block mb-1 font-bold">IMEI do Aparelho (Telemetria):</label>
                <input
                  type="text"
                  value={banImeiInput}
                  onChange={(e) => setBanImeiInput(e.target.value)}
                  placeholder="Ex: 864291048291038"
                  className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-red-500 font-mono"
                />
              </div>

              <div className="flex flex-col justify-end">
                <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Motivo do Bloqueio:</label>
                <div className="flex gap-2">
                  <select
                    value={banMotivoInput}
                    onChange={(e) => setBanMotivoInput(e.target.value)}
                    className="flex-1 p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
                  >
                    <option value="Tentativa de Calote / Sem Pagamento">Tentativa de Calote / Sem Pagamento</option>
                    <option value="Fraude Documental / Biometria Falsa">Fraude Documental / Biometria Falsa</option>
                    <option value="Desacato ou Conduta Agressiva">Desacato ou Conduta Agressiva</option>
                    <option value="Bloqueio Judicial Preventivo">Bloqueio Judicial Preventivo</option>
                  </select>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer shrink-0"
                  >
                    Banir Imediato
                  </button>
                </div>
              </div>
            </form>
          </div>

          {/* AUDITORIA DE CADASTROS & DOCUMENTOS ENVIADOS PELOS MOTORISTAS */}
          {registration && (
            <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-[#a3e635]/40 space-y-4 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-[#1a2e05] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white uppercase tracking-wider">
                      Auditoria de Documentos de Motorista em Tempo Real
                    </h3>
                    <p className="text-[11px] text-neutral-400">
                      Conferência oficial de CNH com EAR, antecedentes, residência e biometria sem acessórios
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                    registration.status === 'aprovado'
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                      : registration.status === 'em_analise'
                      ? 'bg-amber-950 text-amber-300 border-amber-500/50'
                      : 'bg-red-950 text-red-300 border-red-500/50'
                  }`}>
                    {registration.status === 'aprovado' ? '✅ Motorista Aprovado' : registration.status === 'em_analise' ? '⏳ Em Análise' : 'Bloqueado'}
                  </span>
                </div>
              </div>

              {/* DADOS DO MOTORISTA */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80">
                  <span className="text-[10px] text-neutral-400 block font-bold">Motorista:</span>
                  <strong className="text-white text-xs">{registration.nome}</strong>
                  <span className="text-[10px] text-neutral-400 block mt-0.5">CPF: {registration.cpf}</span>
                </div>

                <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80">
                  <span className="text-[10px] text-neutral-400 block font-bold">Contato:</span>
                  <strong className="text-white text-xs">{registration.telefone}</strong>
                  <span className="text-[10px] text-[#a3e635] block truncate mt-0.5">{registration.email || 'wdriveroficial@gmail.com'}</span>
                </div>

                <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80">
                  <span className="text-[10px] text-neutral-400 block font-bold">Categoria Pretendida:</span>
                  <strong className="text-[#a3e635] text-xs uppercase">{registration.categoriaPretendida || 'W-CARRO'}</strong>
                  <span className="text-[10px] text-neutral-400 block mt-0.5">{registration.bairro || 'Torre, João Pessoa / PB'}</span>
                </div>

                <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800/80">
                  <span className="text-[10px] text-neutral-400 block font-bold">Assinatura Digital:</span>
                  <strong className="text-emerald-400 text-xs">gov.br ICP-Brasil ✅</strong>
                  <span className="text-[10px] text-neutral-400 block mt-0.5">Termos de 90% Aceitos</span>
                </div>
              </div>

              {/* 4 DOCUMENTOS ANEXADOS */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider block">
                  Documentos & Arquivos Anexados:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {/* DOC 1: FOTO DE PERFIL */}
                  <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[11px] font-bold text-white mb-1">
                        <span>Foto de Perfil</span>
                        <span className="text-[9px] text-emerald-400">Sem óculos</span>
                      </div>
                      <div className="w-full h-24 rounded-xl bg-neutral-900 overflow-hidden flex items-center justify-center border border-neutral-800">
                        {registration.selfieUrl ? (
                          <img
                            src={registration.selfieUrl}
                            alt="Foto Perfil"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="text-[10px] text-neutral-500 text-center p-2">
                            Foto anexada no cadastro
                          </div>
                        )}
                      </div>
                    </div>
                    {registration.selfieUrl && (
                      <button
                        type="button"
                        onClick={() => setDocPreviewModal({ title: 'Foto de Perfil Oficial (Sem Acessórios)', url: registration.selfieUrl, type: 'image' })}
                        className="w-full py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-[10px] font-bold transition-colors cursor-pointer"
                      >
                        Visualizar Foto
                      </button>
                    )}
                  </div>

                  {/* DOC 2: CNH COM EAR */}
                  <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[11px] font-bold text-white mb-1">
                        <span>CNH com EAR</span>
                        <span className="text-[9px] text-emerald-400">Válida</span>
                      </div>
                      <div className="w-full h-24 rounded-xl bg-neutral-900 overflow-hidden flex flex-col items-center justify-center border border-neutral-800 p-2 text-center">
                        {registration.documentoUrl ? (
                          registration.documentoUrl.startsWith('data:image') ? (
                            <img src={registration.documentoUrl} alt="CNH" className="w-full h-full object-cover" />
                          ) : (
                            <div className="text-[10px] text-[#a3e635] font-bold">Arquivo CNH Anexado</div>
                          )
                        ) : (
                          <div className="text-[10px] text-neutral-500">Documento CNH EAR</div>
                        )}
                      </div>
                    </div>
                    {registration.documentoUrl && (
                      <button
                        type="button"
                        onClick={() => setDocPreviewModal({ title: 'CNH com EAR (Atividade Remunerada)', url: registration.documentoUrl, type: 'doc' })}
                        className="w-full py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-[10px] font-bold transition-colors cursor-pointer"
                      >
                        Inspecionar CNH
                      </button>
                    )}
                  </div>

                  {/* DOC 3: ANTECEDENTES CRIMINAIS */}
                  <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[11px] font-bold text-white mb-1">
                        <span>Antecedentes</span>
                        <span className="text-[9px] text-emerald-400">Negativo</span>
                      </div>
                      <div className="w-full h-24 rounded-xl bg-neutral-900 overflow-hidden flex flex-col items-center justify-center border border-neutral-800 p-2 text-center">
                        {registration.antecedentesUrl ? (
                          registration.antecedentesUrl.startsWith('data:image') ? (
                            <img src={registration.antecedentesUrl} alt="Antecedentes" className="w-full h-full object-cover" />
                          ) : (
                            <div className="text-[10px] text-emerald-400 font-bold">Certidão Negativa Anexada</div>
                          )
                        ) : (
                          <div className="text-[10px] text-neutral-500">Certidões Fed. / Est.</div>
                        )}
                      </div>
                    </div>
                    {registration.antecedentesUrl && (
                      <button
                        type="button"
                        onClick={() => setDocPreviewModal({ title: 'Certidão Negativa de Antecedentes Criminais', url: registration.antecedentesUrl, type: 'doc' })}
                        className="w-full py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-[10px] font-bold transition-colors cursor-pointer"
                      >
                        Inspecionar Certidão
                      </button>
                    )}
                  </div>

                  {/* DOC 4: COMPROVANTE DE RESIDÊNCIA */}
                  <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[11px] font-bold text-white mb-1">
                        <span>Residência</span>
                        <span className="text-[9px] text-sky-400">João Pessoa/PB</span>
                      </div>
                      <div className="w-full h-24 rounded-xl bg-neutral-900 overflow-hidden flex flex-col items-center justify-center border border-neutral-800 p-2 text-center">
                        {registration.comprovanteResidenciaUrl ? (
                          registration.comprovanteResidenciaUrl.startsWith('data:image') ? (
                            <img src={registration.comprovanteResidenciaUrl} alt="Residência" className="w-full h-full object-cover" />
                          ) : (
                            <div className="text-[10px] text-sky-400 font-bold">Comprovante Anexado</div>
                          )
                        ) : (
                          <div className="text-[10px] text-neutral-500">Comprovante de Residência</div>
                        )}
                      </div>
                    </div>
                    {registration.comprovanteResidenciaUrl && (
                      <button
                        type="button"
                        onClick={() => setDocPreviewModal({ title: 'Comprovante de Residência (João Pessoa/PB)', url: registration.comprovanteResidenciaUrl, type: 'doc' })}
                        className="w-full py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white text-[10px] font-bold transition-colors cursor-pointer"
                      >
                        Inspecionar Residência
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* BOTÕES DE AÇÃO DE APROVAÇÃO */}
              {onUpdateRegistration && (
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-neutral-800">
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateRegistration({ status: 'aprovado' });
                      showNotification(`✅ Cadastro de ${registration.nome} APROVADO pela Central!`);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                    <span>Aprovar Cadastro & Liberar Corridas</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateRegistration({ status: 'em_analise' });
                      showNotification(`⏳ Cadastro marcado como pendente de análise.`);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-xs cursor-pointer"
                  >
                    Marcar em Análise
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateRegistration({ status: 'bloqueado' });
                      showNotification(`🚫 Cadastro de ${registration.nome} bloqueado por inconformidade.`);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800/60 font-bold text-xs cursor-pointer"
                  >
                    Rejeitar / Bloquear
                  </button>
                </div>
              )}
            </div>
          )}

          {/* LISTA DE USUÁRIOS E MOTORISTAS GERENCIADOS */}
          <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-[#a3e635]" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Usuários & Motoristas Auditados
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-neutral-400">
                  {managedUsers.length} cadastros
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedUserToEdit(null);
                    setUserModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs flex items-center gap-1.5 cursor-pointer transition-all shadow-md"
                >
                  <UserPlus className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>+ Novo Cadastro</span>
                </button>
              </div>
            </div>

            <div className="space-y-2.5">
              {managedUsers.map((user) => (
                <div
                  key={user.id}
                  className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800/80 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:border-neutral-700 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    {/* Foto Avatar */}
                    <div className="w-11 h-11 rounded-xl overflow-hidden bg-neutral-900 border border-neutral-700 shrink-0 flex items-center justify-center">
                      {user.fotoUrl ? (
                        <img src={user.fotoUrl} alt={user.nome} className="w-full h-full object-cover" />
                      ) : (
                        <Users className="w-5 h-5 text-neutral-500" />
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-black text-white">{user.nome}</span>
                        <span className={`px-2 py-0.2 rounded-full text-[9px] font-extrabold uppercase ${
                          user.tipo === 'motorista' ? 'bg-sky-500/20 text-sky-400' : 'bg-purple-500/20 text-purple-400'
                        }`}>
                          {user.tipo.toUpperCase()}
                        </span>
                        <span className={`px-2 py-0.2 rounded-full text-[9px] font-extrabold uppercase ${
                          user.status === 'aprovado'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : user.status === 'em_analise'
                            ? 'bg-amber-500/20 text-amber-300'
                            : user.status === 'suspenso'
                            ? 'bg-orange-500/20 text-orange-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {user.status.toUpperCase()}
                        </span>
                        {user.documentoUrl && (
                          <span className="px-1.5 py-0.2 rounded bg-neutral-800 text-[9px] text-[#a3e635] font-semibold flex items-center gap-0.5">
                            <FileText className="w-2.5 h-2.5" />
                            Doc OK
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-neutral-400">
                        <div><span className="text-neutral-500">CPF:</span> {user.cpf}</div>
                        <div><span className="text-neutral-500">IMEI:</span> <span className="font-mono">{user.imei}</span></div>
                        <div><span className="text-neutral-500">Local:</span> {user.cidade}</div>
                        {user.veiculo && <div><span className="text-neutral-500">Veículo:</span> {user.veiculo}</div>}
                      </div>

                      {user.motivoBloqueio && (
                        <div className="text-[10px] text-red-400 font-semibold">
                          Motivo: {user.motivoBloqueio}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* AÇÕES DE GESTÃO */}
                  <div className="flex flex-wrap items-center gap-1.5 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-neutral-800">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedUserToEdit(user);
                        setUserModalOpen(true);
                      }}
                      className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
                      title="Editar dados e documentos"
                    >
                      <Edit3 className="w-3 h-3 text-[#a3e635]" />
                      <span>Editar</span>
                    </button>

                    {user.status !== 'aprovado' && (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateUserStatus(user.id, 'aprovado');
                          showNotification(`✅ Cadastro de ${user.nome} APROVADO com sucesso!`);
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] transition-colors cursor-pointer"
                      >
                        Aprovar
                      </button>
                    )}

                    {user.status !== 'suspenso' && (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateUserStatus(user.id, 'suspenso');
                          showNotification(`⚠️ Usuário ${user.nome} SUSPENSO temporariamente.`);
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-orange-600 hover:bg-orange-500 text-white font-bold text-[10px] transition-colors cursor-pointer"
                      >
                        Suspender
                      </button>
                    )}

                    {user.status !== 'banido' ? (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateUserStatus(user.id, 'banido');
                          showNotification(`🚫 Usuário ${user.nome} BANIDO definitivamente por CPF e IMEI.`);
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] transition-colors cursor-pointer"
                      >
                        Banir IMEI
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateUserStatus(user.id, 'aprovado');
                          showNotification(`🔓 Usuário ${user.nome} DESBLOQUEADO.`);
                        }}
                        className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-bold text-[10px] transition-colors cursor-pointer"
                      >
                        Desbloquear
                      </button>
                    )}

                    {onDeleteUser && (
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Deseja excluir permanentemente o cadastro de ${user.nome}?`)) {
                            onDeleteUser(user.id);
                            showNotification(`Cadastro de ${user.nome} excluído do sistema.`);
                          }
                        }}
                        className="p-1.5 rounded-lg text-neutral-500 hover:text-red-400 hover:bg-neutral-900 transition-colors cursor-pointer"
                        title="Excluir cadastro"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 2. CONFIGURAÇÃO DE CATEGORIAS E TARIFAS OFICIAIS         */}
      {/* ======================================================== */}
      {activeSubTab === 'categorias' && onUpdateCategories && (
        <CategoriesControlTab
          categories={categories}
          onUpdateCategories={onUpdateCategories}
          showNotification={showNotification}
        />
      )}

      {/* ======================================================== */}
      {/* 2. SELETOR DE DINÂMICA REGIONAL (TRILHA 3.5X)             */}
      {/* ======================================================== */}
      {activeSubTab === 'dinamica' && (
        <div className="space-y-4 animate-fadeIn">
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-[#a3e635]" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Seletor de Dinâmica Regional W-DRIVER
                </h3>
              </div>
              <span className="text-[10px] text-neutral-400">
                Ajuste imediato em todo o radar de João Pessoa
              </span>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Ative a tarifa dinâmica em momentos de chuva forte, congestionamento nas orlas (Tambaú/Cabo Branco) ou horários de pico. O valor atualiza instantaneamente para passageiros e garante 90% de repasse líquido turbinado aos motoristas.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {[
                { label: 'Normal (1.0x)', val: 1.0, desc: 'Tráfego livre sem sobretaxa' },
                { label: 'Atenção (1.5x)', val: 1.5, desc: 'Horário de pico moderado' },
                { label: 'Chuva / Orla (2.0x)', val: 2.0, desc: 'Alta demanda regional' },
                { label: 'Trilha Dinâmica (3.5x)', val: 3.5, desc: 'Demanda máxima e trânsito lento' },
              ].map((item) => (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => {
                    onChangeSurgeMultiplier && onChangeSurgeMultiplier(item.val);
                    showNotification(`⚡ Dinâmica atualizada para ${item.val.toFixed(1)}x em todo o ecossistema!`);
                  }}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                    surgeMultiplier === item.val
                      ? 'bg-[#1a2e05] border-[#a3e635] text-[#a3e635] shadow-[0_0_20px_rgba(163,230,53,0.3)] scale-[1.02]'
                      : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700 text-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-black">{item.label}</span>
                    {surgeMultiplier === item.val && (
                      <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
                    )}
                  </div>
                  <div className="text-[10px] text-neutral-400">{item.desc}</div>
                </button>
              ))}
            </div>

            {/* STATUS DA TRILHA DINÂMICA ATIVA */}
            {surgeMultiplier >= 3.5 && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-red-950/70 via-neutral-900 to-red-950/70 border border-red-500/50 flex items-center justify-between animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-red-600 text-white font-black text-sm">
                    3.5x
                  </div>
                  <div>
                    <div className="text-xs font-black text-white uppercase tracking-wider">
                      Trilha Dinâmica 3.5x Ativada pela Central
                    </div>
                    <div className="text-[11px] text-neutral-300">
                      Tarifas multiplicadas por 3.5x para garantir disponibilidade máxima de frotas.
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => onChangeSurgeMultiplier && onChangeSurgeMultiplier(1.0)}
                  className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold"
                >
                  Normalizar (1.0x)
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 3. AUDITORIA DE PAGAMENTOS E PIX (90% / 10%)              */}
      {/* ======================================================== */}
      {activeSubTab === 'pagamentos' && (
        <div className="space-y-4 animate-fadeIn">
          {/* KPI CARDS */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-bold block uppercase">Volume Transacionado:</span>
              <div className="text-2xl font-black text-[#a3e635] mt-1">
                R$ {totalFaturado.toFixed(2).replace('.', ',')}
              </div>
              <span className="text-[10px] text-neutral-400">Custódia direta da empresa</span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-bold block uppercase">Repasses Motoristas (90%):</span>
              <div className="text-2xl font-black text-emerald-400 mt-1">
                R$ {totalRepasse.toFixed(2).replace('.', ',')}
              </div>
              <span className="text-[10px] text-emerald-400">Direto no W-BANK</span>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
              <span className="text-[10px] text-neutral-400 font-bold block uppercase">Taxa Operacional W-DRIVER (10%):</span>
              <div className="text-2xl font-black text-white mt-1">
                R$ {totalTaxaCentral.toFixed(2).replace('.', ',')}
              </div>
              <span className="text-[10px] text-neutral-400">Manutenção & Seguros</span>
            </div>
          </div>

          {/* DADOS DA CONTA JURÍDICA PIX & UPLOAD DE QR CODE (pixSettings) */}
          <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-[#a3e635]/40 space-y-4 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 text-xs font-black text-white uppercase tracking-wide">
                <Landmark className="w-4 h-4 text-[#a3e635]" />
                <span>Configuração PIX & Upload de QR Code da Central</span>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                Ativa no Banco Central do Brasil
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800">
              <div>
                <span className="text-[10px] text-neutral-500 block font-semibold">Favorecido Oficial (Titular):</span>
                <strong className="text-white text-xs block mt-0.5">{PIX_CONFIG.favorecido}</strong>
                <span className="text-[10px] text-neutral-400">W-DRIVER AMÉRICA LATINA BRASIL</span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 block font-semibold">CNPJ / Chave Pix de Liquidação:</span>
                <strong className="text-[#a3e635] font-mono text-xs block mt-0.5">{PIX_CONFIG.cnpjFormatado}</strong>
                <span className="text-[10px] text-neutral-400">João Pessoa - PB (Agência Central W-DRIVER)</span>
              </div>
            </div>

            {/* SEÇÃO DE UPLOAD DO QR CODE PIX */}
            <div className="p-3.5 rounded-2xl bg-neutral-950/80 border border-dashed border-neutral-700 space-y-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <QrCode className="w-3.5 h-3.5 text-[#a3e635]" />
                    <span>Upload do QR Code PIX (Imagens / Storage)</span>
                  </h4>
                  <p className="text-[10px] text-neutral-400 mt-0.5">
                    Envie a imagem do QR Code Pix da sua conta jurídica. Ela será exibida em alta definição na tela de pagamento do passageiro.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <label className="px-3.5 py-1.5 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 text-xs font-black uppercase tracking-wider cursor-pointer transition-all flex items-center gap-1.5 shadow-md">
                    <Upload className="w-3.5 h-3.5" />
                    <span>Fazer Upload</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePixQrUpload}
                      className="hidden"
                    />
                  </label>

                  {customPixQr && (
                    <button
                      type="button"
                      onClick={handleRemovePixQr}
                      className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-red-950/70 text-neutral-400 hover:text-red-300 border border-neutral-800 hover:border-red-800 text-xs font-bold transition-all cursor-pointer"
                    >
                      Remover
                    </button>
                  )}
                </div>
              </div>

              {customPixQr ? (
                <div className="flex items-center gap-3 p-2.5 rounded-xl bg-[#142608] border border-[#a3e635]/40 text-xs">
                  <img
                    src={customPixQr}
                    alt="QR Code Personalizado da Empresa"
                    className="w-14 h-14 object-contain rounded-lg bg-white p-1 border border-neutral-700"
                  />
                  <div className="space-y-0.5">
                    <span className="text-[#a3e635] font-bold block text-xs">
                      ✓ QR Code Personalizado Ativo
                    </span>
                    <span className="text-[10px] text-neutral-300 block">
                      Exibindo na tela de pagamento para todos os passageiros no tamanho otimizado (50% da tela do celular).
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-[10px] text-neutral-500 italic">
                  Utilizando o gerador automático dinâmico de QR Code do Banco Central com chave CNPJ oficial e código EMV BR Code.
                </div>
              )}
            </div>
          </div>

          {/* TRIAGEM E DESPACHO DE CORRIDAS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Corridas em Auditoria & Despacho
              </h3>
              <button
                onClick={onGoToDriverRadar}
                className="text-xs text-[#a3e635] hover:underline flex items-center gap-1 font-semibold"
              >
                <span>Ver Radar do Motorista</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {rides.length === 0 ? (
              <div className="p-8 text-center bg-neutral-900/50 border border-neutral-800 rounded-2xl">
                <p className="text-xs text-neutral-400">Nenhuma corrida solicitada no momento.</p>
              </div>
            ) : (
              rides.map((ride) => {
                const isAguardando = ride.status === 'solicitada' || ride.status === 'aguardando_pix';
                const isPaga = ride.status === 'paga_central';
                const isEmAndamento = ['despachada', 'motorista_a_caminho', 'motorista_no_local', 'em_viagem'].includes(ride.status);
                const isConcluida = ride.status === 'concluida';

                return (
                  <div
                    key={ride.id}
                    className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-md space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-lg bg-neutral-800 text-xs font-bold text-white">
                          {ride.categoria.name}
                        </span>
                        <span className="text-xs text-neutral-400 font-mono">
                          ID: #{ride.id.slice(-6).toUpperCase()}
                        </span>
                      </div>

                      {/* Status Badge */}
                      <div>
                        {isAguardando && (
                          <span className="px-2.5 py-1 rounded-full bg-amber-950/80 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>Aguardando PIX...</span>
                          </span>
                        )}
                        {isPaga && (
                          <span className="px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>PIX Confirmado pela Central</span>
                          </span>
                        )}
                        {isEmAndamento && (
                          <span className="px-2.5 py-1 rounded-full bg-sky-950/80 border border-sky-500/40 text-sky-300 text-xs font-bold flex items-center gap-1">
                            <Activity className="w-3 h-3 animate-spin" />
                            <span>Em Andamento ({ride.status.replace('_', ' ')})</span>
                          </span>
                        )}
                        {isConcluida && (
                          <span className="px-2.5 py-1 rounded-full bg-lime-950/80 border border-[#a3e635]/40 text-[#a3e635] text-xs font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Finalizada (Repassado 90%)</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Route Details */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs bg-neutral-950 p-3 rounded-xl border border-neutral-800">
                      <div>
                        <span className="text-neutral-500 block text-[10px]">Origem (Partida):</span>
                        <span className="text-neutral-200 font-semibold">{ride.origem}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 block text-[10px]">Destino (Chegada):</span>
                        <span className="text-neutral-200 font-semibold">{ride.destino}</span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
                      <div className="flex items-center gap-4">
                        <div>
                          <span className="text-neutral-500 text-[10px] block">Total Corrida:</span>
                          <strong className="text-[#a3e635] text-sm font-black">
                            R$ {ride.valorTotal.toFixed(2).replace('.', ',')}
                          </strong>
                        </div>
                        <div>
                          <span className="text-neutral-500 text-[10px] block">Repasse Motorista (90%):</span>
                          <strong className="text-emerald-300 text-sm font-bold">
                            R$ {ride.repasseMotorista.toFixed(2).replace('.', ',')}
                          </strong>
                        </div>
                        <div>
                          <span className="text-neutral-500 text-[10px] block">Taxa Central (10%):</span>
                          <strong className="text-neutral-400 text-sm font-medium">
                            R$ {ride.taxaPlataforma.toFixed(2).replace('.', ',')}
                          </strong>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {ride.status === 'aguardando_pix' && (
                          <button
                            onClick={() => onApproveAndDispatch(ride.id)}
                            className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs transition-colors shadow-md flex items-center gap-1.5 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Aprovar PIX Manualmente</span>
                          </button>
                        )}

                        {ride.status === 'paga_central' && (
                          <button
                            onClick={() => onApproveAndDispatch(ride.id)}
                            className="px-4 py-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-bold text-xs transition-colors shadow-[0_2px_10px_rgba(163,230,53,0.3)] flex items-center gap-1.5 cursor-pointer"
                          >
                            <ArrowRight className="w-3.5 h-3.5" />
                            <span>Despachar ao Radar do Motorista</span>
                          </button>
                        )}

                        {isEmAndamento && (
                          <button
                            onClick={onGoToDriverRadar}
                            className="px-3.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold cursor-pointer"
                          >
                            Acompanhar no Radar ➔
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 4. CENTRAL DE MENSAGENS E ALERTAS EM TEMPO REAL          */}
      {/* ======================================================== */}
      {activeSubTab === 'alertas' && (
        <div className="space-y-4 animate-fadeIn">
          {/* CRIADOR DE COMUNICADOS */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-[#a3e635]" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Emitir Comunicado Direto (Broadcast)
                </h3>
              </div>
              <span className="text-[10px] text-neutral-400">
                Disparo instantâneo para os apps
              </span>
            </div>

            <form onSubmit={handleCreateAlert} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Título do Alerta:</label>
                  <input
                    type="text"
                    value={alertTitulo}
                    onChange={(e) => setAlertTitulo(e.target.value)}
                    placeholder="Ex: 🌧️ Alerta de Chuva e Pista Escorregadia na Epitácio"
                    className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Destinatários:</label>
                    <select
                      value={alertDestinatario}
                      onChange={(e) => setAlertDestinatario(e.target.value as any)}
                      className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
                    >
                      <option value="todos">Todos (Passageiros e Motoristas)</option>
                      <option value="passageiros">Apenas Passageiros</option>
                      <option value="motoristas">Apenas Motoristas</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Categoria:</label>
                    <select
                      value={alertTipo}
                      onChange={(e) => setAlertTipo(e.target.value as any)}
                      className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
                    >
                      <option value="transito">Trânsito / Chuva</option>
                      <option value="seguranca">Segurança Antifraude</option>
                      <option value="urgente">Urgente / Operacional</option>
                      <option value="geral">Informativo Geral</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Conteúdo da Mensagem:</label>
                <textarea
                  rows={2}
                  value={alertMensagem}
                  onChange={(e) => setAlertMensagem(e.target.value)}
                  placeholder="Escreva a mensagem clara e objetiva para os usuários..."
                  className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
                  required
                />
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Transmitir Comunicado Agora</span>
                </button>
              </div>
            </form>
          </div>

          {/* LISTA DE ALERTAS ATIVOS */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Alertas Transmitidos Ativos ({alerts.length})
            </h3>

            <div className="space-y-2">
              {alerts.map((al) => (
                <div
                  key={al.id}
                  className={`p-3.5 rounded-2xl border flex items-start justify-between gap-3 ${
                    al.ativo
                      ? 'bg-neutral-950 border-neutral-800'
                      : 'bg-neutral-950/50 border-neutral-900 opacity-60'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-white">{al.titulo}</span>
                      <span className="px-2 py-0.2 rounded-full text-[9px] font-bold bg-[#1a2e05] text-[#a3e635] uppercase">
                        {al.destinatario.toUpperCase()}
                      </span>
                      <span className="text-[10px] text-neutral-500">{al.criadoEm}</span>
                    </div>
                    <p className="text-xs text-neutral-300">{al.mensagem}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAlertToEdit(al);
                        setAlertModalOpen(true);
                      }}
                      className="p-1.5 text-neutral-400 hover:text-[#a3e635] transition-colors cursor-pointer"
                      title="Editar mensagem"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleAlert(al.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        al.ativo
                          ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-neutral-800 text-neutral-400'
                      }`}
                    >
                      {al.ativo ? 'Ativo no App' : 'Pausado'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteAlert(al.id)}
                      className="p-1.5 text-neutral-500 hover:text-red-400 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* 5. GERENCIAMENTO DE PUBLICIDADE (ADS DE CLIENTES LOCAIS) */}
      {/* ======================================================== */}
      {activeSubTab === 'publicidade' && (
        <div className="space-y-4 animate-fadeIn">
          {/* FORMULÁRIO DE UPLOAD DE BANNERS */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-[#a3e635]" />
                <h3 className="text-sm font-black text-white uppercase tracking-wider">
                  Upload & Gestão de Banners de Clientes Locais (Ads)
                </h3>
              </div>
              <span className="text-[10px] font-bold text-[#a3e635] bg-[#1a2e05] px-2.5 py-1 rounded-full border border-[#a3e635]/40">
                Receita Extra com Patrocínio
              </span>
            </div>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Cadastre e faça upload de anúncios de patrocinadores locais de João Pessoa: <strong>espetinhos, farmácias, supermercados e postos de combustíveis</strong>. Os banners aparecem na tela do passageiro e na página inicial gerando retorno comercial.
            </p>

            <form onSubmit={handleCreateAd} className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Empresa Anunciante:</label>
                  <input
                    type="text"
                    value={adEmpresa}
                    onChange={(e) => setAdEmpresa(e.target.value)}
                    placeholder="Ex: Espetinho do Chefe Cabo Branco"
                    className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Título da Promoção:</label>
                  <input
                    type="text"
                    value={adTitulo}
                    onChange={(e) => setAdTitulo(e.target.value)}
                    placeholder="Ex: Chopp Dobrado e Espetinho na Brasa"
                    className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Segmento do Parceiro:</label>
                  <select
                    value={adCategoria}
                    onChange={(e) => setAdCategoria(e.target.value as any)}
                    className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
                  >
                    <option value="espetinho">Gastronomia & Espetinhos</option>
                    <option value="farmacia">Farmácias & Drogarias</option>
                    <option value="mercado">Supermercados & Atacarejos</option>
                    <option value="posto">Postos de Combustíveis</option>
                    <option value="outro">Outro Comércio Local</option>
                  </select>
                </div>
              </div>

              {/* UPLOAD DE ARQUIVO E URL */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-neutral-950 border border-dashed border-neutral-700 hover:border-[#a3e635]/60 transition-colors flex flex-col items-center justify-center text-center">
                  <Upload className="w-6 h-6 text-[#a3e635] mb-1" />
                  <span className="text-xs font-bold text-white">Upload Direto de Imagem</span>
                  <span className="text-[10px] text-neutral-400 mb-2">Clique ou arraste o banner do cliente (JPG, PNG)</span>
                  <label className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-bold cursor-pointer transition-colors">
                    Selecionar Arquivo
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageFileChange}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Ou informe URL da Imagem:</label>
                    <input
                      type="url"
                      value={adImagemUrl}
                      onChange={(e) => setAdImagemUrl(e.target.value)}
                      placeholder="https://..."
                      className="w-full p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Cupom de Desconto:</label>
                      <input
                        type="text"
                        value={adCupom}
                        onChange={(e) => setAdCupom(e.target.value)}
                        placeholder="Ex: WDRIVER-10"
                        className="w-full p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none uppercase font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-neutral-400 block mb-1 font-bold">WhatsApp p/ Pedidos:</label>
                      <input
                        type="text"
                        value={adLinkWhatsApp}
                        onChange={(e) => setAdLinkWhatsApp(e.target.value)}
                        placeholder="https://wa.me/5583..."
                        className="w-full p-2 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {adImagemUrl && (
                <div className="p-2 bg-neutral-950 rounded-xl border border-neutral-800 flex items-center gap-3">
                  <img src={adImagemUrl} alt="Prévia" className="w-16 h-16 rounded-lg object-cover" referrerPolicy="no-referrer" />
                  <span className="text-xs text-neutral-400">Prévia do banner carregado com sucesso</span>
                </div>
              )}

              <div>
                <label className="text-[10px] text-neutral-400 block mb-1 font-bold">Descrição da Oferta:</label>
                <input
                  type="text"
                  value={adDescricao}
                  onChange={(e) => setAdDescricao(e.target.value)}
                  placeholder="Ex: Apresente o aplicativo W-DRIVER e ganhe 15% de desconto imediato no consumo."
                  className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
                />
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Publicar Banner no W-DRIVER</span>
                </button>
              </div>
            </form>
          </div>

          {/* LISTA DE BANNERS ATIVOS */}
          <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
            <h3 className="text-sm font-black text-white uppercase tracking-wider">
              Banners Ativos em João Pessoa ({ads.length})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {ads.map((ad) => (
                <div
                  key={ad.id}
                  className={`p-3.5 rounded-2xl border flex gap-3 ${
                    ad.ativo ? 'bg-neutral-950 border-neutral-800' : 'bg-neutral-950/50 border-neutral-900 opacity-60'
                  }`}
                >
                  <img
                    src={ad.imagemUrl}
                    alt={ad.empresa}
                    className="w-20 h-20 rounded-xl object-cover shrink-0 border border-neutral-800"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-bold uppercase text-[#a3e635] truncate block">
                        {ad.categoriaLabel}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedAdToEdit(ad);
                            setAdModalOpen(true);
                          }}
                          className="text-neutral-400 hover:text-[#a3e635] p-0.5 cursor-pointer"
                          title="Editar anúncio"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteAd(ad.id)}
                          className="text-neutral-500 hover:text-red-400 p-0.5 cursor-pointer"
                          title="Excluir anúncio"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className="text-xs font-bold text-white truncate">{ad.titulo}</h4>
                    <span className="text-[10px] text-neutral-400 block truncate">{ad.empresa}</span>

                    <div className="flex items-center justify-between pt-1 text-[10px] text-neutral-500">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-0.5">
                          <Eye className="w-3 h-3 text-neutral-400" /> {ad.visualizacoes}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <MousePointer className="w-3 h-3 text-[#a3e635]" /> {ad.cliques}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onToggleAd(ad.id)}
                        className={`px-2 py-0.5 rounded text-[9px] font-bold cursor-pointer ${
                          ad.ativo ? 'bg-emerald-500/20 text-emerald-400' : 'bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {ad.ativo ? 'Ativo' : 'Pausado'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

        </div>
      </div>

      {/* MODAL EDITAR OU CRIAR CADASTRO (COM UPLOAD DE FOTO E DOCUMENTO) */}
      <UserEditModal
        isOpen={userModalOpen}
        user={selectedUserToEdit}
        onClose={() => {
          setUserModalOpen(false);
          setSelectedUserToEdit(null);
        }}
        onSave={(updatedUser) => {
          if (selectedUserToEdit) {
            if (onEditUser) {
              onEditUser(updatedUser);
            } else {
              onUpdateUserStatus(updatedUser.id, updatedUser.status);
            }
            showNotification(`✅ Dados e arquivos de ${updatedUser.nome} atualizados com sucesso!`);
          } else {
            if (onAddUser) {
              onAddUser(updatedUser);
            }
            showNotification(`✅ Novo usuário ${updatedUser.nome} cadastrado com sucesso!`);
          }
        }}
      />

      {/* MODAL EDITAR COMUNICADO / MENSAGEM */}
      {selectedAlertToEdit && (
        <AlertEditModal
          isOpen={alertModalOpen}
          alert={selectedAlertToEdit}
          onClose={() => {
            setAlertModalOpen(false);
            setSelectedAlertToEdit(null);
          }}
          onSave={(updatedAlert) => {
            if (onUpdateAlert) {
              onUpdateAlert(updatedAlert);
            }
            showNotification(`✅ Mensagem "${updatedAlert.titulo}" editada com sucesso!`);
          }}
        />
      )}

      {/* MODAL EDITAR ANÚNCIO / BANNER */}
      {selectedAdToEdit && (
        <AdEditModal
          isOpen={adModalOpen}
          ad={selectedAdToEdit}
          onClose={() => {
            setAdModalOpen(false);
            setSelectedAdToEdit(null);
          }}
          onSave={(updatedAd) => {
            if (onUpdateAd) {
              onUpdateAd(updatedAd);
            }
            showNotification(`✅ Anúncio de "${updatedAd.empresa}" atualizado com sucesso!`);
          }}
        />
      )}
      {/* MODAL DE VISUALIZAÇÃO/INSPEÇÃO DE DOCUMENTOS DO MOTORISTA */}
      {docPreviewModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative w-full max-w-2xl rounded-3xl bg-neutral-950 border border-[#a3e635]/50 p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">{docPreviewModal.title}</h3>
                  <p className="text-[10px] text-neutral-400">Auditoria Documental da Central 24h</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDocPreviewModal(null)}
                className="w-8 h-8 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="max-h-[65vh] overflow-y-auto rounded-2xl bg-neutral-900 border border-neutral-800 p-2 flex items-center justify-center">
              {docPreviewModal.url && docPreviewModal.url.startsWith('data:image') ? (
                <img
                  src={docPreviewModal.url}
                  alt={docPreviewModal.title}
                  className="max-h-[60vh] w-auto max-w-full rounded-xl object-contain shadow-lg"
                />
              ) : (
                <div className="p-8 text-center space-y-2">
                  <FileText className="w-12 h-12 text-[#a3e635] mx-auto" />
                  <p className="text-xs font-bold text-white">Documento Digital Anexado e Certificado</p>
                  <p className="text-[11px] text-neutral-400">Assinado com conformidade legal e validado pelo compliance W-DRIVER.</p>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDocPreviewModal(null)}
                className="px-4 py-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-bold text-xs cursor-pointer"
              >
                Concluir Inspeção
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
