import React, { useState, useEffect } from 'react';
import { 
  Car, Clock, DollarSign, FileText, Star, Bike, ShoppingBag, 
  FileCheck, Megaphone, User, AlertTriangle, ExternalLink, 
  Navigation, Compass, CheckCircle2, X, ChevronRight, ShieldAlert,
  MapPin, Shield, Video, Zap, Wallet
} from 'lucide-react';
import { RideData } from '../types';
import { SosModal } from './SosModal';
import { NoShowVideoModal } from './NoShowVideoModal';
import { DriverFeatureModal, DriverFeatureType } from './driver/DriverFeatureModal';

interface DriverAppProps {
  activeRide: RideData | null;
  surgeActive: boolean;
  onToggleSurge: () => void;
  onAcceptRide: (rideId: string) => void;
  onUpdateRideStatus: (rideId: string, status: RideData['status']) => void;
  onOpenWBank: () => void;
}

export const DriverApp: React.FC<DriverAppProps> = ({
  activeRide,
  surgeActive,
  onToggleSurge,
  onAcceptRide,
  onUpdateRideStatus,
  onOpenWBank,
}) => {
  const [isOnline, setIsOnline] = useState(true);
  const [activeFeature, setActiveFeature] = useState<DriverFeatureType | null>(null);
  const [showSosModal, setShowSosModal] = useState(false);
  const [showNoShowModal, setShowNoShowModal] = useState(false);
  const [secondsWaiting, setSecondsWaiting] = useState(180); // 3 min
  const [timerRunning, setTimerRunning] = useState(false);
  const [callCountdown, setCallCountdown] = useState(15);
  const [hasRefusedCall, setHasRefusedCall] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [demoCallActive, setDemoCallActive] = useState(false);

  // Default simulated upcoming ride matching Image 3 if no ride is dispatched from PassengerApp
  const fallbackRide: RideData = {
    id: 'ride-chamada-bessa',
    origem: 'Bessa Shopping, Av. Gov. Argemiro de Figueiredo, 1700, Bessa, João Pessoa - PB',
    origemBairro: 'Bessa',
    destino: 'Manaíra Shopping, Av. Gov. Flávio Ribeiro Coutinho, 805, Manaíra, João Pessoa - PB',
    destinoBairro: 'Manaíra',
    distanciaKm: 5.2,
    tempoEstimadoMin: 12,
    categoria: {
      id: 'w_carro_comum',
      name: 'W-CARRO',
      subtitle: 'Taxa fixa até 4 km R$ 8,00 | Km adic. R$ 1,75',
      baseFare: 8.0,
      kmAdicional: 1.75,
      iconType: 'car_white',
      capacity: 'Até 4 passageiros',
      etaMins: 4,
    },
    valorBase: 8.0,
    dinamicaAtiva: surgeActive,
    multiplicadorDinamica: surgeActive ? 3.5 : 1.0,
    valorTotal: 15.50,
    repasseMotorista: 13.95, // 90%
    taxaPlataforma: 1.55, // 10%
    status: 'despachada',
    criadoEm: 'Agora',
    chavePix: '00020126580014BR.GOV.BCB.PIX...',
    codigoPix: 'PIX-WDRIVER-CALL',
    passageiroNome: 'Mariana Medeiros (Nota 4.98 ⭐)',
    motoristaNome: 'Carlos E. da Silva',
    motoristaVeiculo: 'Toyota Corolla XEi • 2023',
    motoristaPlaca: 'QFA-9921',
    pin: '4821',
  };

  const incomingRide = activeRide || (demoCallActive && !hasRefusedCall ? fallbackRide : null);

  // Countdown timer for PRÓXIMA CHAMADA (00:15)
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isOnline && incomingRide && incomingRide.status === 'despachada' && callCountdown > 0) {
      interval = setInterval(() => {
        setCallCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isOnline, incomingRide, callCountdown]);

  // Wait timer for passenger boarding (3 minutes)
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (incomingRide?.status === 'motorista_no_local' && timerRunning && secondsWaiting > 0) {
      interval = setInterval(() => {
        setSecondsWaiting((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [incomingRide?.status, timerRunning, secondsWaiting]);

  useEffect(() => {
    if (incomingRide?.status === 'motorista_no_local') {
      setTimerRunning(true);
      setSecondsWaiting(180);
    } else {
      setTimerRunning(false);
    }
  }, [incomingRide?.status]);

  const formatTimer = (totalSec: number) => {
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const handleOpenGps = (app: 'Google Maps' | 'Waze', mode: 'embarque' | 'completa') => {
    if (!incomingRide) return;
    const target = mode === 'embarque' ? incomingRide.origem : incomingRide.destino;
    const enc = encodeURIComponent(target);
    const url = app === 'Waze' ? `https://waze.com/ul?q=${enc}&navigate=yes` : `https://www.google.com/maps/dir/?api=1&destination=${enc}`;
    window.open(url, '_blank');
  };

  const handleFinishRide = () => {
    if (!incomingRide) return;
    onUpdateRideStatus(incomingRide.id, 'concluida');
    setStatusMessage('✅ Viagem finalizada! 90% creditados automaticamente no seu W-BANK.');
  };

  return (
    <div className="w-full max-w-md mx-auto bg-[#0a0a0a] text-neutral-100 rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl flex flex-col min-h-[720px] p-4 space-y-3.5 select-none">
      {/* 1. TOP HEADER: ONLINE / OFFLINE TOGGLE SWITCH (Exact matching Image 3) */}
      <div className="flex items-center justify-between p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 shadow-md">
        <div className="flex items-center gap-2.5">
          <span className={`w-3 h-3 rounded-full ${isOnline ? 'bg-[#a3e635] shadow-[0_0_8px_#a3e635]' : 'bg-neutral-600'}`} />
          <div>
            <div className="text-xs font-black text-white leading-tight">
              {isOnline ? 'Você está ONLINE' : 'Você está OFFLINE'}
            </div>
            <div className="text-[10px] text-neutral-400">
              {isOnline ? 'Conectado para receber chamadas' : 'Toque no botão para conectar'}
            </div>
          </div>
        </div>

        {/* Custom Toggle Switch */}
        <button
          type="button"
          onClick={() => {
            setIsOnline(!isOnline);
            setCallCountdown(15);
            setHasRefusedCall(false);
          }}
          className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 flex items-center cursor-pointer ${
            isOnline ? 'bg-[#a3e635]' : 'bg-neutral-800'
          }`}
        >
          <div
            className={`w-4 h-4 rounded-full bg-neutral-950 transition-transform duration-300 transform ${
              isOnline ? 'translate-x-6' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* 2. STATS ROW (3 Cards: HOJE, SEMANA, AVALIAÇÃO - Matching Image 3) */}
      <div className="grid grid-cols-3 gap-2">
        {/* Hoje */}
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center flex flex-col justify-center">
          <span className="text-[10px] uppercase font-extrabold text-neutral-400 tracking-wider">
            HOJE
          </span>
          <div className="text-sm font-black text-[#a3e635] mt-0.5">
            R$ 215,60
          </div>
          <span className="text-[9px] text-neutral-500 font-medium">
            7 corridas
          </span>
        </div>

        {/* Semana */}
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center flex flex-col justify-center">
          <span className="text-[10px] uppercase font-extrabold text-neutral-400 tracking-wider">
            SEMANA
          </span>
          <div className="text-sm font-black text-[#a3e635] mt-0.5">
            R$ 1.256,40
          </div>
          <span className="text-[9px] text-neutral-500 font-medium">
            42 corridas
          </span>
        </div>

        {/* Avaliação */}
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center flex flex-col justify-center">
          <span className="text-[10px] uppercase font-extrabold text-neutral-400 tracking-wider">
            AVALIAÇÃO
          </span>
          <div className="text-sm font-black text-amber-400 mt-0.5">
            4,95
          </div>
          <div className="flex items-center justify-center text-amber-400 text-[10px] tracking-tighter">
            ★★★★★
          </div>
        </div>
      </div>

      {/* 3. PRÓXIMA CHAMADA CARD (Exact matching Image 3) */}
      {isOnline && incomingRide && incomingRide.status === 'despachada' && (
        <div className="p-4 rounded-3xl bg-neutral-900 border border-[#a3e635]/50 shadow-[0_0_24px_rgba(163,230,53,0.15)] space-y-3 animate-fadeIn">
          {/* Top Bar of Call */}
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
              <span className="text-xs font-black text-white tracking-wide uppercase">
                PRÓXIMA CHAMADA
              </span>
            </div>
            <span className="font-mono text-xs font-black text-[#a3e635] bg-[#1a2e05] px-2 py-0.5 rounded-lg border border-[#a3e635]/40">
              00:{callCountdown.toString().padStart(2, '0')}
            </span>
          </div>

          <div className="text-xs text-neutral-400 font-medium">
            📍 1,8 km de distância até o embarque
          </div>

          {/* Origem */}
          <div className="flex items-start gap-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-[#38bdf8] mt-1 shrink-0" />
            <div className="text-xs">
              <span className="text-white font-bold block">Bessa Shopping</span>
              <span className="text-neutral-400 text-[10px] block leading-tight">
                Av. Gov. Argemiro de Figueiredo, 1700, Bessa, João Pessoa - PB
              </span>
            </div>
          </div>

          {/* Destino */}
          <div className="flex items-start gap-2.5">
            <MapPin className="w-3 h-3 text-[#a3e635] shrink-0 fill-[#a3e635] mt-0.5" />
            <div className="text-xs">
              <span className="text-white font-bold block">Manaíra Shopping</span>
              <span className="text-neutral-400 text-[10px] block leading-tight">
                Av. Gov. Flávio Ribeiro Coutinho, 805, Manaíra, João Pessoa - PB
              </span>
            </div>
          </div>

          {/* Mini Route Map Preview (Stylized SVG Route matching screenshot) */}
          <div className="relative h-24 rounded-2xl bg-[#070b07] border border-neutral-800 overflow-hidden flex items-center justify-center">
            <svg viewBox="0 0 320 100" className="w-full h-full opacity-70">
              <path d="M 30 70 Q 120 20 200 40 T 290 30" fill="none" stroke="#a3e635" strokeWidth="3" strokeDasharray="6 4" />
              <circle cx="30" cy="70" r="5" fill="#38bdf8" />
              <circle cx="290" cy="30" r="6" fill="#a3e635" />
              <text x="35" y="85" fill="#94a3b8" fontSize="8" fontWeight="bold">Bessa</text>
              <text x="260" y="22" fill="#a3e635" fontSize="8" fontWeight="bold">Manaíra</text>
            </svg>
            <div className="absolute top-2 right-2 px-2 py-0.5 rounded-lg bg-neutral-900/90 text-[9px] text-[#a3e635] font-bold border border-neutral-700">
              {incomingRide.distanciaKm.toFixed(1)} km (~12 min)
            </div>
          </div>

          {/* Estimativa & Categoria */}
          <div className="flex items-center justify-between pt-1">
            <div>
              <span className="text-[10px] text-neutral-400 block font-medium">Estimativa da corrida</span>
              <span className="text-lg font-black text-white">
                R$ {incomingRide.valorTotal.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <span className="px-2.5 py-1 rounded-xl bg-neutral-800 border border-neutral-700 text-xs font-black text-[#a3e635]">
              [W-CARRO]
            </span>
          </div>

          {/* Action Buttons: RECUSAR ❌ & ACEITAR ✓ */}
          <div className="grid grid-cols-2 gap-2.5 pt-1">
            <button
              type="button"
              onClick={() => setHasRefusedCall(true)}
              className="py-3 rounded-2xl bg-neutral-950 hover:bg-neutral-800 border border-red-500/50 text-red-400 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>RECUSAR</span>
              <span className="text-sm">❌</span>
            </button>

            <button
              type="button"
              onClick={() => onAcceptRide(incomingRide.id)}
              className="py-3 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-[0_0_16px_rgba(163,230,53,0.3)] cursor-pointer"
            >
              <span>ACEITAR</span>
              <span className="text-sm">✓</span>
            </button>
          </div>
        </div>
      )}

      {/* 3.1 RADAR W-DRIVER: BUSCANDO CHAMADAS AUTORIZADAS PELA CENTRAL */}
      {isOnline && (!incomingRide || incomingRide.status === 'concluida' || incomingRide.status === 'cancelada') && (
        <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 text-center space-y-3 animate-fadeIn">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#1a2e05] border-2 border-[#a3e635] flex items-center justify-center relative">
            <span className="w-12 h-12 rounded-full border border-[#a3e635]/40 animate-ping absolute" />
            <Navigation className="w-7 h-7 text-[#a3e635] animate-pulse" />
          </div>
          <div>
            <h4 className="text-sm font-black text-white uppercase tracking-wider">
              Radar W-DRIVER Conectado
            </h4>
            <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
              Aguardando corridas autorizadas pela Central 24h de João Pessoa.
            </p>
          </div>
          <div className="p-2.5 rounded-2xl bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-400 flex items-center justify-center gap-2">
            <Shield className="w-4 h-4 text-[#a3e635] shrink-0" />
            <span>Bloqueio Anti-Calote Ativo: corridas só tocam após Pix confirmado pela Central</span>
          </div>
          {!demoCallActive && (
            <button
              type="button"
              onClick={() => setDemoCallActive(true)}
              className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-[11px] font-bold text-neutral-300 border border-neutral-700 transition-colors cursor-pointer"
            >
              Simular Chamada Teste Direta
            </button>
          )}
        </div>
      )}

      {/* ACTIVE ACCEPTED RIDE WORKFLOW */}
      {incomingRide && incomingRide.status !== 'despachada' && incomingRide.status !== 'concluida' && incomingRide.status !== 'cancelada' && (
        <div className="p-4 rounded-3xl bg-neutral-900 border-2 border-[#a3e635] shadow-[0_0_24px_rgba(163,230,53,0.2)] space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#a3e635] animate-pulse" />
              <span className="text-xs font-black text-white uppercase">
                {incomingRide.status === 'motorista_a_caminho' && '🚗 A Caminho do Passageiro'}
                {incomingRide.status === 'motorista_no_local' && '📍 No Local de Embarque'}
                {incomingRide.status === 'em_viagem' && '🚀 Viagem em Andamento'}
              </span>
            </div>
            <span className="text-xs font-black text-[#a3e635]">
              R$ {incomingRide.repasseMotorista.toFixed(2).replace('.', ',')} (90%)
            </span>
          </div>

          <div className="text-xs text-neutral-300">
            <strong>Passageiro:</strong> {incomingRide.passageiroNome}
          </div>

          {/* GPS Quick Launch */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleOpenGps('Google Maps', incomingRide.status === 'motorista_a_caminho' ? 'embarque' : 'completa')}
              className="py-2 px-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-blue-500/40 text-white text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
              <span>Google Maps</span>
            </button>
            <button
              onClick={() => handleOpenGps('Waze', incomingRide.status === 'motorista_a_caminho' ? 'embarque' : 'completa')}
              className="py-2 px-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-cyan-500/40 text-white text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              <span>Waze GPS</span>
            </button>
          </div>

          {/* Workflow Steps */}
          {incomingRide.status === 'motorista_a_caminho' && (
            <button
              onClick={() => onUpdateRideStatus(incomingRide.id, 'motorista_no_local')}
              className="w-full py-3 rounded-2xl bg-sky-500 hover:bg-sky-400 text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors"
            >
              📍 Cheguei ao Local de Embarque
            </button>
          )}

          {incomingRide.status === 'motorista_no_local' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs p-2.5 bg-neutral-950 rounded-2xl border border-neutral-800">
                <div>
                  <span className="text-neutral-400 font-bold block text-[10px] uppercase tracking-wider">Tempo de Espera no Embarque</span>
                  <span className="text-neutral-500 text-[10px]">Tolerância obrigatória de 3 minutos (180s)</span>
                </div>
                <span className="font-mono font-black text-[#a3e635] text-base">{formatTimer(secondsWaiting)}</span>
              </div>

              {/* VALIDAÇÃO DE PIN DE 4 DÍGITOS OBRIGATÓRIO */}
              <div className="p-3 bg-neutral-950 rounded-2xl border border-[#a3e635]/40 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-[#a3e635]" />
                    PIN Obrigatório de Embarque (4 dígitos)
                  </span>
                  <span className="text-[10px] text-neutral-400">Peça ao passageiro</span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={4}
                    value={pinInput}
                    onChange={(e) => {
                      setPinInput(e.target.value.replace(/\D/g, ''));
                      setPinError(null);
                    }}
                    placeholder="0000"
                    className="flex-1 px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-center text-lg font-mono font-black tracking-widest text-[#a3e635] outline-none focus:border-[#a3e635]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const expectedPin = incomingRide.pin || '4821';
                      if (pinInput.trim() === expectedPin) {
                        setPinError(null);
                        setPinInput('');
                        onUpdateRideStatus(incomingRide.id, 'em_viagem');
                      } else {
                        setPinError(`PIN incorreto! Peça o código de 4 dígitos exibido no celular do passageiro (ex: ${expectedPin}).`);
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer"
                  >
                    Validar PIN & Iniciar
                  </button>
                </div>
                {pinError && (
                  <p className="text-[11px] text-red-400 font-semibold">{pinError}</p>
                )}
              </div>

              {/* BOTÃO NO-SHOW APÓS 180 SEGUNDOS */}
              <button
                type="button"
                onClick={() => {
                  if (secondsWaiting > 0) {
                    alert(`O No-Show só é liberado após o término dos 3 minutos (180s) regulamentares de espera. Restam: ${formatTimer(secondsWaiting)}.`);
                    return;
                  }
                  setShowNoShowModal(true);
                }}
                className={`w-full py-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  secondsWaiting > 0
                    ? 'bg-neutral-900/60 border-neutral-800 text-neutral-500 cursor-not-allowed'
                    : 'bg-amber-500/20 border-amber-500/50 text-amber-300 hover:bg-amber-500/30 cursor-pointer shadow-lg'
                }`}
              >
                <Video className="w-4 h-4" />
                <span>
                  {secondsWaiting > 0
                    ? `Passageiro Ausente (Liberado em ${formatTimer(secondsWaiting)})`
                    : 'Passageiro Ausente (Gravar Vídeo 360°)'}
                </span>
              </button>
            </div>
          )}

          {incomingRide.status === 'em_viagem' && (
            <button
              onClick={handleFinishRide}
              className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-md"
            >
              🏁 Chegamos ao Destino (Concluir Viagem)
            </button>
          )}
        </div>
      )}

      {statusMessage && (
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-center text-xs text-neutral-300 font-bold">
          {statusMessage}
        </div>
      )}

      {/* 4. FUNCTIONAL GRID (5 cols x 2 rows = 10 buttons matching Image 3) */}
      <div className="grid grid-cols-5 gap-2 pt-1">
        {/* 1. Corridas */}
        <button
          type="button"
          onClick={() => setActiveFeature('corridas')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <Car className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Corridas</span>
        </button>

        {/* 2. Histórico */}
        <button
          type="button"
          onClick={() => setActiveFeature('historico')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <Clock className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Histórico</span>
        </button>

        {/* 3. Ganhos */}
        <button
          type="button"
          onClick={() => setActiveFeature('ganhos')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <DollarSign className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Ganhos</span>
        </button>

        {/* 4. Extrato */}
        <button
          type="button"
          onClick={() => setActiveFeature('extrato')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <FileText className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Extrato</span>
        </button>

        {/* 5. Avaliações */}
        <button
          type="button"
          onClick={() => setActiveFeature('avaliacoes')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <Star className="w-5 h-5 text-amber-400" />
          <span className="text-[9px] font-bold text-neutral-200">Avaliações</span>
        </button>

        {/* 6. Entregas */}
        <button
          type="button"
          onClick={() => setActiveFeature('entregas')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <Bike className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Entregas</span>
        </button>

        {/* 7. Objetos encontrados */}
        <button
          type="button"
          onClick={() => setActiveFeature('objetos')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <ShoppingBag className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[8px] font-bold text-neutral-200 leading-tight">Objetos</span>
        </button>

        {/* 8. Documentos */}
        <button
          type="button"
          onClick={() => setActiveFeature('documentos')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <FileCheck className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[8px] font-bold text-neutral-200 leading-tight">Docs</span>
        </button>

        {/* 9. Promoções */}
        <button
          type="button"
          onClick={() => setActiveFeature('promocoes')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <Megaphone className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Promoções</span>
        </button>

        {/* 10. Perfil */}
        <button
          type="button"
          onClick={() => setActiveFeature('perfil')}
          className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1 text-center transition-colors cursor-pointer"
        >
          <User className="w-5 h-5 text-[#a3e635]" />
          <span className="text-[9px] font-bold text-neutral-200">Perfil</span>
        </button>
      </div>

      {/* 5. BANNERS (Matching Image 3) */}
      <div className="space-y-2 pt-1">
        {/* Taxa da Plataforma */}
        <div 
          onClick={() => setActiveFeature('ganhos')}
          className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between cursor-pointer hover:border-neutral-700 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-2 h-2 rounded-full bg-[#a3e635]" />
            <span className="text-xs text-neutral-300 font-medium">
              Taxa da plataforma: <strong className="text-white">10% sobre o valor da corrida</strong>
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-500" />
        </div>

        {/* Dirija com segurança */}
        <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-[#a3e635] shrink-0" />
            <span className="text-[11px] text-neutral-400 font-medium leading-tight">
              Dirija com segurança! Respeite as leis de trânsito e cuide bem do passageiro.
            </span>
          </div>
        </div>

        {/* W-SOS EMERGENCY BANNER (Matching Image 3 red button) */}
        <button
          type="button"
          onClick={() => setShowSosModal(true)}
          className="w-full py-3 rounded-2xl bg-red-600 hover:bg-red-500 active:scale-98 text-white font-black text-xs uppercase tracking-wider shadow-[0_0_16px_rgba(239,68,68,0.4)] transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>W-SOS: Emergência / Central de apoio</span>
        </button>
      </div>

      {/* MODALS */}
      <DriverFeatureModal
        type={activeFeature}
        onClose={() => setActiveFeature(null)}
        rides={incomingRide ? [incomingRide] : []}
        onOpenWBank={onOpenWBank}
      />

      <SosModal
        isOpen={showSosModal}
        onClose={() => setShowSosModal(false)}
        userRole="motorista"
      />

      <NoShowVideoModal
        isOpen={showNoShowModal}
        onClose={() => setShowNoShowModal(false)}
        onConfirmNoShow={() => {
          setShowNoShowModal(false);
          if (incomingRide) onUpdateRideStatus(incomingRide.id, 'cancelada');
          setStatusMessage('🚨 Evidência 360° enviada à Central! Taxa de No-Show creditada no seu W-BANK.');
        }}
      />
    </div>
  );
};
