import React, { useState, useEffect, useRef } from 'react';
import { Camera, Upload, CheckCircle2, ShieldCheck, AlertCircle, RefreshCw } from 'lucide-react';

interface FounderOfficialPhotoProps {
  variant?: 'full' | 'compact' | 'avatar';
  className?: string;
}

const OFFICIAL_IMAGE_REF = 'file_0000000067c890cc6f2165d5419c2dc0.png';
const BACKUP_IMAGE_REF = 'file_00000000b67c820e85f216bdb413c2da.png';

export const getStoredFounderPhoto = (): string | null => {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('wdriver_founder_official_photo');
};

export const FounderOfficialPhoto: React.FC<FounderOfficialPhotoProps> = ({ 
  variant = 'full',
  className = '' 
}) => {
  const [photoUrl, setPhotoUrl] = useState<string>(() => {
    return getStoredFounderPhoto() || OFFICIAL_IMAGE_REF;
  });
  const [isDragging, setIsDragging] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const stored = getStoredFounderPhoto();
    if (stored) {
      setPhotoUrl(stored);
      return;
    }

    const handlePhotoUpdate = (e: CustomEvent<string>) => {
      setPhotoUrl(e.detail);
    };

    window.addEventListener('wdriver-founder-photo-updated', handlePhotoUpdate as EventListener);
    return () => {
      window.removeEventListener('wdriver-founder-photo-updated', handlePhotoUpdate as EventListener);
    };
  }, []);

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    const target = e.currentTarget;
    if (target.src.includes(OFFICIAL_IMAGE_REF)) {
      target.src = BACKUP_IMAGE_REF;
    } else if (target.src.includes(BACKUP_IMAGE_REF)) {
      target.src = '/founder_diego_official.png';
    }
  };

  const handleFileProcess = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione um arquivo de imagem válido (PNG, JPG ou WEBP).');
      return;
    }

    setIsSaving(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        // 1. Save to localStorage for persistent local display
        try {
          localStorage.setItem('wdriver_founder_official_photo', dataUrl);
        } catch (err) {
          console.warn('LocalStorage limit reached for image:', err);
        }

        setPhotoUrl(dataUrl);

        // 2. Broadcast to any other component in the window
        window.dispatchEvent(
          new CustomEvent('wdriver-founder-photo-updated', { detail: dataUrl })
        );

        // 3. Post to backend to persist to public/ folder
        try {
          await fetch('/api/upload-founder-photo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dataUrl }),
          });
        } catch (err) {
          console.error('Server save error:', err);
        }
      }
      setIsSaving(false);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileProcess(file);
    }
  };

  // 1. AVATAR VARIANT (used in compact headers and quick cards)
  if (variant === 'avatar') {
    return (
      <div className={`relative overflow-hidden rounded-full border-2 border-[#a3e635] shadow-md bg-neutral-900 ${className}`}>
        {photoUrl ? (
          <img
            src={photoUrl}
            alt="Diego Wallace de Lima Vasconcelos (Wollace Motorista)"
            className="w-full h-full object-cover object-top"
            referrerPolicy="no-referrer"
            onError={handleImageError}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-[#142607] text-[#a3e635] font-black text-xs">
            W
          </div>
        )}
      </div>
    );
  }

  // 2. COMPACT VARIANT
  if (variant === 'compact') {
    return (
      <div className={`space-y-2 ${className}`}>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
        <div className="relative rounded-2xl overflow-hidden border border-[#a3e635]/50 bg-neutral-950">
          {photoUrl ? (
            <img
              src={photoUrl}
              alt="Foto Oficial de Wollace Motorista"
              className="w-full h-48 object-cover object-top"
              referrerPolicy="no-referrer"
              onError={handleImageError}
            />
          ) : (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-48 flex flex-col items-center justify-center p-4 text-center cursor-pointer bg-neutral-900/90 hover:bg-neutral-800/80 transition-all border-2 border-dashed border-[#a3e635]/40"
            >
              <Camera className="w-8 h-8 text-[#a3e635] mb-2" />
              <p className="text-xs font-bold text-white">Carregar Foto Oficial Original</p>
              <p className="text-[10px] text-neutral-400 mt-1">Clique para selecionar</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // 3. FULL VARIANT (Main Biography Section)
  return (
    <div className={`space-y-3 ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {photoUrl ? (
        <div className="space-y-3">
          {/* Authentic Photo Frame */}
          <div className="relative rounded-3xl overflow-hidden border-2 border-[#a3e635] shadow-2xl bg-neutral-950 group">
            <div className="max-h-[460px] overflow-hidden flex items-center justify-center bg-black">
              <img
                src={photoUrl}
                alt="Diego Wallace de Lima Vasconcelos - Fundador Oficial W-DRIVER"
                className="w-full h-auto max-h-[460px] object-cover object-top"
                referrerPolicy="no-referrer"
                onError={handleImageError}
              />
            </div>

            {/* Official Overlay Badge */}
            <div className="absolute top-3 left-3 bg-black/85 backdrop-blur-md border border-[#a3e635]/60 text-white px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg">
              <CheckCircle2 className="w-4 h-4 text-[#a3e635]" />
              <span className="text-[11px] font-black uppercase tracking-wider text-[#a3e635]">
                Foto Oficial Original Auditada
              </span>
            </div>

            {/* Change Photo Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-3 right-3 bg-neutral-900/90 hover:bg-neutral-800 text-white border border-neutral-700 hover:border-[#a3e635] px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 transition-all shadow-md"
              title="Trocar ou atualizar foto oficial original"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#a3e635]" />
              <span>Atualizar Foto</span>
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
            <span className="flex items-center gap-1 text-[#a3e635] font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              Retrato Oficial Autêntico do Fundador Wollace Motorista
            </span>
            <span>João Pessoa - PB</span>
          </div>
        </div>
      ) : (
        /* UPLOAD CONTAINER WHEN NO PHOTO IS CONFIGURED YET */
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`p-6 sm:p-8 rounded-3xl border-2 border-dashed transition-all cursor-pointer text-center space-y-4 ${
            isDragging 
              ? 'border-[#a3e635] bg-[#142607]/40 shadow-xl' 
              : 'border-[#a3e635]/60 bg-neutral-900/90 hover:border-[#a3e635] hover:bg-neutral-900'
          }`}
        >
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#142607] border border-[#a3e635]/60 flex items-center justify-center text-[#a3e635] shadow-lg">
            <Camera className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-[#a3e635]/60 text-[#a3e635] text-[11px] font-black uppercase">
              <ShieldCheck className="w-3.5 h-3.5" />
              Foto Oficial & Original do Fundador
            </div>
            <h3 className="text-base sm:text-lg font-black text-white">
              Anexe aqui a sua imagem oficial original
            </h3>
            <p className="text-xs text-neutral-400 max-w-md mx-auto">
              Nenhuma imagem fictícia ou sintética será usada. Clique para selecionar ou arraste o seu arquivo original direto do computador ou celular.
            </p>
          </div>

          <div className="pt-2">
            <button
              type="button"
              disabled={isSaving}
              className="px-6 py-3 rounded-2xl bg-[#a3e635] hover:bg-[#8cee18] text-neutral-950 font-black text-xs sm:text-sm uppercase tracking-wider inline-flex items-center gap-2 shadow-lg hover:shadow-[#a3e635]/20 transition-all cursor-pointer"
            >
              <Upload className="w-4 h-4 text-neutral-950" />
              <span>{isSaving ? 'Carregando Foto...' : 'Selecionar Foto Oficial Original'}</span>
            </button>
          </div>

          <div className="text-[10px] text-neutral-500 flex items-center justify-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>Formatos aceitos: PNG, JPG ou WEBP de qualquer resolução</span>
          </div>
        </div>
      )}
    </div>
  );
};
