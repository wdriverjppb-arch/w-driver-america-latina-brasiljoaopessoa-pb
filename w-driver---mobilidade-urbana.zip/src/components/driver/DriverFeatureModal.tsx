import React, { useState } from 'react';
import { 
  X, Car, Clock, DollarSign, FileText, Star, Bike, ShoppingBag, 
  FileCheck, Megaphone, User, CheckCircle2, Shield, Upload, 
  Smartphone, ChevronRight, Award, Wallet
} from 'lucide-react';
import { RideData } from '../../types';

export type DriverFeatureType = 
  | 'corridas'
  | 'historico'
  | 'ganhos'
  | 'extrato'
  | 'avaliacoes'
  | 'entregas'
  | 'objetos'
  | 'documentos'
  | 'promocoes'
  | 'perfil';

interface DriverFeatureModalProps {
  type: DriverFeatureType | null;
  onClose: () => void;
  rides: RideData[];
  driverName?: string;
  driverVehicle?: string;
  driverPlate?: string;
  driverRating?: number;
  onOpenWBank?: () => void;
}

export const DriverFeatureModal: React.FC<DriverFeatureModalProps> = ({
  type,
  onClose,
  rides,
  driverName = 'Carlos E. da Silva',
  driverVehicle = 'Toyota Corolla XEi • 2023',
  driverPlate = 'QFA-9921',
  driverRating = 4.95,
  onOpenWBank,
}) => {
  const [objetoDesc, setObjetoDesc] = useState('');
  const [objetoSaved, setObjetoSaved] = useState(false);

  if (!type) return null;

  const completedRides = rides.filter((r) => r.status === 'concluida');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635]">
              {type === 'corridas' && <Car className="w-4 h-4" />}
              {type === 'historico' && <Clock className="w-4 h-4" />}
              {type === 'ganhos' && <DollarSign className="w-4 h-4" />}
              {type === 'extrato' && <FileText className="w-4 h-4" />}
              {type === 'avaliacoes' && <Star className="w-4 h-4" />}
              {type === 'entregas' && <Bike className="w-4 h-4" />}
              {type === 'objetos' && <ShoppingBag className="w-4 h-4" />}
              {type === 'documentos' && <FileCheck className="w-4 h-4" />}
              {type === 'promocoes' && <Megaphone className="w-4 h-4" />}
              {type === 'perfil' && <User className="w-4 h-4" />}
            </span>
            <div>
              <h3 className="text-sm font-black text-white capitalize">
                {type === 'corridas' && 'Central de Corridas'}
                {type === 'historico' && 'Histórico de Viagens'}
                {type === 'ganhos' && 'Painel de Ganhos & Repasses'}
                {type === 'extrato' && 'Extrato Financeiro'}
                {type === 'avaliacoes' && 'Avaliações dos Passageiros'}
                {type === 'entregas' && 'Central de Entregas W-DRIVER'}
                {type === 'objetos' && 'Objetos Encontrados'}
                {type === 'documentos' && 'Meus Documentos & Status'}
                {type === 'promocoes' && 'Promoções & Metas da Semana'}
                {type === 'perfil' && 'Perfil do Motorista Credenciado'}
              </h3>
              <p className="text-[11px] text-neutral-400">
                W-DRIVER Mobilidade • João Pessoa - PB
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-xl bg-neutral-900 text-neutral-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 1. CORRIDAS */}
        {type === 'corridas' && (
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
              <span className="text-neutral-400">Corridas disponíveis na região:</span>
              <div className="text-base font-bold text-white">João Pessoa (Orla & Zona Sul)</div>
              <span className="text-[10px] text-[#a3e635]">⚡ Alta demanda na Torre, Bancários e Bessa</span>
            </div>

            <div className="space-y-2">
              {rides.length === 0 ? (
                <div className="p-6 text-center text-neutral-500 text-xs">
                  Nenhuma corrida ativa no momento. Mantenha o status ONLINE para receber novas chamadas sonoras.
                </div>
              ) : (
                rides.slice(0, 5).map((r) => (
                  <div key={r.id} className="p-3 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{r.categoria.name}</span>
                      <span className="text-[#a3e635] font-black">R$ {r.repasseMotorista.toFixed(2).replace('.', ',')}</span>
                    </div>
                    <div className="text-[11px] text-neutral-400">De: {r.origem}</div>
                    <div className="text-[11px] text-neutral-400">Para: {r.destino}</div>
                    <div className="flex items-center justify-between pt-1">
                      <span className="px-2 py-0.5 rounded bg-neutral-800 text-[9px] text-neutral-300 font-bold uppercase">
                        {r.status.replace(/_/g, ' ')}
                      </span>
                      <span className="text-[10px] text-neutral-500">{r.distanciaKm.toFixed(1)} km</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* 2. HISTÓRICO */}
        {type === 'historico' && (
          <div className="space-y-2 text-xs">
            {completedRides.length === 0 ? (
              <div className="p-6 text-center text-neutral-500">
                Histórico recente consolidado. Suas corridas finalizadas serão catalogadas aqui com recibo digital e valor líquido repassado.
              </div>
            ) : (
              completedRides.map((r) => (
                <div key={r.id} className="p-3 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs">{r.destino}</span>
                    <span className="text-[#a3e635] font-black">R$ {r.repasseMotorista.toFixed(2).replace('.', ',')}</span>
                  </div>
                  <div className="text-[10px] text-neutral-400">{r.origem} • {r.criadoEm}</div>
                  <div className="text-[10px] text-emerald-400 flex items-center gap-1 font-semibold">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>90% Creditado no W-BANK</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* 3. GANHOS */}
        {type === 'ganhos' && (
          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
                <span className="text-[10px] text-neutral-400 uppercase font-bold block">Hoje</span>
                <div className="text-base font-black text-[#a3e635]">R$ 215,60</div>
                <span className="text-[9px] text-neutral-500 font-medium">7 corridas</span>
              </div>
              <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
                <span className="text-[10px] text-neutral-400 uppercase font-bold block">Semana</span>
                <div className="text-base font-black text-[#a3e635]">R$ 1.256,40</div>
                <span className="text-[9px] text-neutral-500 font-medium">42 corridas</span>
              </div>
              <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
                <span className="text-[10px] text-neutral-400 uppercase font-bold block">Mês</span>
                <div className="text-base font-black text-[#a3e635]">R$ 4.890,00</div>
                <span className="text-[9px] text-neutral-500 font-medium">168 corridas</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between text-neutral-300">
                <span>Repasse Líquido ao Motorista:</span>
                <span className="font-black text-[#a3e635]">90,0%</span>
              </div>
              <div className="flex items-center justify-between text-neutral-400 text-[11px]">
                <span>Taxa da Plataforma W-DRIVER:</span>
                <span>10,0%</span>
              </div>
              <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
                <span className="text-neutral-400">Saldo W-BANK disponível para saque PIX:</span>
                <span className="text-sm font-black text-white">R$ 380,50</span>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                if (onOpenWBank) onOpenWBank();
              }}
              className="w-full py-3 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
            >
              <Wallet className="w-4 h-4" />
              <span>Acessar Carteira Digital W-BANK</span>
            </button>
          </div>
        )}

        {/* 4. EXTRATO */}
        {type === 'extrato' && (
          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-neutral-400 block">Saldo Total em Conta</span>
                <span className="text-lg font-black text-white">R$ 380,50</span>
              </div>
              <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-bold">
                Livre para PIX
              </span>
            </div>

            <div className="space-y-1.5">
              {[
                { desc: 'Repasse Corrida W-CARRO #8921', val: '+ R$ 22,50', date: 'Hoje, 14:32', type: 'in' },
                { desc: 'Repasse Corrida W-MOTO #8918', val: '+ R$ 8,10', date: 'Hoje, 13:10', type: 'in' },
                { desc: 'Saque PIX para Banco do Brasil', val: '- R$ 150,00', date: 'Ontem, 19:40', type: 'out' },
                { desc: 'Repasse Corrida W-CARRO #8890', val: '+ R$ 34,20', date: 'Ontem, 18:05', type: 'in' },
              ].map((tx, idx) => (
                <div key={idx} className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white text-xs">{tx.desc}</div>
                    <div className="text-[10px] text-neutral-500">{tx.date}</div>
                  </div>
                  <span className={`font-mono font-bold text-xs ${tx.type === 'in' ? 'text-[#a3e635]' : 'text-red-400'}`}>
                    {tx.val}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. AVALIAÇÕES */}
        {type === 'avaliacoes' && (
          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 text-center space-y-1">
              <div className="text-3xl font-black text-amber-400 flex items-center justify-center gap-1">
                <span>{driverRating.toFixed(2)}</span>
                <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
              </div>
              <div className="text-neutral-400 text-xs">Excelente avaliação baseada em 184 viagens</div>
            </div>

            <div className="space-y-2">
              {[
                { name: 'Mariana Silva', nota: 5, comment: 'Carro muito limpo, ar-condicionado excelente e condução super segura!' },
                { name: 'Lucas Pereira', nota: 5, comment: 'Chegou rápido no Bessa e foi muito educado. Nota 10!' },
                { name: 'Fernanda Costa', nota: 5, comment: 'Ótima rota sem trânsito. W-DRIVER é o melhor app de JP.' },
              ].map((av, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs">{av.name}</span>
                    <div className="flex text-amber-400">
                      {'★'.repeat(av.nota)}
                    </div>
                  </div>
                  <p className="text-[11px] text-neutral-400">{av.comment}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. ENTREGAS */}
        {type === 'entregas' && (
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="font-bold text-white text-xs">W-ENTREGAS EXPRESSAS</div>
              <p className="text-[11px] text-neutral-400">
                Transporte de encomendas leves, documentos e compras com confirmação por código de segurança de 4 dígitos.
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-center text-neutral-400 space-y-2">
              <Bike className="w-8 h-8 text-[#a3e635] mx-auto" />
              <div className="font-bold text-white text-xs">Modo Entregas Habilitado</div>
              <p className="text-[10px] text-neutral-500">
                Você pode receber entregas de restaurantes e farmácias conveniadas diretamente no radar.
              </p>
            </div>
          </div>
        )}

        {/* 7. OBJETOS ENCONTRADOS */}
        {type === 'objetos' && (
          <div className="space-y-3 text-xs">
            {objetoSaved ? (
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <div className="font-bold text-white">Item Registrado com Sucesso!</div>
                <p className="text-[11px] text-neutral-300">
                  A Central W-DRIVER associará o item ao último passageiro e intermediará a devolução segura.
                </p>
                <button
                  onClick={() => setObjetoSaved(false)}
                  className="px-3 py-1.5 rounded-xl bg-neutral-800 text-white font-bold"
                >
                  Registrar Outro
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-neutral-400 text-xs">
                  Encontrou algum pertence esquecido por um passageiro? Registre aqui para que a Central notifique o dono.
                </p>
                <textarea
                  value={objetoDesc}
                  onChange={(e) => setObjetoDesc(e.target.value)}
                  placeholder="Descreva o objeto (ex: Carteira marrom, chaves com chaveiro do Botafogo-PB...)"
                  rows={3}
                  className="w-full py-2 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white outline-none"
                />
                <button
                  onClick={() => {
                    if (!objetoDesc.trim()) return;
                    setObjetoSaved(true);
                  }}
                  className="w-full py-2.5 rounded-xl bg-[#a3e635] text-neutral-950 font-black uppercase tracking-wider"
                >
                  Registrar Item Achado
                </button>
              </div>
            )}
          </div>
        )}

        {/* 8. DOCUMENTOS */}
        {type === 'documentos' && (
          <div className="space-y-2 text-xs">
            {[
              { doc: 'CNH com Remuneração (EAR)', status: 'Aprovado & Válido', date: 'Vencimento: 2028' },
              { doc: 'CRLV do Veículo', status: 'Aprovado & Licenciado', date: 'Exercício 2025' },
              { doc: 'Certidão Negativa de Antecedentes', status: 'Auditada pela Central', date: 'Emissão: 2026' },
              { doc: 'Comprovante de Residência (João Pessoa)', status: 'Auditado & Confirmado', date: 'Torre, JPA' },
            ].map((d, idx) => (
              <div key={idx} className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs">{d.doc}</div>
                  <div className="text-[10px] text-neutral-500">{d.date}</div>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                  {d.status}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* 9. PROMOÇÕES & METAS */}
        {type === 'promocoes' && (
          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#142607] to-neutral-900 border border-[#a3e635]/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-black text-white text-xs">Meta Semanal Turbo</span>
                <span className="px-2 py-0.5 rounded bg-[#a3e635] text-neutral-950 text-[10px] font-black">+ R$ 100,00</span>
              </div>
              <p className="text-[11px] text-neutral-300">
                Complete 35 viagens entre segunda e domingo em João Pessoa e receba bônus de R$ 100,00 direto no W-BANK.
              </p>
              <div className="w-full bg-neutral-950 rounded-full h-2 overflow-hidden">
                <div className="bg-[#a3e635] h-full" style={{ width: '70%' }} />
              </div>
              <div className="text-right text-[10px] text-neutral-400">25 / 35 viagens concluídas (71%)</div>
            </div>
          </div>
        )}

        {/* 10. PERFIL */}
        {type === 'perfil' && (
          <div className="space-y-3 text-xs">
            <div className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-900 border border-neutral-800">
              <div className="w-12 h-12 rounded-2xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center text-xl text-[#a3e635] font-black">
                {driverName.charAt(0)}
              </div>
              <div>
                <div className="font-black text-white text-sm">{driverName}</div>
                <div className="text-[11px] text-neutral-400">{driverVehicle} • Placa {driverPlate}</div>
                <div className="text-[10px] text-[#a3e635] font-bold">⭐ {driverRating.toFixed(2)} Motorista VIP</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
              <div className="text-neutral-400 text-[10px] uppercase font-bold">Chave PIX Cadastrada para Saques:</div>
              <div className="text-white font-mono font-semibold text-xs">carlos.motorista@wdriver.com.br</div>
            </div>
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs transition-colors cursor-pointer"
        >
          Fechar
        </button>
      </div>
    </div>
  );
};
