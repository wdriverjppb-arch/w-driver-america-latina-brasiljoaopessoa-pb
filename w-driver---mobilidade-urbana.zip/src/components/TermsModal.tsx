import React from 'react';
import { X, ShieldCheck, FileText, Lock, Video, AlertOctagon } from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-lg bg-[#121212] border border-[#b2ec5d] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-[#000000] px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#b2ec5d]" />
            <h3 className="text-sm font-black text-[#b2ec5d] uppercase tracking-wider">
              Termos de Uso e Normas W-DRIVER
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-neutral-300 leading-relaxed">
          <div className="p-3 bg-neutral-950/80 border border-neutral-800 rounded-xl">
            <p className="font-semibold text-neutral-200">
              W-DRIVER AMÉRICA LATINA BRASIL — Sistema Blindado Anti-Fraude e Anti-Calote
            </p>
            <p className="text-[11px] text-neutral-400 mt-1">
              Plataforma com validação biométrica facial, documentos oficiais, certidões de antecedentes e assinatura digital via gov.br.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-sm">
              <FileText className="w-4 h-4 text-[#b2ec5d]" />
              1. Aceitação dos Termos e Condições
            </h4>
            <p className="text-neutral-400 text-[11px]">
              Ao se cadastrar e utilizar a plataforma W-DRIVER América Latina Brasil, tanto o passageiro quanto o motorista parceiro concordam integralmente com todas as normas operacionais, regras de segurança, compliance e antifraude estipuladas pela Central de Monitoramento 24h.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-sm">
              <Lock className="w-4 h-4 text-[#b2ec5d]" />
              2. Sistema Anti-Calote e W-BANK
            </h4>
            <p className="text-neutral-400 text-[11px]">
              Todas as solicitações de transporte e entregas exigem pré-pagamento ou garantia digital de crédito via carteira W-BANK. É estritamente vedada a recusa de pagamento ou fraudes de cancelamento intencional, sob pena de bloqueio definitivo de CPF, IMEI do aparelho e envio imediato de dados para responsabilização jurídica.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-sm">
              <ShieldCheck className="w-4 h-4 text-[#b2ec5d]" />
              3. Validação Biométrica e Documental Obrigatória
            </h4>
            <p className="text-neutral-400 text-[11px]">
              O acesso à plataforma requer o envio de documentação oficial válida (RG ou CNH com EAR para condutores), atestados de antecedentes criminais nas esferas estadual e federal, captura de selfie facial com prova de vida biométrica e assinatura digital autenticada através do portal gov.br.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-sm">
              <Video className="w-4 h-4 text-[#b2ec5d]" />
              4. Segurança, Cronômetro de 3 Min e Monitoramento 360°
            </h4>
            <p className="text-neutral-400 text-[11px]">
              Em caso de ausência do passageiro no ponto de partida após o tempo regulamentar de 03:00 minutos de espera, o motorista parceiro deverá acionar a gravação de vídeo 360° ao redor do veículo para comprovação de No-Show, garantindo o crédito integral da taxa compensatória no W-BANK e auditoria da Central.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#000000] px-5 py-3 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#b2ec5d] hover:bg-[#9ecf4c] text-neutral-950 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            Entendido e Concordo
          </button>
        </div>
      </div>
    </div>
  );
};
