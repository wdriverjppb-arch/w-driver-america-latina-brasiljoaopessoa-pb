import React from 'react';
import { ArrowLeft, Wind, UserCheck, ShieldCheck, ArrowRight } from 'lucide-react';
import { CategoryInfo } from '../types';
import { VehicleGraphic } from './VehicleGraphic';

interface CategoryDetailModalProps {
  category: CategoryInfo;
  distanciaKm: number;
  calculatedFare: number;
  onClose: () => void;
  onConfirm: () => void;
}

export const CategoryDetailModal: React.FC<CategoryDetailModalProps> = ({
  category,
  distanciaKm,
  calculatedFare,
  onClose,
  onConfirm,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-gradient-to-b from-[#0c1308] via-[#090d06] to-[#060805] border border-[#a3e635]/40 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800/80 bg-neutral-950">
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <VehicleGraphic type={category.iconType} size="sm" />
            <span className="text-sm font-black text-white">{category.name}</span>
          </div>
          <div className="w-8" />
        </div>

        {/* Content Body */}
        <div className="p-5 flex flex-col items-center text-center space-y-4 max-h-[85vh] overflow-y-auto">
          <p className="text-xs text-neutral-400 font-medium">
            Conforto e segurança para o seu dia a dia.
          </p>

          {/* Large Vehicle Graphic */}
          <div className="py-2 transform scale-110">
            <VehicleGraphic type={category.iconType} size="lg" />
          </div>

          <div className="px-4 py-1.5 rounded-full bg-neutral-900 border border-neutral-700 text-xs font-bold text-[#a3e635]">
            Categoria {category.tag || 'Oficial'}
          </div>

          {/* Tarifa Card (Exact match with user screenshot) */}
          <div className="w-full p-4 rounded-2xl bg-neutral-950 border border-neutral-800 text-left space-y-2">
            <span className="text-[10px] text-neutral-400 font-extrabold uppercase tracking-wider block">
              Tarifa
            </span>
            <div className="grid grid-cols-2 gap-3 pt-1 border-t border-neutral-800/80">
              <div>
                <span className="text-[11px] text-neutral-400 block">Fixo (até 4 km)</span>
                <strong className="text-lg font-black text-[#a3e635]">
                  R$ {category.baseFare.toFixed(2).replace('.', ',')}
                </strong>
              </div>
              <div className="border-l border-neutral-800 pl-3">
                <span className="text-[11px] text-neutral-400 block">Km adicional</span>
                <strong className="text-lg font-black text-[#a3e635]">
                  R$ {category.kmAdicional.toFixed(2).replace('.', ',')}
                </strong>
              </div>
            </div>
          </div>

          {/* 3 Value Proposition Badges */}
          <div className="w-full grid grid-cols-3 gap-2">
            <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1.5">
              <Wind className="w-5 h-5 text-[#a3e635]" />
              <span className="text-[10px] text-neutral-300 font-semibold leading-tight">
                Ar-condicionado
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1.5">
              <UserCheck className="w-5 h-5 text-[#a3e635]" />
              <span className="text-[10px] text-neutral-300 font-semibold leading-tight">
                Motorista profissional
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1.5">
              <ShieldCheck className="w-5 h-5 text-[#a3e635]" />
              <span className="text-[10px] text-neutral-300 font-semibold leading-tight">
                Viagem segura
              </span>
            </div>
          </div>

          {/* Resumo da rota calculada */}
          <div className="w-full p-3.5 rounded-2xl bg-[#122209] border border-[#a3e635]/30 flex items-center justify-between text-left">
            <div>
              <span className="text-[10px] text-neutral-400 block">Distância: {distanciaKm.toFixed(1)} km</span>
              <div className="text-base font-black text-white">
                Estimado: <span className="text-[#a3e635]">R$ {calculatedFare.toFixed(2).replace('.', ',')}</span>
              </div>
            </div>
            <span className="text-[10px] text-[#a3e635] bg-[#1a2e05] px-2.5 py-1 rounded-full border border-[#a3e635]/40 font-bold">
              ~ {category.etaMins} min
            </span>
          </div>

          {/* Botão Solicitar agora -> */}
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="w-full py-4 px-6 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(163,230,53,0.4)] transition-all cursor-pointer"
          >
            <span>Solicitar agora</span>
            <ArrowRight className="w-4 h-4 stroke-[3]" />
          </button>
        </div>
      </div>
    </div>
  );
};
