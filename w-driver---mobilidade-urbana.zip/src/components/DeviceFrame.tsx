import React from 'react';
import { Smartphone, Monitor, Wifi, Battery, Signal } from 'lucide-react';

interface DeviceFrameProps {
  children: React.ReactNode;
  isMobileFrame: boolean;
  onToggleFrame: () => void;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({
  children,
  isMobileFrame,
  onToggleFrame,
}) => {
  return (
    <div className="w-full flex flex-col items-center">
      {/* Top Bar Switcher */}
      <div className="w-full max-w-5xl mb-4 flex items-center justify-between px-4 py-2 rounded-2xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-pulse" />
          <span className="font-semibold text-neutral-300">W-DRIVER Mobilidade Urbana</span>
          <span className="hidden sm:inline text-neutral-600">|</span>
          <span className="hidden sm:inline text-neutral-500">João Pessoa - PB</span>
        </div>

        <button
          onClick={onToggleFrame}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-bold transition-colors"
        >
          {isMobileFrame ? (
            <>
              <Monitor className="w-3.5 h-3.5 text-[#a3e635]" />
              <span>Expandir Layout Completo</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3.5 h-3.5 text-[#a3e635]" />
              <span>Visualizar no iPhone Mockup</span>
            </>
          )}
        </button>
      </div>

      {isMobileFrame ? (
        /* iPhone Mockup Frame */
        <div className="relative w-full max-w-[400px] rounded-[52px] p-3 bg-[#171717] border-[6px] border-[#2c2c2e] shadow-[0_25px_70px_rgba(0,0,0,0.85)] ring-1 ring-white/10">
          {/* Dynamic Island / Speaker notch */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-50 flex items-center justify-end px-3">
            <div className="w-2.5 h-2.5 rounded-full bg-[#111] border border-neutral-700" />
          </div>

          {/* Status Bar */}
          <div className="w-full px-6 pt-2 pb-1 flex justify-between items-center text-white text-[11px] font-bold z-40 select-none">
            <span>21:57</span>
            <div className="flex items-center gap-1.5 text-white">
              <Signal className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-4 h-4 fill-white" />
            </div>
          </div>

          {/* Screen Content */}
          <div className="rounded-[40px] overflow-hidden bg-[#0a0a0a]">
            {children}
          </div>

          {/* Home indicator bar at bottom */}
          <div className="w-32 h-1 bg-neutral-500 rounded-full mx-auto my-2 opacity-60" />
        </div>
      ) : (
        /* Full Desktop / Responsive Layout Container */
        <div className="w-full max-w-6xl animate-fadeIn">
          {children}
        </div>
      )}
    </div>
  );
};
