import React, { useState, useRef, useEffect } from 'react';
import { 
  Lock, Mail, Key, Eye, EyeOff, ShieldCheck, AlertTriangle, 
  CheckCircle2, ArrowRight, RefreshCw, Sparkles, Send, ShieldAlert, X,
  Camera, Mic, Siren, Radio, AlertOctagon, UserX, Volume2
} from 'lucide-react';
import { WDriverLogo } from './WDriverLogo';

interface CentralAuthGateProps {
  isAuthenticated: boolean;
  onLoginSuccess: () => void;
  onLogout: () => void;
  children: React.ReactNode;
}

const OFFICIAL_ADMIN_EMAIL = 'wdriveroficial@gmail.com';
const STORAGE_KEY_MASTER_PWD = 'wdriver_admin_master_pwd';

export const CentralAuthGate: React.FC<CentralAuthGateProps> = ({
  isAuthenticated,
  onLoginSuccess,
  onLogout,
  children,
}) => {
  const [emailInput, setEmailInput] = useState(OFFICIAL_ADMIN_EMAIL);
  const [passwordInput, setPasswordInput] = useState('');
  
  // Verifica se a senha já foi configurada pelo administrador
  const [isPasswordConfigured, setIsPasswordConfigured] = useState(() => {
    return Boolean(localStorage.getItem(STORAGE_KEY_MASTER_PWD));
  });

  // Campos para a configuração inicial da senha
  const [setupPassword, setSetupPassword] = useState('');
  const [setupPasswordConfirm, setSetupPasswordConfirm] = useState('');
  const [setupError, setSetupError] = useState<string | null>(null);

  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Anti-Invasion System States
  const [isAntiIntrusionActive, setIsAntiIntrusionActive] = useState(false);
  const [intruderData, setIntruderData] = useState<{
    emailAttempt: string;
    timestamp: string;
    ipSimulated: string;
    location: string;
    protocolNumber: string;
  } | null>(null);
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [hasCameraAccess, setHasCameraAccess] = useState<boolean | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Recovery modal states
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState(OFFICIAL_ADMIN_EMAIL);
  const [recoveryStep, setRecoveryStep] = useState<'input_email' | 'enter_code' | 'success'>('input_email');
  const [generatedCode, setGeneratedCode] = useState('');
  const [typedCode, setTypedCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [recoveryError, setRecoveryError] = useState<string | null>(null);
  const [recoverySuccessMessage, setRecoverySuccessMessage] = useState<string | null>(null);
  const [isSendingCode, setIsSendingCode] = useState(false);

  // Clean up media stream when component unmounts or anti-invasion closes
  useEffect(() => {
    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [mediaStream]);

  // Connect video stream to video element when active
  useEffect(() => {
    if (isAntiIntrusionActive && videoRef.current && mediaStream) {
      videoRef.current.srcObject = mediaStream;
      videoRef.current.play().catch(() => {});
    }
  }, [isAntiIntrusionActive, mediaStream]);

  const playSecuritySiren = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sawtooth';
      const now = audioCtx.currentTime;
      osc.frequency.setValueAtTime(900, now);
      osc.frequency.linearRampToValueAtTime(450, now + 0.3);
      osc.frequency.linearRampToValueAtTime(900, now + 0.6);
      osc.frequency.linearRampToValueAtTime(450, now + 0.9);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.linearRampToValueAtTime(0, now + 1.2);

      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(now + 1.2);
    } catch {
      // Audio context might be restricted before user interaction
    }
  };

  const triggerAntiIntrusion = (attemptedEmail: string) => {
    playSecuritySiren();

    const timestamp = new Date().toLocaleString('pt-BR');
    const protocolNumber = `INC-${Math.floor(100000 + Math.random() * 900000)}/PB`;
    setIntruderData({
      emailAttempt: attemptedEmail,
      timestamp,
      ipSimulated: '187.19.142.88 (Provedor Paraíba Telecom)',
      location: 'João Pessoa, PB (Lat -7.1153, Long -34.8610)',
      protocolNumber,
    });
    setIsAntiIntrusionActive(true);

    // Request camera and microphone to capture visual evidence
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: 'user' }, audio: true })
        .then((stream) => {
          setMediaStream(stream);
          setHasCameraAccess(true);
        })
        .catch(() => {
          // If audio was denied or failed, try video only
          navigator.mediaDevices
            .getUserMedia({ video: { facingMode: 'user' } })
            .then((stream) => {
              setMediaStream(stream);
              setHasCameraAccess(true);
            })
            .catch(() => {
              setHasCameraAccess(false);
            });
        });
    } else {
      setHasCameraAccess(false);
    }
  };

  const closeAntiIntrusion = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach((track) => track.stop());
      setMediaStream(null);
    }
    setIsAntiIntrusionActive(false);
    setErrorMessage('⚠️ Tentativa de invasão bloqueada. Apenas o fundador oficial possui acesso.');
  };

  const handleInitialSetup = (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError(null);

    if (setupPassword.length < 6) {
      setSetupError('A senha master deve conter pelo menos 6 caracteres.');
      return;
    }

    if (setupPassword !== setupPasswordConfirm) {
      setSetupError('As senhas digitadas não coincidem.');
      return;
    }

    localStorage.setItem(STORAGE_KEY_MASTER_PWD, setupPassword);
    setIsPasswordConfigured(true);
    setPasswordInput(setupPassword);
    onLoginSuccess();
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanEmail = emailInput.trim().toLowerCase();

    // Verificação de E-mail não autorizado -> Dispara Sistema Anti-Invasão
    if (cleanEmail !== OFFICIAL_ADMIN_EMAIL.toLowerCase()) {
      triggerAntiIntrusion(emailInput);
      return;
    }

    const savedMasterPwd = localStorage.getItem(STORAGE_KEY_MASTER_PWD) || '';

    // Verificação de Senha incorreta -> Dispara Sistema Anti-Invasão
    if (!savedMasterPwd || passwordInput !== savedMasterPwd) {
      triggerAntiIntrusion(emailInput);
      return;
    }

    onLoginSuccess();
  };

  const handleRequestCode = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    const cleanEmail = recoveryEmail.trim().toLowerCase();

    // TRAVA DE SEGURANÇA ESTRITA: Somente wdriveroficial@gmail.com pode recuperar a senha
    if (cleanEmail !== OFFICIAL_ADMIN_EMAIL.toLowerCase()) {
      setRecoveryError(
        `🚫 RECUPERAÇÃO BLOQUEADA: A função de redefinição é restrita exclusivamente ao e-mail oficial: ${OFFICIAL_ADMIN_EMAIL}. Qualquer tentativa com outros e-mails é bloqueada pelo sistema.`
      );
      return;
    }

    setIsSendingCode(true);

    setTimeout(() => {
      setIsSendingCode(false);
      const code = `WD-${Math.floor(100000 + Math.random() * 900000)}`;
      setGeneratedCode(code);
      setRecoveryStep('enter_code');
      setRecoverySuccessMessage(`Código de verificação enviado com sucesso para ${OFFICIAL_ADMIN_EMAIL}!`);
    }, 1200);
  };

  const handleConfirmNewPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError(null);

    if (typedCode.trim().toUpperCase() !== generatedCode.toUpperCase()) {
      setRecoveryError('Código de segurança incorreto. Verifique o código recebido no e-mail.');
      return;
    }

    if (newPassword.length < 6) {
      setRecoveryError('A nova senha deve ter no mínimo 6 caracteres.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setRecoveryError('As senhas digitadas não coincidem.');
      return;
    }

    // Atualiza a senha master no armazenamento local seguro
    localStorage.setItem(STORAGE_KEY_MASTER_PWD, newPassword);
    setIsPasswordConfigured(true);
    setPasswordInput(newPassword);
    setRecoveryStep('success');

    setTimeout(() => {
      setShowRecoveryModal(false);
      setRecoveryStep('input_email');
      setRecoverySuccessMessage(null);
      onLoginSuccess();
    }, 1800);
  };

  // Se já autenticado, renderiza a Central com barra de status e botão de Logout
  if (isAuthenticated) {
    return (
      <div className="w-full space-y-4">
        {/* BANNER DE SESSÃO SEGURA DO ADMINISTRADOR */}
        <div className="bg-[#121c0b] border border-[#a3e635]/40 rounded-2xl p-3 px-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#1c300c] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-neutral-400 font-extrabold uppercase tracking-wider block">
                Central de Operações 24h • Sessão Autenticada
              </span>
              <strong className="text-xs text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-pulse" />
                {OFFICIAL_ADMIN_EMAIL}
              </strong>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-[#a3e635] bg-[#1a2e05] px-2.5 py-1 rounded-full border border-[#a3e635]/40 font-bold hidden sm:inline-block">
              Acesso Diretor Master (Diego Wallace)
            </span>
            <button
              onClick={onLogout}
              className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-red-950/60 text-neutral-300 hover:text-red-300 border border-neutral-800 hover:border-red-800/60 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Bloquear Central</span>
            </button>
          </div>
        </div>

        {children}
      </div>
    );
  }

  // TELA DE CONFIGURAÇÃO INICIAL DA SENHA MASTER (SEM SENHA FIXA NO CÓDIGO)
  if (!isPasswordConfigured) {
    return (
      <div className="w-full max-w-md mx-auto py-8 animate-fadeIn">
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-[#121f0a] via-neutral-900 to-neutral-950 border border-[#a3e635]/40 shadow-2xl space-y-6">
          <div className="text-center space-y-3">
            <div className="flex justify-center">
              <WDriverLogo size="lg" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#182907] border border-[#a3e635]/40 text-[#a3e635] text-[11px] font-black uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Configuração Inicial do Administrador</span>
            </div>
            <h1 className="text-xl font-black text-white">
              Crie sua Senha Master
            </h1>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Nenhuma senha padrão vem gravada no código. Defina agora sua senha de acesso exclusivo para <strong className="text-[#a3e635]">{OFFICIAL_ADMIN_EMAIL}</strong>.
            </p>
          </div>

          {setupError && (
            <div className="p-3 rounded-2xl bg-red-950/50 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{setupError}</span>
            </div>
          )}

          <form onSubmit={handleInitialSetup} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-neutral-300 block mb-1">
                E-mail Oficial da Presidência:
              </label>
              <input
                type="email"
                readOnly
                value={OFFICIAL_ADMIN_EMAIL}
                className="w-full px-3.5 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-neutral-400 text-xs font-mono select-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-neutral-300 block mb-1">
                Nova Senha Master (mínimo 6 caracteres) *
              </label>
              <input
                type="password"
                required
                placeholder="Digite a senha master"
                value={setupPassword}
                onChange={(e) => setSetupPassword(e.target.value)}
                className="w-full px-3.5 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-white text-xs font-medium focus:border-[#a3e635] outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-neutral-300 block mb-1">
                Confirmação da Senha *
              </label>
              <input
                type="password"
                required
                placeholder="Repita a senha master"
                value={setupPasswordConfirm}
                onChange={(e) => setSetupPasswordConfirm(e.target.value)}
                className="w-full px-3.5 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-white text-xs font-medium focus:border-[#a3e635] outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(163,230,53,0.35)] transition-all cursor-pointer mt-2"
            >
              <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
              <span>Salvar Senha e Iniciar Central</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  // TELA DE LOGIN MASTER DA CENTRAL (Quando senha já está configurada)
  return (
    <div className="w-full max-w-md mx-auto py-8 animate-fadeIn">
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-[#121f0a] via-neutral-900 to-neutral-950 border border-[#a3e635]/40 shadow-2xl space-y-6">
        {/* LOGO & CABEÇALHO */}
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <WDriverLogo size="lg" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#182907] border border-[#a3e635]/30 text-[#a3e635] text-[11px] font-black uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" />
            <span>Acesso Restrito à Central 24h</span>
          </div>
          <h1 className="text-xl font-black text-white">
            Painel Master de Operações
          </h1>
          <p className="text-xs text-neutral-400">
            Acesso liberado exclusivamente através do e-mail da presidência: <strong className="text-white">{OFFICIAL_ADMIN_EMAIL}</strong>
          </p>
        </div>

        {/* FEEDBACK DE ERRO */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/50 text-red-200 text-xs flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* FORMULÁRIO DE LOGIN */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-neutral-300 block mb-1.5">
              E-mail de Login da Presidência:
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                placeholder="wdriveroficial@gmail.com"
                className="w-full pl-10 pr-3.5 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-white text-xs font-medium focus:border-[#a3e635] focus:outline-none transition-colors"
              />
            </div>
            <span className="text-[10px] text-neutral-500 mt-1 block">
              E-mail oficial restrito: <strong className="text-[#a3e635]">{OFFICIAL_ADMIN_EMAIL}</strong>
            </span>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-neutral-300">
                Senha Master:
              </label>
              <button
                type="button"
                onClick={() => setShowRecoveryModal(true)}
                className="text-[11px] text-[#a3e635] hover:underline font-semibold cursor-pointer"
              >
                Esqueceu a senha?
              </button>
            </div>
            <div className="relative">
              <Key className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="••••••••••••"
                className="w-full pl-10 pr-10 py-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-white text-xs font-medium focus:border-[#a3e635] focus:outline-none transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <span className="text-[10px] text-neutral-500 mt-1 block">
              Acesso protegido pela Senha Master criada pelo administrador.
            </span>
          </div>

          {/* BOTÃO ENTRAR */}
          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(163,230,53,0.35)] transition-all cursor-pointer mt-2"
          >
            <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
            <span>Acessar Central W-DRIVER</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* NOTA DE SEGURANÇA E SISTEMA ANTI-INVASÃO */}
        <div className="p-3.5 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 space-y-1 text-center">
          <div className="flex items-center justify-center gap-1.5 text-neutral-400 text-[11px] font-bold">
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
            <span>Sistema Anti-Invasão Ativo 24h</span>
          </div>
          <p className="text-[10px] text-neutral-500 leading-tight">
            Tentativas não autorizadas disparam a captura visual/áudio do invasor e banimento permanente imediato por IMEI/IP.
          </p>
        </div>
      </div>

      {/* ========================================================= */}
      {/* MODAL DO SISTEMA ANTI-INVASÃO COM CAPTURA DE CÂMERA/ÁUDIO */}
      {/* ========================================================= */}
      {isAntiIntrusionActive && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-fadeIn">
          <div className="relative w-full max-w-lg rounded-3xl bg-gradient-to-b from-red-950 via-neutral-950 to-black border-2 border-red-500 p-5 sm:p-7 shadow-[0_0_50px_rgba(239,68,68,0.6)] space-y-5">
            
            {/* TOPO DO ALERTA DE INVASÃO */}
            <div className="flex items-center justify-between border-b border-red-500/40 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-red-900/60 border border-red-500 flex items-center justify-center text-red-400 animate-bounce">
                  <Siren className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-black text-red-400 uppercase tracking-widest block animate-pulse">
                    🚨 ALERTA MÁXIMO DE SEGURANÇA
                  </span>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    SISTEMA ANTI-INVASÃO W-DRIVER
                  </h3>
                </div>
              </div>
              <button
                onClick={closeAntiIntrusion}
                className="w-8 h-8 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* TRANSMISSÃO DA CÂMERA FRONTAL (FEED FORENSE) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-red-400 font-bold flex items-center gap-1.5 uppercase tracking-wider">
                  <Camera className="w-4 h-4 animate-pulse text-red-500" />
                  Captura Visual & Biometria do Invasor
                </span>
                <span className="px-2 py-0.5 rounded-full bg-red-950 text-red-300 text-[10px] font-black border border-red-500/50 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                  GRAVANDO AO VIVO
                </span>
              </div>

              <div className="relative rounded-2xl overflow-hidden border-2 border-red-500/80 bg-black aspect-video flex items-center justify-center">
                {hasCameraAccess ? (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover scale-x-[-1]"
                    />
                    {/* Retículo Biométrico Forense */}
                    <div className="absolute inset-0 border-2 border-dashed border-red-500/40 m-6 rounded-2xl pointer-events-none flex flex-col justify-between p-3">
                      <div className="flex justify-between text-[9px] font-mono text-red-400">
                        <span>SCAN_FACE: ATIVO</span>
                        <span>MIC: CAPTANDO</span>
                      </div>
                      <div className="w-20 h-20 border-2 border-red-500 rounded-full self-center animate-pulse flex items-center justify-center">
                        <div className="w-2 h-2 bg-red-500 rounded-full" />
                      </div>
                      <div className="flex justify-between text-[9px] font-mono text-red-400">
                        <span>GEO: JOAO PESSOA/PB</span>
                        <span>EVIDENCIA_GRAVADA</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="p-6 text-center space-y-2">
                    <UserX className="w-12 h-12 text-red-400 mx-auto animate-pulse" />
                    <p className="text-xs font-bold text-white">
                      Identificador de Hardware & Perfil Biométrico Capturados
                    </p>
                    <p className="text-[10px] text-neutral-400">
                      Dispositivo bloqueado por diretriz de segurança cibernética W-DRIVER.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* DADOS REGISTRADOS DA OCORRÊNCIA */}
            <div className="p-3.5 rounded-2xl bg-black/60 border border-red-500/30 text-xs space-y-2 font-mono">
              <div className="flex justify-between text-neutral-300">
                <span className="text-neutral-500">Protocolo:</span>
                <span className="text-red-400 font-bold">{intruderData?.protocolNumber}</span>
              </div>
              <div className="flex justify-between text-neutral-300">
                <span className="text-neutral-500">E-mail Tentado:</span>
                <span className="text-white font-bold">{intruderData?.emailAttempt}</span>
              </div>
              <div className="flex justify-between text-neutral-300">
                <span className="text-neutral-500">Data/Hora:</span>
                <span className="text-neutral-200">{intruderData?.timestamp}</span>
              </div>
              <div className="flex justify-between text-neutral-300">
                <span className="text-neutral-500">Localização GPS:</span>
                <span className="text-neutral-200">{intruderData?.location}</span>
              </div>
            </div>

            {/* ALERTA DE BANIMENTO PERMANENTE */}
            <div className="p-4 rounded-2xl bg-red-950/80 border border-red-500 text-xs text-red-100 space-y-2">
              <h4 className="font-black uppercase tracking-wider text-red-300 flex items-center gap-1.5">
                <AlertOctagon className="w-4 h-4 text-red-400" />
                PENALIDADE: BANIMENTO PERMANENTE DA PLATAFORMA
              </h4>
              <p className="leading-relaxed text-[11px]">
                A W-DRIVER adota tolerância zero contra tentativas de invasão, golpes ou acessos fraudulentos. O IMEI deste dispositivo, o endereço IP e a biometria visual capturada foram registrados na lista negra e encaminhados à <strong>Delegacia de Defraudações e Crimes Cibernéticos da Paraíba (DECC-PB)</strong>.
              </p>
            </div>

            {/* BOTÃO DE RECONHECIMENTO */}
            <button
              onClick={closeAntiIntrusion}
              className="w-full py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-black text-xs uppercase tracking-wider transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Reconhecer Alerta e Retornar</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL DE RECUPERAÇÃO DE SENHA (RESTRITA AO E-MAIL OFICIAL) */}
      {/* ========================================================= */}
      {showRecoveryModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-md rounded-3xl bg-neutral-950 border border-neutral-800 p-6 shadow-2xl space-y-5 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">
                    Recuperação de Senha Restrita
                  </h3>
                  <p className="text-[10px] text-neutral-400">
                    Exclusiva para a presidência da W-DRIVER
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowRecoveryModal(false);
                  setRecoveryStep('input_email');
                  setRecoveryError(null);
                }}
                className="text-neutral-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {recoveryError && (
              <div className="p-3 rounded-2xl bg-red-950/50 border border-red-500/60 text-red-200 text-xs flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>{recoveryError}</span>
              </div>
            )}

            {recoverySuccessMessage && (
              <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/50 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{recoverySuccessMessage}</span>
              </div>
            )}

            {/* ETAPA 1: SOLICITAR CÓDIGO */}
            {recoveryStep === 'input_email' && (
              <form onSubmit={handleRequestCode} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1.5">
                    Confirme o e-mail oficial do fundador:
                  </label>
                  <input
                    type="email"
                    required
                    value={recoveryEmail}
                    onChange={(e) => setRecoveryEmail(e.target.value)}
                    placeholder="wdriveroficial@gmail.com"
                    className="w-full px-3.5 py-3 rounded-2xl bg-neutral-900 border border-neutral-800 text-white text-xs focus:border-[#a3e635] focus:outline-none"
                  />
                  <span className="text-[10px] text-neutral-500 mt-1 block">
                    Por segurança, links são enviados apenas para <strong className="text-[#a3e635]">{OFFICIAL_ADMIN_EMAIL}</strong>.
                  </span>
                </div>

                <button
                  type="submit"
                  disabled={isSendingCode}
                  className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSendingCode ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Gerando Código de Segurança...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Enviar Código para {OFFICIAL_ADMIN_EMAIL}</span>
                    </>
                  )}
                </button>
              </form>
            )}

            {/* ETAPA 2: DIGITAR CÓDIGO E NOVA SENHA */}
            {recoveryStep === 'enter_code' && (
              <form onSubmit={handleConfirmNewPassword} className="space-y-4">
                <div className="p-3 rounded-2xl bg-neutral-900 border border-[#a3e635]/40 text-center">
                  <span className="text-[10px] text-neutral-400 block font-semibold">
                    Código oficial enviado para {OFFICIAL_ADMIN_EMAIL}:
                  </span>
                  <div className="text-lg font-mono font-black text-[#a3e635] mt-1 tracking-widest">
                    {generatedCode}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1">
                    Código de Segurança:
                  </label>
                  <input
                    type="text"
                    required
                    value={typedCode}
                    onChange={(e) => setTypedCode(e.target.value)}
                    placeholder="Ex: WD-123456"
                    className="w-full px-3.5 py-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono uppercase text-center focus:border-[#a3e635] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1">
                    Nova Senha Master:
                  </label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="w-full px-3.5 py-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-white text-xs focus:border-[#a3e635] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-neutral-300 block mb-1">
                    Confirmar Nova Senha:
                  </label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Digite novamente"
                    className="w-full px-3.5 py-2.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-white text-xs focus:border-[#a3e635] focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                  <span>Redefinir Senha e Acessar Central</span>
                </button>
              </form>
            )}

            {/* ETAPA 3: SUCESSO */}
            {recoveryStep === 'success' && (
              <div className="py-6 text-center space-y-3 animate-fadeIn">
                <div className="w-12 h-12 rounded-full bg-emerald-950 border border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-black text-white">
                  Senha Master Atualizada com Sucesso!
                </h4>
                <p className="text-xs text-neutral-400">
                  Desbloqueando acesso seguro à Central de Operações...
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
