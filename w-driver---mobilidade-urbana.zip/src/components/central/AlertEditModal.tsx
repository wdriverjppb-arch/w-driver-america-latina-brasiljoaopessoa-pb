import React, { useState } from 'react';
import { X, Megaphone, CheckCircle2 } from 'lucide-react';
import { CentralAlert } from '../../types';

interface AlertEditModalProps {
  alert: CentralAlert;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedAlert: CentralAlert) => void;
}

export const AlertEditModal: React.FC<AlertEditModalProps> = ({
  alert,
  isOpen,
  onClose,
  onSave,
}) => {
  const [titulo, setTitulo] = useState(alert.titulo);
  const [mensagem, setMensagem] = useState(alert.mensagem);
  const [destinatario, setDestinatario] = useState(alert.destinatario);
  const [tipo, setTipo] = useState(alert.tipo);
  const [ativo, setAtivo] = useState(alert.ativo);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...alert,
      titulo: titulo.trim(),
      mensagem: mensagem.trim(),
      destinatario,
      tipo,
      ativo,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-neutral-800 bg-neutral-900">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
              <Megaphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Editar Comunicado</h3>
              <span className="text-[10px] text-neutral-400">Transmissão em tempo real</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-xl text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
          <div>
            <label className="text-[10px] text-neutral-400 font-bold block mb-1">Título do Comunicado:</label>
            <input
              type="text"
              required
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
              className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Destinatários:</label>
              <select
                value={destinatario}
                onChange={(e) => setDestinatario(e.target.value as any)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none"
              >
                <option value="todos">Todos</option>
                <option value="passageiros">Apenas Passageiros</option>
                <option value="motoristas">Apenas Motoristas</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Tipo de Alerta:</label>
              <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value as any)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none"
              >
                <option value="transito">Trânsito / Chuva</option>
                <option value="seguranca">Segurança</option>
                <option value="urgente">Urgente</option>
                <option value="geral">Informativo Geral</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] text-neutral-400 font-bold block mb-1">Mensagem:</label>
            <textarea
              rows={3}
              required
              value={mensagem}
              onChange={(e) => setMensagem(e.target.value)}
              className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="alertActiveCheck"
              checked={ativo}
              onChange={(e) => setAtivo(e.target.checked)}
              className="w-4 h-4 rounded text-[#a3e635] accent-[#a3e635]"
            />
            <label htmlFor="alertActiveCheck" className="text-xs text-neutral-300 font-semibold cursor-pointer">
              Ativo e visível no aplicativo
            </label>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-neutral-900 text-neutral-300 text-xs font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#a3e635] text-neutral-950 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-md"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Salvar Alterações</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
