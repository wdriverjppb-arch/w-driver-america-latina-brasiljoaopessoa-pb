import React, { useState } from 'react';
import { X, Upload, CheckCircle2, User, Camera, FileText, ShieldAlert, Trash2 } from 'lucide-react';
import { ManagedUser } from '../../types';

interface UserEditModalProps {
  user?: ManagedUser | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (userData: ManagedUser) => void;
}

export const UserEditModal: React.FC<UserEditModalProps> = ({
  user,
  isOpen,
  onClose,
  onSave,
}) => {
  const isEditing = Boolean(user && user.id);

  const [nome, setNome] = useState(user?.nome || '');
  const [tipo, setTipo] = useState<'passageiro' | 'motorista'>(user?.tipo || 'passageiro');
  const [cpf, setCpf] = useState(user?.cpf || '');
  const [telefone, setTelefone] = useState(user?.telefone || '(83) 98800-1122');
  const [imei, setImei] = useState(user?.imei || '');
  const [cidade, setCidade] = useState(user?.cidade || 'João Pessoa / PB');
  const [veiculo, setVeiculo] = useState(user?.veiculo || '');
  const [status, setStatus] = useState<ManagedUser['status']>(user?.status || 'aprovado');
  const [motivoBloqueio, setMotivoBloqueio] = useState(user?.motivoBloqueio || '');
  const [fotoUrl, setFotoUrl] = useState(user?.fotoUrl || '');
  const [documentoUrl, setDocumentoUrl] = useState(user?.documentoUrl || '');

  if (!isOpen) return null;

  // Handle Photo Upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setFotoUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Handle Document Upload
  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setDocumentoUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const resultUser: ManagedUser = {
      id: user?.id || `usr-${Date.now()}`,
      nome: nome.trim(),
      tipo,
      cpf: cpf.trim(),
      telefone: telefone.trim(),
      imei: imei.trim() || `864${Math.floor(100000000000 + Math.random() * 900000000000)}`,
      cidade: cidade.trim(),
      veiculo: tipo === 'motorista' ? veiculo.trim() : undefined,
      status,
      motivoBloqueio: (status === 'banido' || status === 'suspenso') ? (motivoBloqueio || 'Determinação da Central') : undefined,
      fotoUrl: fotoUrl || undefined,
      documentoUrl: documentoUrl || undefined,
      dataCadastro: user?.dataCadastro || new Date().toLocaleDateString('pt-BR'),
    };

    onSave(resultUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-lg bg-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800 bg-neutral-900">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">
                {isEditing ? 'Editar Cadastro de Usuário' : 'Adicionar Novo Cadastro'}
              </h3>
              <span className="text-[10px] text-neutral-400">
                Central de Segurança Antifraude W-DRIVER
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Formulário com Scroll */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {/* UPLOAD DE FOTO & DOCUMENTO */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800">
            {/* Foto de Perfil */}
            <div className="space-y-2 text-center">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                Foto de Perfil (Selfie)
              </span>
              <div className="relative mx-auto w-20 h-20 rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-700 flex items-center justify-center">
                {fotoUrl ? (
                  <img src={fotoUrl} alt="Perfil" className="w-full h-full object-cover" />
                ) : (
                  <Camera className="w-6 h-6 text-neutral-500" />
                )}
              </div>
              <label className="inline-block px-3 py-1 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[10px] font-bold cursor-pointer hover:bg-[#223d06] transition-colors">
                <span>{fotoUrl ? 'Alterar Foto' : 'Upload Foto'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            </div>

            {/* Documento Oficial */}
            <div className="space-y-2 text-center border-t sm:border-t-0 sm:border-l border-neutral-800 pt-2 sm:pt-0 sm:pl-3">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                Documento (CNH / RG)
              </span>
              <div className="relative mx-auto w-20 h-20 rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-700 flex items-center justify-center">
                {documentoUrl ? (
                  <img src={documentoUrl} alt="Documento" className="w-full h-full object-cover" />
                ) : (
                  <FileText className="w-6 h-6 text-neutral-500" />
                )}
              </div>
              <label className="inline-block px-3 py-1 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[10px] font-bold cursor-pointer hover:bg-[#223d06] transition-colors">
                <span>{documentoUrl ? 'Alterar Doc' : 'Upload Doc'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleDocumentUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* DADOS CADASTRAIS BÁSICOS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Nome Completo:</label>
              <input
                type="text"
                required
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Ex: João da Silva"
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>

            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Tipo de Usuário:</label>
              <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value as any)}
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              >
                <option value="passageiro">Passageiro</option>
                <option value="motorista">Motorista Parceiro</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">CPF (Receita Federal):</label>
              <input
                type="text"
                required
                value={cpf}
                onChange={(e) => setCpf(e.target.value)}
                placeholder="000.000.000-00"
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>

            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Telefone / WhatsApp:</label>
              <input
                type="text"
                value={telefone}
                onChange={(e) => setTelefone(e.target.value)}
                placeholder="(83) 98888-7777"
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">IMEI do Dispositivo:</label>
              <input
                type="text"
                value={imei}
                onChange={(e) => setImei(e.target.value)}
                placeholder="864291048291038"
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs font-mono outline-none focus:border-[#a3e635]"
              />
            </div>

            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Cidade / Região:</label>
              <input
                type="text"
                value={cidade}
                onChange={(e) => setCidade(e.target.value)}
                placeholder="João Pessoa / PB"
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>
          </div>

          {tipo === 'motorista' && (
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Veículo e Placa:</label>
              <input
                type="text"
                value={veiculo}
                onChange={(e) => setVeiculo(e.target.value)}
                placeholder="Ex: Honda CG 160 Titan (Placa: QFA-9921)"
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>
          )}

          {/* STATUS E CONTROLE DE BLOQUEIO */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-neutral-800">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Status do Cadastro:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs font-bold outline-none"
              >
                <option value="aprovado">Aprovado (Ativo no Radar)</option>
                <option value="em_analise">Em Análise Antifraude</option>
                <option value="suspenso">Suspenso Temporariamente</option>
                <option value="banido">Banido por CPF / IMEI</option>
              </select>
            </div>

            {(status === 'banido' || status === 'suspenso') && (
              <div>
                <label className="text-[10px] text-red-400 font-bold block mb-1">Motivo do Bloqueio:</label>
                <input
                  type="text"
                  value={motivoBloqueio}
                  onChange={(e) => setMotivoBloqueio(e.target.value)}
                  placeholder="Ex: Tentativa de calote no desembarque"
                  className="w-full p-2.5 bg-neutral-900 border border-red-500/50 rounded-xl text-red-200 text-xs outline-none"
                />
              </div>
            )}
          </div>

          {/* BOTÕES DE AÇÃO */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 text-xs font-bold transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
              <span>{isEditing ? 'Salvar Alterações' : 'Criar Cadastro'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
