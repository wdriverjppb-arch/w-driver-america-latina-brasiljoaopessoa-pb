import React, { useState } from 'react';
import { Sliders, Save, CheckCircle2, RotateCcw, ShieldCheck, Tag, Car } from 'lucide-react';
import { CategoryInfo } from '../../types';
import { VehicleGraphic } from '../VehicleGraphic';

interface CategoriesControlTabProps {
  categories: CategoryInfo[];
  onUpdateCategories: (updated: CategoryInfo[]) => void;
  showNotification: (msg: string) => void;
}

export const CategoriesControlTab: React.FC<CategoriesControlTabProps> = ({
  categories,
  onUpdateCategories,
  showNotification,
}) => {
  const [localCategories, setLocalCategories] = useState<CategoryInfo[]>(categories);
  const [hasChanges, setHasChanges] = useState(false);

  const handleFareChange = (index: number, field: 'baseFare' | 'kmAdicional' | 'name' | 'subtitle', val: string | number) => {
    const updated = [...localCategories];
    if (field === 'baseFare' || field === 'kmAdicional') {
      const numVal = parseFloat(val.toString()) || 0;
      updated[index] = { ...updated[index], [field]: numVal };
    } else {
      updated[index] = { ...updated[index], [field]: val };
    }
    setLocalCategories(updated);
    setHasChanges(true);
  };

  const handleSave = () => {
    onUpdateCategories(localCategories);
    setHasChanges(false);
    showNotification('✅ Tarifas e categorias oficiais atualizadas com sucesso! Os valores já estão valendo no App do Passageiro.');
  };

  const handleResetToCurrent = () => {
    setLocalCategories(categories);
    setHasChanges(false);
    showNotification('Valores restaurados para a configuração ativa.');
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* HEADER DA ABA */}
      <div className="p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-white uppercase tracking-wider">
                Configuração de Categorias & Tarifas Oficiais W-DRIVER
              </h2>
              <p className="text-xs text-neutral-400">
                Edite a taxa fixa (até 4 km) e o valor do km adicional. As alterações são sincronizadas imediatamente com a tela do passageiro.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {hasChanges && (
              <button
                onClick={handleResetToCurrent}
                className="px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Descartar</span>
              </button>
            )}

            <button
              onClick={handleSave}
              className="px-4 py-2 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(163,230,53,0.35)] cursor-pointer"
            >
              <Save className="w-4 h-4 stroke-[2.5]" />
              <span>Salvar Todas as Tarifas</span>
            </button>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-300 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#a3e635] shrink-0" />
          <span>
            <strong>Regra Oficial do Modelo W-DRIVER:</strong> Tarifa fixa cobre percursos de até 4 km. Acima de 4 km, cobra-se o valor do km adicional por quilômetro excedente.
          </span>
        </div>
      </div>

      {/* GRID DAS 8 CATEGORIAS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
        {localCategories.map((cat, idx) => (
          <div
            key={cat.id}
            className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800/90 shadow-md space-y-3 hover:border-[#a3e635]/30 transition-colors"
          >
            <div className="flex items-center justify-between border-b border-neutral-800/80 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center">
                  <VehicleGraphic type={cat.iconType} size="sm" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-white">{cat.name}</span>
                    {cat.tag && (
                      <span className="px-2 py-0.5 rounded-full bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[9px] font-bold">
                        {cat.tag}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono">ID: {cat.id}</span>
                </div>
              </div>

              <span className="text-[10px] text-neutral-400 bg-neutral-950 px-2 py-1 rounded-lg border border-neutral-800">
                ~ {cat.etaMins} min ETA
              </span>
            </div>

            {/* INPUTS DE VALORES */}
            <div className="grid grid-cols-2 gap-3 bg-neutral-950 p-3 rounded-xl border border-neutral-800/70">
              <div>
                <label className="text-[10px] text-neutral-400 font-bold block mb-1">
                  Taxa Fixa (até 4 km) - R$:
                </label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[11px] text-neutral-500 font-bold">R$</span>
                  <input
                    type="number"
                    step="0.50"
                    min="1.00"
                    value={cat.baseFare}
                    onChange={(e) => handleFareChange(idx, 'baseFare', e.target.value)}
                    className="w-full pl-8 pr-2 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs font-black text-[#a3e635] outline-none focus:border-[#a3e635]"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-neutral-400 font-bold block mb-1">
                  Km Adicional - R$:
                </label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[11px] text-neutral-500 font-bold">R$</span>
                  <input
                    type="number"
                    step="0.05"
                    min="0.10"
                    value={cat.kmAdicional}
                    onChange={(e) => handleFareChange(idx, 'kmAdicional', e.target.value)}
                    className="w-full pl-8 pr-2 py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-xs font-black text-[#a3e635] outline-none focus:border-[#a3e635]"
                  />
                </div>
              </div>
            </div>

            {/* SUBTÍTULO / DESCRIÇÃO */}
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">
                Subtítulo exibido no App:
              </label>
              <input
                type="text"
                value={cat.subtitle}
                onChange={(e) => handleFareChange(idx, 'subtitle', e.target.value)}
                placeholder="Ex: Fixo R$ 8,00 | Km adicional R$ 1,75"
                className="w-full px-2.5 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-[11px] text-neutral-300 outline-none focus:border-[#a3e635]"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
