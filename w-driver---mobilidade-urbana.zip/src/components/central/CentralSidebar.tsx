import React from 'react';
import { 
  LayoutDashboard, Map, Radio, Clock, AlertTriangle, Users, 
  FileCheck, ShieldCheck, Activity, BarChart2, Ban, Trash2, 
  DollarSign, Percent, FileText, Wallet, Megaphone, Tag, Gift, 
  PhoneCall, MessageSquare, ShieldAlert, FileCode, Sliders, 
  RefreshCw, ChevronRight, Phone
} from 'lucide-react';

export type CentralMenuOption = 
  | 'visao_geral'
  | 'mapa_geral'
  | 'chamadas_andamento'
  | 'solicitacoes_pendentes'
  | 'alertas_ocorrencias'
  | 'motoristas'
  | 'passageiros'
  | 'documentos'
  | 'aprovacao_motoristas'
  | 'status_viagens'
  | 'relatorios'
  | 'bloqueios'
  | 'excluir_usuarios'
  | 'receitas_transacoes'
  | 'comissoes_taxas'
  | 'extratos'
  | 'carteira_digital'
  | 'anuncios'
  | 'promocoes'
  | 'indicacoes'
  | 'wsos'
  | 'mensagens'
  | 'logs'
  | 'termos'
  | 'configuracoes';

interface CentralSidebarProps {
  activeOption: CentralMenuOption;
  onSelectOption: (option: CentralMenuOption) => void;
  pendingApprovalsCount?: number;
  pendingRidesCount?: number;
}

export const CentralSidebar: React.FC<CentralSidebarProps> = ({
  activeOption,
  onSelectOption,
  pendingApprovalsCount = 12,
  pendingRidesCount = 15,
}) => {
  return (
    <aside className="w-full lg:w-64 bg-[#080c08] border border-neutral-800/80 rounded-3xl p-3 text-neutral-300 space-y-4 shrink-0 max-h-[920px] overflow-y-auto no-scrollbar shadow-2xl">
      {/* 1. VISÃO GERAL */}
      <div>
        <button
          onClick={() => onSelectOption('visao_geral')}
          className={`w-full py-2.5 px-3 rounded-2xl font-black text-xs flex items-center justify-between transition-all cursor-pointer ${
            activeOption === 'visao_geral'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_15px_rgba(163,230,53,0.3)]'
              : 'hover:bg-neutral-900 text-neutral-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-4 h-4" />
            <span>Visão Geral</span>
          </div>
          <ChevronRight className="w-3.5 h-3.5 opacity-60" />
        </button>
      </div>

      {/* 2. ACOMPANHAMENTO EM TEMPO REAL */}
      <div className="space-y-1">
        <div className="px-2 text-[10px] font-black uppercase text-neutral-500 tracking-wider">
          Acompanhamento em Tempo Real
        </div>

        <button
          onClick={() => onSelectOption('mapa_geral')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'mapa_geral' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Map className="w-3.5 h-3.5" />
            <span>Mapa Geral</span>
          </div>
          <span className="px-1.5 py-0.2 rounded-md bg-neutral-900 text-[#a3e635] text-[10px] font-bold">128</span>
        </button>

        <button
          onClick={() => onSelectOption('chamadas_andamento')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'chamadas_andamento' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Radio className="w-3.5 h-3.5" />
            <span>Chamadas em Andamento</span>
          </div>
          <span className="px-1.5 py-0.2 rounded-md bg-sky-950 text-sky-400 text-[10px] font-bold">32</span>
        </button>

        <button
          onClick={() => onSelectOption('solicitacoes_pendentes')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'solicitacoes_pendentes' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5" />
            <span>Solicitações Pendentes</span>
          </div>
          <span className="px-1.5 py-0.2 rounded-md bg-amber-950 text-amber-400 text-[10px] font-bold">{pendingRidesCount}</span>
        </button>

        <button
          onClick={() => onSelectOption('alertas_ocorrencias')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'alertas_ocorrencias' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Alertas e Ocorrências</span>
          </div>
          <span className="px-1.5 py-0.2 rounded-md bg-red-950 text-red-400 text-[10px] font-bold">3</span>
        </button>
      </div>

      {/* 3. GESTÃO DE CADASTROS */}
      <div className="space-y-1">
        <div className="px-2 text-[10px] font-black uppercase text-neutral-500 tracking-wider">
          Gestão de Cadastros
        </div>

        <button
          onClick={() => onSelectOption('motoristas')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'motoristas' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Users className="w-3.5 h-3.5" />
            <span>Motoristas</span>
          </div>
          <span className="text-[9px] text-neutral-500">Dados & Docs</span>
        </button>

        <button
          onClick={() => onSelectOption('passageiros')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'passageiros' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Users className="w-3.5 h-3.5" />
            <span>Passageiros</span>
          </div>
          <span className="text-[9px] text-neutral-500">Avaliações</span>
        </button>

        <button
          onClick={() => onSelectOption('documentos')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'documentos' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <FileCheck className="w-3.5 h-3.5" />
            <span>Documentos</span>
          </div>
          <span className="px-1.5 py-0.2 rounded-md bg-amber-950 text-amber-300 text-[10px] font-bold">{pendingApprovalsCount}</span>
        </button>

        <button
          onClick={() => onSelectOption('aprovacao_motoristas')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'aprovacao_motoristas' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Aprovação de Motoristas</span>
          </div>
          <ChevronRight className="w-3 h-3 text-neutral-600" />
        </button>
      </div>

      {/* 4. CONTROLE E FISCALIZAÇÃO */}
      <div className="space-y-1">
        <div className="px-2 text-[10px] font-black uppercase text-neutral-500 tracking-wider">
          Controle e Fiscalização
        </div>

        <button
          onClick={() => onSelectOption('status_viagens')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'status_viagens' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Activity className="w-3.5 h-3.5" />
            <span>Status das Viagens</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('relatorios')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'relatorios' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Relatórios</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('bloqueios')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'bloqueios' ? 'bg-neutral-900 text-red-400' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Ban className="w-3.5 h-3.5 text-red-400" />
            <span>Bloqueios & Banimento</span>
          </div>
        </button>
      </div>

      {/* 5. FINANCEIRO */}
      <div className="space-y-1">
        <div className="px-2 text-[10px] font-black uppercase text-neutral-500 tracking-wider">
          Financeiro
        </div>

        <button
          onClick={() => onSelectOption('receitas_transacoes')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'receitas_transacoes' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <DollarSign className="w-3.5 h-3.5" />
            <span>Receitas & Transações</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('comissoes_taxas')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'comissoes_taxas' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Percent className="w-3.5 h-3.5" />
            <span>Comissões e Taxas (10%)</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('carteira_digital')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'carteira_digital' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Wallet className="w-3.5 h-3.5" />
            <span>Carteira Digital W-BANK</span>
          </div>
        </button>
      </div>

      {/* 6. MARKETING E ANÚNCIOS */}
      <div className="space-y-1">
        <div className="px-2 text-[10px] font-black uppercase text-neutral-500 tracking-wider">
          Marketing e Anúncios
        </div>

        <button
          onClick={() => onSelectOption('anuncios')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'anuncios' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Megaphone className="w-3.5 h-3.5" />
            <span>Anúncios Locais</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('promocoes')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'promocoes' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <Tag className="w-3.5 h-3.5" />
            <span>Promoções & Cupons</span>
          </div>
        </button>
      </div>

      {/* 7. FERRAMENTAS & SOS */}
      <div className="space-y-1">
        <div className="px-2 text-[10px] font-black uppercase text-neutral-500 tracking-wider">
          Ferramentas
        </div>

        <button
          onClick={() => onSelectOption('wsos')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-black flex items-center justify-between transition-colors ${
            activeOption === 'wsos' ? 'bg-red-950 text-red-300' : 'hover:bg-red-950/40 text-red-400'
          }`}
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>W-SOS Emergência</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('mensagens')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'mensagens' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Mensagens & Suporte</span>
          </div>
        </button>

        <button
          onClick={() => onSelectOption('logs')}
          className={`w-full py-2 px-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
            activeOption === 'logs' ? 'bg-neutral-900 text-[#a3e635]' : 'hover:bg-neutral-900/60 text-neutral-400 hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Logs do Sistema</span>
          </div>
        </button>
      </div>

      {/* 8. SUPORTE TÉCNICO RODAPÉ (Matching Image 2) */}
      <div className="p-3 rounded-2xl bg-[#0e140e] border border-neutral-800/80 space-y-1 text-[11px]">
        <div className="text-[10px] font-bold text-neutral-400 uppercase">Suporte Técnico 24h:</div>
        <div className="font-mono font-black text-white text-xs">0800 000 0000</div>
        <div className="text-[10px] text-neutral-400">suporte@wdriver.com</div>
        <div className="text-[9px] text-[#a3e635] font-bold pt-0.5">● Operação João Pessoa Ativa</div>
      </div>
    </aside>
  );
};
