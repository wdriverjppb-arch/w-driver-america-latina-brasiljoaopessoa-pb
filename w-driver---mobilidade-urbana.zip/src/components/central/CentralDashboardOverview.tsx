import React, { useState } from 'react';
import { 
  Users, Car, XCircle, DollarSign, TrendingUp, TrendingDown, 
  MapPin, CheckCircle2, ShieldCheck, AlertTriangle, Eye, 
  Check, X, Clock, ArrowRight, ShieldAlert, Sliders, Zap, 
  Megaphone, Ban, RefreshCw, Star, BarChart3, PieChart, Activity
} from 'lucide-react';
import { ManagedUser, RideData } from '../../types';

interface CentralDashboardOverviewProps {
  managedUsers: ManagedUser[];
  rides: RideData[];
  onApproveUser: (id: string) => void;
  onRejectUser: (id: string) => void;
  onViewDocs: (user: ManagedUser) => void;
  onSelectAction: (action: string) => void;
}

export const CentralDashboardOverview: React.FC<CentralDashboardOverviewProps> = ({
  managedUsers,
  rides,
  onApproveUser,
  onRejectUser,
  onViewDocs,
  onSelectAction,
}) => {
  const [approvalTab, setApprovalTab] = useState<'todos' | 'motoristas' | 'passageiros'>('motoristas');

  // Filter pending approvals
  const pendingApprovals = managedUsers.filter((u) => {
    const isPending = u.status === 'em_analise';
    if (approvalTab === 'todos') return isPending;
    if (approvalTab === 'motoristas') return isPending && u.tipo === 'motorista';
    if (approvalTab === 'passageiros') return isPending && u.tipo === 'passageiro';
    return isPending;
  });

  return (
    <div className="space-y-5 animate-fadeIn">
      {/* 1. 4 STAT CARDS (Exact values & layout from Image 2) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: USUÁRIOS ATIVOS */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-neutral-400 tracking-wider">
              USUÁRIOS ATIVOS
            </span>
            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/30">
              <TrendingUp className="w-3 h-3" />
              <span>+12% em 24h</span>
            </span>
          </div>
          <div className="text-2xl font-black text-white">
            18.654
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1 border-t border-neutral-800">
            <span>Motoristas: <strong className="text-[#a3e635]">5.642</strong></span>
            <span>Passageiros: <strong className="text-white">13.012</strong></span>
          </div>
        </div>

        {/* Card 2: CORRIDAS REALIZADAS */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-neutral-400 tracking-wider">
              CORRIDAS REALIZADAS
            </span>
            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/30">
              <TrendingUp className="w-3 h-3" />
              <span>+8% em 24h</span>
            </span>
          </div>
          <div className="text-2xl font-black text-white">
            128
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1 border-t border-neutral-800">
            <span>Taxa de aceitação: <strong className="text-emerald-400">92%</strong></span>
            <span>Hoje em JP</span>
          </div>
        </div>

        {/* Card 3: CANCELAMENTOS */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-neutral-400 tracking-wider">
              CANCELAMENTOS
            </span>
            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/30">
              <TrendingDown className="w-3 h-3" />
              <span>-5% em 24h</span>
            </span>
          </div>
          <div className="text-2xl font-black text-white">
            1.256
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1 border-t border-neutral-800">
            <span>Em andamento: <strong className="text-[#a3e635]">38</strong></span>
            <span>Auditados</span>
          </div>
        </div>

        {/* Card 4: FATURAMENTO DO DIA */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-[#a3e635]/40 shadow-[0_0_20px_rgba(163,230,53,0.1)] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-neutral-400 tracking-wider">
              FATURAMENTO DO DIA
            </span>
            <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/30">
              <TrendingUp className="w-3 h-3" />
              <span>+18% em 24h</span>
            </span>
          </div>
          <div className="text-2xl font-black text-[#a3e635]">
            R$ 24.560,80
          </div>
          <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1 border-t border-neutral-800">
            <span>Comissão (10%): <strong className="text-white">R$ 2.456,08</strong></span>
            <span>PIX Direto</span>
          </div>
        </div>
      </div>

      {/* 2. MAPA EM TEMPO REAL + DESEMPENHO DA PLATAFORMA (Matching Image 2) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
        {/* Mapa Radar Operacional */}
        <div className="lg:col-span-2 p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#a3e635] animate-ping" />
              <h3 className="text-sm font-black text-white">Mapa em Tempo Real (João Pessoa)</h3>
            </div>
            <span className="text-[11px] text-[#a3e635] font-bold bg-[#142607] px-2.5 py-0.5 rounded-full border border-[#a3e635]/30">
              128 Motoristas Ativos
            </span>
          </div>

          <div className="relative h-64 rounded-2xl bg-[#060906] border border-neutral-800 overflow-hidden flex items-center justify-center">
            {/* Stylized vector map grid of João Pessoa */}
            <svg viewBox="0 0 500 240" className="w-full h-full opacity-60">
              {/* Coastline */}
              <path d="M 420 10 Q 400 120 440 240" stroke="#0ea5e9" strokeWidth="6" fill="none" opacity="0.4" />
              <text x="445" y="120" fill="#0ea5e9" fontSize="10" fontWeight="bold">Oceano Atlântico</text>
              {/* Major Roads */}
              <path d="M 50 120 L 410 120" stroke="#334155" strokeWidth="2" />
              <path d="M 220 20 L 220 220" stroke="#334155" strokeWidth="2" />
              <path d="M 120 40 Q 250 80 400 60" stroke="#a3e635" strokeWidth="2" strokeDasharray="4 4" />
              
              {/* Active Vehicles Pins */}
              <circle cx="160" cy="90" r="4" fill="#a3e635" className="animate-pulse" />
              <circle cx="210" cy="140" r="4" fill="#a3e635" />
              <circle cx="280" cy="110" r="5" fill="#38bdf8" />
              <circle cx="340" cy="70" r="4" fill="#a3e635" />
              <circle cx="380" cy="130" r="4" fill="#eab308" />
              <circle cx="320" cy="180" r="4" fill="#a3e635" />

              {/* Bairros Labels */}
              <text x="350" y="85" fill="#94a3b8" fontSize="9" fontWeight="bold">Tambaú</text>
              <text x="340" y="145" fill="#94a3b8" fontSize="9" fontWeight="bold">Cabo Branco</text>
              <text x="310" y="50" fill="#94a3b8" fontSize="9" fontWeight="bold">Bessa</text>
              <text x="210" y="110" fill="#94a3b8" fontSize="9" fontWeight="bold">Torre</text>
              <text x="140" y="170" fill="#94a3b8" fontSize="9" fontWeight="bold">Mangabeira</text>
            </svg>

            <div className="absolute bottom-3 left-3 bg-neutral-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-neutral-800 text-[10px] text-neutral-300 flex items-center gap-3">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#a3e635]" /> Livres</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#38bdf8]" /> Em Viagem</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-[#eab308]" /> W-TÁXI</span>
            </div>
          </div>
        </div>

        {/* Desempenho da Plataforma */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3.5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-black text-white">Desempenho da Plataforma</h3>
            <p className="text-[11px] text-neutral-400">Indicadores operacionais de João Pessoa</p>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-neutral-300">Tempo Médio de Resposta:</span>
                <span className="font-bold text-white">4 min</span>
              </div>
              <div className="w-full bg-neutral-950 rounded-full h-2">
                <div className="bg-[#a3e635] h-2 rounded-full" style={{ width: '85%' }} />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-neutral-300">Nota Média dos Motoristas:</span>
                <span className="font-bold text-amber-400">4.87 ★</span>
              </div>
              <div className="w-full bg-neutral-950 rounded-full h-2">
                <div className="bg-amber-400 h-2 rounded-full" style={{ width: '95%' }} />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-neutral-300">Chamadas Atendidas:</span>
                <span className="font-bold text-emerald-400">94.2%</span>
              </div>
              <div className="w-full bg-neutral-950 rounded-full h-2">
                <div className="bg-emerald-400 h-2 rounded-full" style={{ width: '94%' }} />
              </div>
            </div>
          </div>

          <div className="p-2.5 rounded-2xl bg-[#142607] border border-[#a3e635]/30 text-center text-[11px] text-[#a3e635] font-bold">
            🛡️ Sistema Anti-Fraude Ativo • 0 Incidentes Críticos
          </div>
        </div>
      </div>

      {/* 3. APROVAÇÕES PENDENTES (Matching Image 2: Abas Todos, Motoristas, Passageiros + Tabela) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-3">
          <div>
            <h3 className="text-sm font-black text-white flex items-center gap-2">
              <span>Aprovações Pendentes</span>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                {pendingApprovals.length} pendentes
              </span>
            </h3>
            <p className="text-[11px] text-neutral-400">
              Auditoria de CNH, EAR, CRLV e antecedentes criminais da Paraíba
            </p>
          </div>

          {/* Abas da tabela */}
          <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-2xl border border-neutral-800 self-start">
            {(['todos', 'motoristas', 'passageiros'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setApprovalTab(tab)}
                className={`py-1.5 px-3 rounded-xl text-xs font-bold capitalize transition-colors ${
                  approvalTab === tab
                    ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/40'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Tabela de Aprovações */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-[10px] uppercase tracking-wider font-bold">
                <th className="py-2.5 px-2">Usuário / CPF</th>
                <th className="py-2.5 px-2">Tipo</th>
                <th className="py-2.5 px-2">Data Cadastro</th>
                <th className="py-2.5 px-2">Documentação</th>
                <th className="py-2.5 px-2">Status</th>
                <th className="py-2.5 px-2 text-right">Ações da Central</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {pendingApprovals.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-neutral-500 text-xs">
                    Nenhum cadastro pendente nesta categoria no momento. Todos auditados!
                  </td>
                </tr>
              ) : (
                pendingApprovals.map((u) => (
                  <tr key={u.id} className="hover:bg-neutral-950/50 transition-colors">
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-center font-bold text-[#a3e635] text-xs shrink-0">
                          {u.nome.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-white text-xs">{u.nome}</div>
                          <div className="text-[10px] text-neutral-400 font-mono">{u.cpf}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                        u.tipo === 'motorista' ? 'bg-sky-500/20 text-sky-300' : 'bg-purple-500/20 text-purple-300'
                      }`}>
                        {u.tipo}
                      </span>
                    </td>
                    <td className="py-3 px-2 text-neutral-400 text-[11px] whitespace-nowrap">
                      {u.dataCadastro}
                    </td>
                    <td className="py-3 px-2">
                      <button
                        onClick={() => onViewDocs(u)}
                        className="px-2.5 py-1 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[10px] font-bold text-neutral-300 hover:text-white flex items-center gap-1 transition-colors"
                      >
                        <Eye className="w-3 h-3 text-[#a3e635]" />
                        <span>Ver Documentos (4)</span>
                      </button>
                    </td>
                    <td className="py-3 px-2">
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-bold">
                        Em Análise
                      </span>
                    </td>
                    <td className="py-3 px-2 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onApproveUser(u.id)}
                          className="px-2.5 py-1 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-[10px] flex items-center gap-1 cursor-pointer transition-colors"
                          title="Aprovar cadastro"
                        >
                          <Check className="w-3 h-3" />
                          <span>Aprovar</span>
                        </button>
                        <button
                          onClick={() => onRejectUser(u.id)}
                          className="px-2.5 py-1 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 font-bold text-[10px] flex items-center gap-1 cursor-pointer transition-colors"
                          title="Recusar cadastro"
                        >
                          <X className="w-3 h-3" />
                          <span>Recusar</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. AÇÕES RÁPIDAS (12 botões matching Image 2) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
        <h3 className="text-xs font-black uppercase text-neutral-300 tracking-wider">
          Ações Rápidas do Administrador
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {[
            { label: 'Bloquear Usuário', icon: Ban, color: 'text-red-400', action: 'bloquear' },
            { label: 'Novo Comunicado', icon: Megaphone, color: 'text-amber-400', action: 'comunicado' },
            { label: 'Trilha Dinâmica 3.5', icon: Zap, color: 'text-[#a3e635]', action: 'dinamica' },
            { label: 'Ajustar Tarifas', icon: Sliders, color: 'text-sky-400', action: 'tarifas' },
            { label: 'Auditoria PIX', icon: DollarSign, color: 'text-emerald-400', action: 'pix' },
            { label: 'Central W-SOS', icon: AlertTriangle, color: 'text-red-500', action: 'sos' },
            { label: 'Novo Anúncio Ads', icon: BarChart3, color: 'text-purple-400', action: 'anuncio' },
            { label: 'Aprovar Motoristas', icon: ShieldCheck, color: 'text-[#a3e635]', action: 'aprovar_motoristas' },
            { label: 'Status Viagens', icon: Activity, color: 'text-blue-400', action: 'status_viagens' },
            { label: 'Relatório Financeiro', icon: DollarSign, color: 'text-emerald-400', action: 'relatorio_financeiro' },
            { label: 'Contratos W-LUXO', icon: Star, color: 'text-amber-300', action: 'contratos_luxo' },
            { label: 'Logs do Sistema', icon: Clock, color: 'text-neutral-400', action: 'logs' },
          ].map((btn, idx) => {
            const Icon = btn.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectAction(btn.action)}
                className="p-3 rounded-2xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 flex flex-col items-center justify-center gap-1.5 text-center transition-all cursor-pointer group hover:border-neutral-700"
              >
                <Icon className={`w-5 h-5 ${btn.color} group-hover:scale-110 transition-transform`} />
                <span className="text-[10px] font-bold text-neutral-300 group-hover:text-white leading-tight">
                  {btn.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 5. 3 GRÁFICOS ANALÍTICOS (Matching Image 2: Corridas por Categoria, Faturamento 7 Dias, Avaliações 7 Dias) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {/* Gráfico 1: Corridas por Categoria */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              Corridas por Categoria
            </h4>
            <PieChart className="w-4 h-4 text-[#a3e635]" />
          </div>
          <div className="space-y-2 text-xs">
            {[
              { name: 'W-CARRO COMUM', pct: 45, color: 'bg-emerald-400' },
              { name: 'W-MOTO COMUM', pct: 28, color: 'bg-[#a3e635]' },
              { name: 'W-CARRO PRIME', pct: 14, color: 'bg-sky-400' },
              { name: 'W-MOTO PRIME', pct: 8, color: 'bg-lime-300' },
              { name: 'W-TÁXI / W-LUXO', pct: 5, color: 'bg-amber-400' },
            ].map((cat, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-[10px] text-neutral-400">
                  <span>{cat.name}</span>
                  <span className="font-bold text-white">{cat.pct}%</span>
                </div>
                <div className="w-full bg-neutral-950 rounded-full h-1.5">
                  <div className={`${cat.color} h-1.5 rounded-full`} style={{ width: `${cat.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Gráfico 2: Faturamento Últimos 7 Dias */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              Faturamento (7 Dias)
            </h4>
            <BarChart3 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="h-32 flex items-end justify-between gap-2 pt-4 px-2">
            {[
              { dia: 'Seg', val: 18, label: '18k' },
              { dia: 'Ter', val: 21, label: '21k' },
              { dia: 'Qua', val: 19, label: '19k' },
              { dia: 'Qui', val: 22, label: '22k' },
              { dia: 'Sex', val: 28, label: '28k' },
              { dia: 'Sáb', val: 32, label: '32k' },
              { dia: 'Dom', val: 24.5, label: '24.5k' },
            ].map((bar, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-[8px] font-bold text-neutral-500">{bar.label}</span>
                <div
                  className="w-full bg-[#a3e635] rounded-t-md hover:bg-[#bef264] transition-colors"
                  style={{ height: `${(bar.val / 35) * 80}px` }}
                />
                <span className="text-[9px] font-bold text-neutral-400">{bar.dia}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Gráfico 3: Avaliações Últimos 7 Dias */}
        <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">
              Avaliações Médias (7 Dias)
            </h4>
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          </div>
          <div className="h-32 flex flex-col justify-between py-2">
            <div className="flex items-baseline justify-between">
              <span className="text-xs text-neutral-400">Nota Média Semanal:</span>
              <span className="text-xl font-black text-amber-400">4,92 ★</span>
            </div>

            <svg viewBox="0 0 200 60" className="w-full h-16">
              <path
                d="M 10 40 L 40 32 L 70 36 L 100 24 L 130 18 L 160 14 L 190 10"
                fill="none"
                stroke="#eab308"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              {[
                { cx: 10, cy: 40 },
                { cx: 40, cy: 32 },
                { cx: 70, cy: 36 },
                { cx: 100, cy: 24 },
                { cx: 130, cy: 18 },
                { cx: 160, cy: 14 },
                { cx: 190, cy: 10 },
              ].map((pt, i) => (
                <circle key={i} cx={pt.cx} cy={pt.cy} r="3" fill="#fef08a" />
              ))}
            </svg>

            <div className="flex justify-between text-[9px] text-neutral-500 font-bold px-1">
              <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Hoje</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
