import React, { useState } from 'react';
import { X, Image as ImageIcon, Upload, CheckCircle2 } from 'lucide-react';
import { AdBanner, AdCategory } from '../../types';

interface AdEditModalProps {
  ad: AdBanner;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedAd: AdBanner) => void;
}

export const AdEditModal: React.FC<AdEditModalProps> = ({
  ad,
  isOpen,
  onClose,
  onSave,
}) => {
  const [empresa, setEmpresa] = useState(ad.empresa);
  const [titulo, setTitulo] = useState(ad.titulo);
  const [categoria, setCategoria] = useState<AdCategory>(ad.categoria);
  const [imagemUrl, setImagemUrl] = useState(ad.imagemUrl);
  const [linkWhatsApp, setLinkWhatsApp] = useState(ad.linkWhatsApp || '');
  const [cupom, setCupom] = useState(ad.cupom || '');
  const [descricao, setDescricao] = useState(ad.descricao);
  const [ativo, setAtivo] = useState(ad.ativo);

  if (!isOpen) return null;

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setImagemUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const categoryLabels: Record<AdCategory, string> = {
      posto: 'Postos de Combustíveis',
      farmacia: 'Farmácias & Drogaria',
      espetinho: 'Gastronomia & Espetinhos',
      mercado: 'Supermercados & Atacarejo',
      outro: 'Comércio Local',
    };

    onSave({
      ...ad,
      empresa: empresa.trim(),
      titulo: titulo.trim(),
      categoria,
      categoriaLabel: categoryLabels[categoria],
      imagemUrl: imagemUrl.trim(),
      linkWhatsApp: linkWhatsApp.trim() || undefined,
      cupom: cupom.trim() || undefined,
      descricao: descricao.trim(),
      ativo,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-md bg-neutral-950 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        <div className="flex items-center justify-between p-4 border-b border-neutral-800 bg-neutral-900">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Editar Anúncio / Banner</h3>
              <span className="text-[10px] text-neutral-400">Patrocinador Local W-DRIVER</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-xl text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-3.5">
          {/* PRÉVIA DO BANNER */}
          <div className="space-y-1.5">
            <span className="text-[10px] text-neutral-400 font-bold block">Banner / Imagem:</span>
            <div className="w-full h-32 rounded-2xl overflow-hidden bg-neutral-900 border border-neutral-800 flex items-center justify-center relative">
              {imagemUrl ? (
                <img src={imagemUrl} alt="Banner" className="w-full h-full object-cover" />
              ) : (
                <ImageIcon className="w-8 h-8 text-neutral-600" />
              )}
            </div>
            <label className="inline-block px-3 py-1.5 rounded-xl bg-neutral-900 border border-neutral-700 hover:border-[#a3e635] text-white text-[11px] font-bold cursor-pointer transition-colors">
              <span>Trocar Banner (Upload)</span>
              <input type="file" accept="image/*" onChange={handleImageFile} className="hidden" />
            </label>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Empresa:</label>
              <input
                type="text"
                required
                value={empresa}
                onChange={(e) => setEmpresa(e.target.value)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Segmento:</label>
              <select
                value={categoria}
                onChange={(e) => setCategoria(e.target.value as any)}
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none"
              >
                <option value="espetinho">Espetinho / Bar</option>
                <option value="farmacia">Farmácia</option>
                <option value="mercado">Mercado</option>
                <option value="posto">Posto</option>
                <option value="outro">Outro</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] text-neutral-400 font-bold block mb-1">Título da Promoção:</label>
            <input
              type="text"
              required
              value={titulo}
              onChange={(e) => setTitulo(e.target.value)}
              className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Link WhatsApp:</label>
              <input
                type="text"
                value={linkWhatsApp}
                onChange={(e) => setLinkWhatsApp(e.target.value)}
                placeholder="https://wa.me/..."
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
              />
            </div>
            <div>
              <label className="text-[10px] text-neutral-400 font-bold block mb-1">Cupom de Desconto:</label>
              <input
                type="text"
                value={cupom}
                onChange={(e) => setCupom(e.target.value)}
                placeholder="Ex: WDRIVER10"
                className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs font-mono outline-none focus:border-[#a3e635]"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-neutral-400 font-bold block mb-1">Descrição do Anúncio:</label>
            <textarea
              rows={2}
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              className="w-full p-2 bg-neutral-900 border border-neutral-800 rounded-xl text-white text-xs outline-none focus:border-[#a3e635]"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="adActiveCheck"
              checked={ativo}
              onChange={(e) => setAtivo(e.target.checked)}
              className="w-4 h-4 rounded text-[#a3e635] accent-[#a3e635]"
            />
            <label htmlFor="adActiveCheck" className="text-xs text-neutral-300 font-semibold cursor-pointer">
              Ativo no aplicativo do passageiro
            </label>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-neutral-900 text-neutral-300 text-xs font-bold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#a3e635] text-neutral-950 text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-md"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Salvar Anúncio</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
