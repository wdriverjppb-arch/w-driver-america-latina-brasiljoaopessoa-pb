import React from 'react';
import { 
  ShieldCheck, Navigation, Lock, Wallet, BookOpen, Building2, 
  ArrowRight, Bike, Sparkles, PhoneCall, ExternalLink, CheckCircle2,
  Car, Compass, Zap
} from 'lucide-react';
import { WDriverLogo } from './WDriverLogo';
import { AdBanner } from '../types';
import { PIX_CONFIG } from '../utils/pix';
import { FounderOfficialPhoto } from './FounderOfficialPhoto';

interface WelcomeHomeProps {
  onGoToPassengerApp: () => void;
  onGoToRegistration: () => void;
  onGoToWBank: () => void;
  onGoToBio: () => void;
  onGoToCentral: () => void;
  ads: AdBanner[];
}

export const WelcomeHome: React.FC<WelcomeHomeProps> = ({
  onGoToPassengerApp,
  onGoToRegistration,
  onGoToWBank,
  onGoToBio,
  onGoToCentral,
  ads,
}) => {
  const activeAds = ads.filter((a) => a.ativo);

  return (
    <div className="w-full space-y-6 animate-fadeIn pb-6">
      {/* HERO SECTION DE BOAS-VINDAS */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#111c08] via-[#090d07] to-neutral-950 border border-[#a3e635]/40 p-5 sm:p-8 shadow-2xl">
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-[#a3e635]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-[#1a2e05] border border-[#a3e635]/50 text-[#a3e635] text-[11px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm">
              <Sparkles className="w-3.5 h-3.5" />
              Plataforma Oficial de Mobilidade Urbana
            </span>
            <span className="px-2.5 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-300 text-[11px] font-semibold">
              João Pessoa - PB
            </span>
          </div>

          <div className="space-y-2">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <WDriverLogo size="lg" />
              </div>
              <div className="pt-2">
                <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight">
                  W-DRIVER
                </h1>
                <p className="text-xs sm:text-sm font-extrabold text-[#a3e635] tracking-wider sm:tracking-widest uppercase">
                  AMÉRICA LATINA BRASIL JOÃO PESSOA-PB
                </p>
              </div>
            </div>
            
            {/* SLOGAN OFICIAL */}
            <div className="pt-2">
              <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-tight">
                "Quem escolhe preço corre riscos.{' '}
                <span className="text-[#a3e635] block sm:inline">
                  Quem escolhe a W-DRIVER escolhe chegar bem!"
                </span>
              </h2>
              <p className="text-xs sm:text-sm text-neutral-300 mt-2 leading-relaxed max-w-2xl font-normal">
                Mobilidade inteligente, auditada e blindada contra golpes. Sistema pioneiro que valoriza o motorista com repasse líquido de 90%, protege o passageiro com biometria facial e garante cada viagem pela Central 24h.
              </p>
            </div>
          </div>

          {/* BOTÕES DE AÇÃO RÁPIDA */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-3">
            <button
              onClick={onGoToPassengerApp}
              className="px-6 py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_4px_25px_rgba(163,230,53,0.35)] transition-all cursor-pointer active:scale-[0.98]"
            >
              <Navigation className="w-4 h-4" />
              <span>Solicitar Viagem Agora (Radar 24h)</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onGoToRegistration}
              className="px-5 py-3.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-neutral-200 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Lock className="w-4 h-4 text-[#a3e635]" />
              <span>Iniciar Cadastro & Blindagem</span>
            </button>
          </div>
        </div>
      </div>

      {/* VITRINE DAS 4 CATEGORIAS PRINCIPAIS */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-black text-white uppercase tracking-wider">
              Escolha Como Deseja se Deslocar
            </h2>
            <p className="text-[11px] text-neutral-400">
              Frota higienizada, revisada e rastreada via satélite em João Pessoa
            </p>
          </div>
          <button
            onClick={onGoToPassengerApp}
            className="text-xs font-bold text-[#a3e635] hover:underline flex items-center gap-1"
          >
            Ver Todas as Tarifas ➔
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {/* 1. W-BIKE */}
          <div 
            onClick={onGoToPassengerApp}
            className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-[#a3e635]/60 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center text-[#a3e635]">
                <Bike className="w-5 h-5" />
              </div>
              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">
                Ecológico
              </span>
            </div>
            <div>
              <div className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
                W-BIKE
              </div>
              <div className="text-[10px] text-neutral-400">Mobilidade ágil e entregas</div>
            </div>
            <div className="pt-1 border-t border-neutral-800 flex items-baseline justify-between text-xs">
              <span className="text-neutral-500 text-[10px]">A partir de:</span>
              <strong className="text-[#a3e635] font-black">R$ 6,00</strong>
            </div>
          </div>

          {/* 2. W-MOTO */}
          <div 
            onClick={onGoToPassengerApp}
            className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-[#a3e635]/60 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center text-[#a3e635] text-lg">
                🏍️
              </div>
              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-400">
                Mais Rápido
              </span>
            </div>
            <div>
              <div className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
                W-MOTO
              </div>
              <div className="text-[10px] text-neutral-400">Capacete higienizado</div>
            </div>
            <div className="pt-1 border-t border-neutral-800 flex items-baseline justify-between text-xs">
              <span className="text-neutral-500 text-[10px]">A partir de:</span>
              <strong className="text-[#a3e635] font-black">R$ 6,00</strong>
            </div>
          </div>

          {/* 3. W-CARRO */}
          <div 
            onClick={onGoToPassengerApp}
            className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-[#a3e635]/60 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center text-[#a3e635]">
                <Car className="w-5 h-5" />
              </div>
              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-[#1a2e05] text-[#a3e635]">
                Popular
              </span>
            </div>
            <div>
              <div className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
                W-CARRO
              </div>
              <div className="text-[10px] text-neutral-400">Até 4 pessoas com ar</div>
            </div>
            <div className="pt-1 border-t border-neutral-800 flex items-baseline justify-between text-xs">
              <span className="text-neutral-500 text-[10px]">A partir de:</span>
              <strong className="text-[#a3e635] font-black">R$ 8,00</strong>
            </div>
          </div>

          {/* 4. W-TÁXI */}
          <div 
            onClick={onGoToPassengerApp}
            className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-[#a3e635]/60 transition-all cursor-pointer group space-y-2"
          >
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-xl bg-[#142607] border border-[#a3e635]/30 flex items-center justify-center text-amber-400 text-lg">
                🚕
              </div>
              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300">
                Faixa Exclusiva
              </span>
            </div>
            <div>
              <div className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
                W-TÁXI
              </div>
              <div className="text-[10px] text-neutral-400">Trânsito livre nas vias</div>
            </div>
            <div className="pt-1 border-t border-neutral-800 flex items-baseline justify-between text-xs">
              <span className="text-neutral-500 text-[10px]">A partir de:</span>
              <strong className="text-[#a3e635] font-black">R$ 8,00</strong>
            </div>
          </div>
        </div>
      </div>

      {/* ACESSOS RÁPIDOS PRINCIPAIS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {/* CARD W-BANK */}
        <div 
          onClick={onGoToWBank}
          className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 hover:border-[#a3e635]/50 transition-all cursor-pointer group space-y-3"
        >
          <div className="w-10 h-10 rounded-2xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
              W-BANK (Painel Financeiro)
            </h3>
            <p className="text-[11px] text-neutral-400 mt-1">
              Carteira digital integrada, extrato transparente de repasses de 90% e liquidação instantânea via PIX.
            </p>
          </div>
          <div className="text-[11px] font-bold text-[#a3e635] flex items-center gap-1">
            <span>Acessar Carteira</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* CARD BIOGRAFIA OFICIAL */}
        <div 
          onClick={onGoToBio}
          className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 hover:border-[#a3e635]/50 transition-all cursor-pointer group space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-2xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
              <BookOpen className="w-5 h-5" />
            </div>
            <FounderOfficialPhoto variant="avatar" className="w-10 h-10" />
          </div>
          <div>
            <h3 className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
              Biografia Oficial & Governança
            </h3>
            <p className="text-[11px] text-neutral-400 mt-1">
              Conheça a história do fundador Diego Wallace, o registro do CNPJ e os pilares de justiça social da empresa.
            </p>
          </div>
          <div className="text-[11px] font-bold text-[#a3e635] flex items-center gap-1">
            <span>Ler História Institucional</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* CARD CENTRAL OPERACIONAL */}
        <div 
          onClick={onGoToCentral}
          className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 hover:border-[#a3e635]/50 transition-all cursor-pointer group space-y-3"
        >
          <div className="w-10 h-10 rounded-2xl bg-[#142607] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635]">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-black text-white group-hover:text-[#a3e635] transition-colors">
              Central de Controle 24h
            </h3>
            <p className="text-[11px] text-neutral-400 mt-1">
              Área restrita de despacho master, auditoria antifraude por CPF/IMEI, dinâmica regional e publicidades.
            </p>
          </div>
          <div className="text-[11px] font-bold text-[#a3e635] flex items-center gap-1">
            <span>Acessar Painel Master</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* BANNERS DE CLIENTES LOCAIS (ADS / PATROCÍNIOS GERENCIADOS PELA CENTRAL) */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-black text-white uppercase tracking-wider">
              Parceiros Locais em Destaque
            </span>
            <span className="px-2 py-0.5 rounded-full bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[9px] font-extrabold uppercase">
              Vantagens W-DRIVER
            </span>
          </div>
          <span className="text-[10px] text-neutral-500">
            Espetinhos • Farmácias • Supermercados • Postos
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {activeAds.slice(0, 4).map((ad) => (
            <div
              key={ad.id}
              className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all flex gap-3 items-center group"
            >
              <img
                src={ad.imagemUrl}
                alt={ad.empresa}
                className="w-20 h-20 rounded-xl object-cover shrink-0 border border-neutral-800"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0 space-y-1">
                <span className="text-[9px] font-bold uppercase tracking-wider text-[#a3e635] block truncate">
                  {ad.categoriaLabel}
                </span>
                <h4 className="text-xs font-bold text-white group-hover:text-[#a3e635] transition-colors truncate">
                  {ad.titulo}
                </h4>
                <p className="text-[10px] text-neutral-400 line-clamp-2 leading-tight">
                  {ad.descricao}
                </p>
                {ad.cupom && (
                  <div className="pt-0.5 flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-neutral-950 border border-neutral-800 text-[9px] font-mono text-[#a3e635]">
                      Cupom: {ad.cupom}
                    </span>
                    {ad.linkWhatsApp && (
                      <a
                        href={ad.linkWhatsApp}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[10px] font-bold text-emerald-400 hover:underline flex items-center gap-0.5"
                      >
                        <span>WhatsApp</span>
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* DADOS INSTITUCIONAIS & CNPJ */}
      <div className="p-4 rounded-3xl bg-neutral-900/60 border border-neutral-800 text-xs text-neutral-400 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-800 pb-2">
          <span className="font-bold text-neutral-200">
            W-DRIVER AMÉRICA LATINA BRASIL LTDA
          </span>
          <span className="font-mono text-[#a3e635] font-bold">
            CNPJ: {PIX_CONFIG.cnpjFormatado}
          </span>
        </div>
        <p className="text-[11px] leading-relaxed">
          Plataforma de mobilidade urbana com sede em João Pessoa - PB. Regida pelos princípios constitucionais de livre iniciativa, segurança pública e combate à precarização laboral de condutores de aplicativos.
        </p>
      </div>
    </div>
  );
};
