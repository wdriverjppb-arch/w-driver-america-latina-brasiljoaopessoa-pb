import React from 'react';
import { 
  Heart, Sparkles, MapPin, Quote, Calendar, Users, 
  Music, ShieldCheck, Award, Building, Baby, Church
} from 'lucide-react';

export const FullFounderStory: React.FC = () => {
  return (
    <div className="rounded-3xl bg-gradient-to-b from-[#0e1709] via-neutral-900 to-neutral-950 border-2 border-[#a3e635]/50 p-5 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Decorative Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#a3e635]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* HEADER DO CANTINHO RESERVADO */}
      <div className="relative z-10 border-b border-neutral-800 pb-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="px-3 py-1 rounded-full bg-[#182907] border border-[#a3e635]/60 text-[#a3e635] text-[11px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            Cantinho Reservado • Relato da Minha Experiência na Prática
          </span>
          <span className="text-[11px] font-mono text-neutral-400 bg-neutral-900 px-2.5 py-1 rounded-full border border-neutral-800">
            Biografia Oficial Completa e Rigorosamente Atualizada
          </span>
        </div>

        <div>
          <h2 className="text-lg sm:text-2xl font-black text-white leading-snug">
            A História por Trás da W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB:{' '}
            <span className="text-[#a3e635]">Da Dor da Rejeição à Liderança com Propósito</span>
          </h2>
          <p className="text-xs sm:text-sm text-neutral-300 mt-1 font-medium">
            Depoimento autêntico de <strong>Wollace Motorista</strong> (Diego Wallace de Lima Vasconcelos) sobre as raízes, dores, família, fé e o nascimento da W-DRIVER.
          </p>
        </div>
      </div>

      {/* DESTAQUES RÁPIDOS EM CARDS SUTIS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 relative z-10">
        <div className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 space-y-1">
          <div className="flex items-center gap-1.5 text-[#a3e635] text-[10px] font-black uppercase">
            <MapPin className="w-3.5 h-3.5" />
            <span>Berço & Matriz</span>
          </div>
          <p className="text-xs font-bold text-white">Bairro da Torre</p>
          <p className="text-[10px] text-neutral-400">Rua José Severino Massa Spinelli, 836 - João Pessoa/PB</p>
        </div>

        <div className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 space-y-1">
          <div className="flex items-center gap-1.5 text-[#a3e635] text-[10px] font-black uppercase">
            <Calendar className="w-3.5 h-3.5" />
            <span>Nascimento & CNH</span>
          </div>
          <p className="text-xs font-bold text-white">29 de Novembro de 1985</p>
          <p className="text-[10px] text-neutral-400">Volante aos 12 anos • CNH EAR em 2009</p>
        </div>

        <div className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 space-y-1">
          <div className="flex items-center gap-1.5 text-[#a3e635] text-[10px] font-black uppercase">
            <Church className="w-3.5 h-3.5" />
            <span>Fé & Ministério</span>
          </div>
          <p className="text-xs font-bold text-white">Pastor em 2012</p>
          <p className="text-[10px] text-neutral-400">Guiado por YHWH (YAHU) e Yeshua (Jesus Cristo)</p>
        </div>

        <div className="p-3 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 space-y-1">
          <div className="flex items-center gap-1.5 text-[#a3e635] text-[10px] font-black uppercase">
            <Users className="w-3.5 h-3.5" />
            <span>Família & Gerações</span>
          </div>
          <p className="text-xs font-bold text-white">5 Filhos e 3 Netos</p>
          <p className="text-[10px] text-neutral-400">Casado com a missionária Gilmara Vasconcelos</p>
        </div>
      </div>

      {/* TEXTO COMPLETO E DETALHADO DA BIOGRAFIA */}
      <div className="space-y-4 text-xs sm:text-sm text-neutral-300 leading-relaxed font-normal relative z-10">
        
        {/* PARÁGRAFO 1 & 2: ORIGEM E O BAIRRO DA TORRE */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <p>
            A história da <strong>W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB</strong> não nasceu em um escritório de tecnologia ou em um berço de ouro. Ela começou na dor, no trânsito, na fé e no legado de uma família que ensinou o verdadeiro valor do trabalho, da honestidade e do amor.
          </p>
          <p>
            Natural de João Pessoa, Paraíba, nascido e criado no Bairro da Torre — na <strong>Rua José Severino Massa Spinelli, 836</strong>, local onde a empresa está oficialmente registrada —, Wollace traz no DNA a essência de sua terra. A partir dessa matriz, projeta o futuro da empresa, que em breve contará com pontos de apoio e escritórios estratégicos espalhados por diversos bairros, regiões e cidades de todo o Brasil.
          </p>
        </div>

        {/* PARÁGRAFO 3: A IDENTIDADE DA MARCA */}
        <div className="p-4 rounded-2xl bg-[#142407] border border-[#a3e635]/40 text-neutral-200 space-y-2">
          <div className="flex items-center gap-2 text-[#a3e635] font-black text-xs uppercase">
            <Award className="w-4 h-4" />
            <span>A Alma da Marca: Wollace Motorista</span>
          </div>
          <p>
            Nascido em <strong>29 de novembro de 1985</strong>, a própria marca carrega a assinatura e a alma de seu criador: o <strong>"W"</strong> vem de Wollace (de pronúncia britânica <em>Wollace</em> ou <em>Uóllace</em>, como sua mãe com tanto carinho o ensinou), e <strong>"Driver"</strong> significa motorista. W-DRIVER, portanto, traz o significado literal e orgulhoso de <strong>"Wollace Motorista"</strong> — a união da identidade de quem esteve ao volante com a profissão de milhares de parceiros pelo país.
          </p>
        </div>

        {/* PARÁGRAFO 4: INFÂNCIA, PAI BIOLÓGICO, VOLANTE AOS 12 ANOS E MADRUGADAS */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <p>
            Ainda na infância, a ausência e o sentimento de rejeição do pai biológico deixaram marcas profundas. Ao descobrir que o pai era taxista em João Pessoa, o desejo de se aproximar fez com que a profissão de motorista se tornasse um objetivo de vida.
          </p>
          <p>
            Aos <strong>12 anos de idade</strong>, Wollace já havia começado a aprender a dirigir. Ele aprendeu observando atentamente os motoristas dentro dos carros, vizinhos com quem saía para trabalhar como ajudante na pintura de paredes. No final de semana, quando voltavam para a rua de casa, ia conduzindo o veículo e, depois, de madrugada, na <strong>Avenida Ministro José Américo de Almeida</strong> — quando o trânsito era calmo, mal existiam carros e a madrugada era completamente vazia —, aperfeiçoava a direção, sonhando com o dia em que estaria ao lado do pai no trabalho para compartilhar um abraço e uma bênção que nunca vieram. Antes disso, ainda correu e operou em depósito de gás GLP, tendo trabalhado por muitos anos entregando água mineral e gás GLP.
          </p>
        </div>

        {/* PARÁGRAFO 5: AOS 21 ANOS, OS 11 IRMÃOS, O IRMÃO WELLINGTON "CARECA" E A CURA EM YHWH & YESHUA */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <p>
            Aos <strong>21 anos</strong>, buscando o sustento de sua família e um espaço no transporte, enfrentou a frieza de uma relação não correspondida e descobriu a existência de 11 irmãos.
          </p>
          <p>
            Recentemente, teve o privilégio e a dor de viver intensamente, cuidar e realizar o sepultamento e o velório de um irmão muito querido, <strong>Wellington</strong>, de apelido carinhoso <em>Careca</em>. Eles se abençoaram muito e curtiram a vida juntos; Wollace pôde ajudá-lo no tratamento da perda da vista e na luta contra o câncer, embora ele infelizmente não tenha resistido. Restaram sua mãe, seus irmãos, irmãs, sobrinhos e sobrinhas.
          </p>
          <p className="text-[#a3e635] font-medium bg-[#142607]/60 p-3 rounded-xl border border-[#a3e635]/30">
            Em um momento de profunda iluminação e fé em <strong>YHWH (YAHU)</strong> e em seu irmão mais velho espiritualmente, <strong>Yeshua (Jesus Cristo)</strong> — cujo sangue e ensinamentos guiam sua vida —, o sentimento de idolatria que antes nutria pelo pai biológico deu lugar a uma profunda cura interior, compreendendo que sua vocação e propósito eram maiores.
          </p>
        </div>

        {/* PARÁGRAFO 6: LEGADO DOS AVÓS MATERNOS, VOVÓ GIL, VOVÔ VASCO E LIVARDO ALVES */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase">
            <Music className="w-4 h-4" />
            <span>O Legado de Amor dos Avós Maternos: Vovó Gil e Vovô Vasco</span>
          </div>
          <p>
            Sua base moral e educacional veio do amor verdadeiro de sua família. Seus avós maternos, um casal exemplar formado por <strong>Vovó Gil (Giselda de Lima Vasconcelos)</strong> e <strong>Vovô Vasco (José João de Lima Vasconcelos)</strong>, deram-lhe a criação, a educação e os valores que carrega no sangue até hoje.
          </p>
          <p>
            O avô — um homem deficiente visual extraordinário, professor de Braille e francês, aposentado pela <strong>Rádio Tabajara</strong> — tocava e afinava todos os instrumentos de corda (com exceção do baixo) e ensinou Wollace a tocar cavaquinho. Vovô Vasco participou do grupo <em>Peneira</em> e afinava os violões do famoso compositor <strong>Livardo Alves</strong> — autor da famosa <em>"Marcha da Cueca"</em>, marchinha de carnaval que toca até hoje no programa de Silvio Santos —, que era seu vizinho no bairro da Torre.
          </p>
          <p>
            Desde pequeno, Wollace ia à casa dele para comprar cigarro e trazia as compras de dona Nita, esposa de Livardo, ajudando-a a carregar tudo para casa. Até hoje, ele mantém forte amizade e carinho por toda aquela família, que mora no mesmo lugar, vizinha à casa de seus avós na Torre.
          </p>
          <p>
            A <strong>Vovó Gil</strong> também construiu uma linda história na inclusão e na educação: foi professora no Instituto dos Cegos da Paraíba (onde o Vovô Vasco também lecionou) e prestou relevantes serviços à <strong>FUNAD</strong> (Fundação Centro Integrado de Apoio à Pessoa com Deficiência). Esse legado de amor, ensino e dignidade deixou uma marca eterna em sua vida.
          </p>
        </div>

        {/* PARÁGRAFO 7: A MÃE JANDACIRA, O CHOKITO NO SENAC E O EXEMPLO DE TRABALHO */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <div className="flex items-center gap-2 text-pink-400 font-bold text-xs uppercase">
            <Heart className="w-4 h-4" />
            <span>Mãe Jandacira: O Exemplo Eterno de Amor e Trabalho</span>
          </div>
          <p>
            Ao lado deles, sua mãe, <strong>Jandacira Geusa de Lima Vasconcelos</strong>, sempre foi uma grande, protetora mãe e amiga. Ela tentou todos os dias fazer com que Wollace fosse feliz e protegido, sendo uma criança normal mesmo sabendo da existência da dor de seu filho — sem saber exatamente o tamanho da saudade do pai e a dor da rejeição, mas sentindo que algo o machucava e fazendo de tudo para que ele ficasse bem todos os dias, com carinho, beijos, abraços, brincadeiras e presentes.
          </p>
          <p>
            Ela não deixava faltar o <em>Chokito</em> que ele comprava no fiteiro em frente ao Senac. Sua mãe trabalhou por 17 anos e hoje, aos <strong>65 anos e aposentada</strong>, continua trabalhando na melhor idade na AeC Mangabeira, sendo um verdadeiro exemplo de trabalho, amor, carinho, dedicação e respeito ao próximo.
          </p>
        </div>

        {/* PARÁGRAFO 8: RESTAURAÇÃO PATERNA COM VOVÓ ZEZÉ E VOVÔ ROBERTO */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <p>
            A restauração familiar também se manifestou do lado paterno: o carinho e o apoio vieram através de sua avó paterna, <strong>Vovó Zezé</strong>, e do <strong>Vovô Roberto</strong> (seu companheiro). Hoje, a cada visita, eles o abençoam e oram por sua vida, cobrindo seus caminhos com fé e amor intercessor.
          </p>
        </div>

        {/* PARÁGRAFO 9: 2009 NA ESTRADA, CNH COM EAR, JORNADAS DE 20H E REVOLTA CONTRA OS APPS EXPLORADORES */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <div className="flex items-center gap-2 text-sky-400 font-bold text-xs uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>A Luta nas Ruas: Da CNH EAR às 20 Horas Diárias nos Aplicativos</span>
          </div>
          <p>
            No início de sua trajetória no transporte legal de passageiros em <strong>2009</strong> — quando tirou a CNH com Atividade Remunerada (EAR) —, Wollace trabalhou com transporte de supermercado e táxi. Depois, ao migrar para as plataformas de transporte por aplicativo, conheceu de perto as injustiças de empresas tradicionais do setor que exploram o trabalhador com repasses de ganhos abusivos e jornadas exaustivas de <strong>20 horas diárias, dormindo apenas 4 horas no veículo</strong> para conseguir pagar diárias de locadoras e sustentar o lar.
          </p>
          <p>
            Sentiu a humilhação de perto, mas também contou com a solidariedade de irmãos de fé — vindos do Brasil e do mundo, pois seu Criador sempre usou pessoas de perto e de longe para lhe abençoar nos momentos mais difíceis.
          </p>
        </div>

        {/* PARÁGRAFO 10: CASAMENTO COM GILMARA, OS 5 FILHOS, MINISTÉRIO PASTORAL E OS 3 NETOS */}
        <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase">
            <Users className="w-4 h-4" />
            <span>Casamento, Ministério Pastoral e as Novas Gerações</span>
          </div>
          <p>
            Casado há mais de duas décadas com a <strong>missionária Gilmara Vasconcelos</strong>, Wollace conheceu sua esposa quando ela já era mãe de dois filhos (um menino e uma menina), que ele acolheu com todo o amor de pai quando eles tinham 8 e 9 anos de idade. Juntos, tiveram mais três filhos, formando uma abençoada família com cinco filhos.
          </p>
          <p>
            Tornou-se <strong>pastor em 2012</strong> e transformou a dor do passado em um compromisso de amor e paternidade presente. Decidiu fazer da própria vida um exemplo: dar aos seus filhos e à sua comunidade o afeto e o amparo que não teve do pai biológico.
          </p>
          <p>
            Hoje, esses enteados já cresceram e constituíram suas próprias famílias: o enteado é pai de um casal e mora com a esposa e filha em Portugal, enquanto o filho dele reside na Paraíba, em Guarabira; a enteada é mãe de uma menina que mora com ela e é pai da neta no bairro do Jardim Oceania. Ao todo, já são <strong>três netos (duas netas e um neto)</strong>.
          </p>
        </div>

        {/* PARÁGRAFO 11 & CONCLUSÃO: DO LIMÃO À LIMONADA - O NASCIMENTO DA W-DRIVER */}
        <div className="p-5 rounded-3xl bg-gradient-to-r from-[#142607] via-[#1f3b0b] to-[#142607] border-2 border-[#a3e635] text-white space-y-3 shadow-xl">
          <div className="flex items-center gap-2 text-[#a3e635] font-black text-xs uppercase tracking-wider">
            <Quote className="w-5 h-5" />
            <span>"Transformando um limão azedo em uma limonada"</span>
          </div>
          <p className="text-sm sm:text-base font-medium leading-relaxed">
            Foi assim, transformando <strong>"um limão azedo em uma limonada"</strong>, que nasceu a <strong>W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB</strong>.
          </p>
          <p className="text-xs sm:text-sm text-neutral-200 leading-relaxed">
            Fundada por <strong>Wollace Motorista</strong>, alguém que viveu a realidade da rua e entende o suor de quem está no volante, no guidão ou no taxímetro, a W-DRIVER é mais que uma plataforma de mobilidade e entregas. É um projeto de valorização do trabalhador brasileiro, com <strong>taxa justa, repasse digno de 90% e respeito humano</strong>.
          </p>
          <div className="pt-2 border-t border-[#a3e635]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-bold text-[#a3e635]">
            <span>Iniciando por João Pessoa e pela Paraíba rumo ao Nordeste, ao Brasil e ao mundo.</span>
            <span className="text-white">Liderança com tecnologia, justiça e fé.</span>
          </div>
        </div>

      </div>
    </div>
  );
};
