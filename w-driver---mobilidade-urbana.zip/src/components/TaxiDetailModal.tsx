import React from 'react';
import { ArrowLeft, Star, Bell, Info, ShieldCheck, UserCheck, Gauge } from 'lucide-react';
import { VehicleGraphic } from './VehicleGraphic';

interface TaxiDetailModalProps {
  onClose: () => void;
  onConfirm: () => void;
}

export const TaxiDetailModal: React.FC<TaxiDetailModalProps> = ({
  onClose,
  onConfirm,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div className="w-full max-w-sm bg-[#0e1210] border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800/60 bg-neutral-950">
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="text-sm font-bold text-white tracking-wide">Categoria Oficial</span>
          <div className="flex items-center gap-2">
            <button className="p-2 text-neutral-400 hover:text-amber-400">
              <Star className="w-4 h-4" />
            </button>
            <button className="p-2 text-neutral-400 hover:text-white">
              <Bell className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 flex flex-col items-center text-center space-y-4 max-h-[85vh] overflow-y-auto">
          {/* Taxi Icon / Graphic */}
          <div className="py-2">
            <VehicleGraphic type="taxi" size="lg" />
          </div>

          <div>
            <div className="flex items-center justify-center gap-2 text-2xl font-black text-white">
              <span className="text-amber-400">🚖</span> TÁXI
            </div>
            <p className="text-xs text-neutral-400 mt-1 font-medium">
              Taxímetro legal regulamentado pelo Inmetro.
            </p>
          </div>

          <div className="px-4 py-1.5 rounded-full bg-neutral-900 border border-neutral-700 text-xs font-semibold text-neutral-300">
            Categoria Táxi
          </div>

          {/* Test Mode Warning Banner (Exact copy from user screenshot) */}
          <div className="w-full p-3.5 rounded-2xl bg-amber-950/25 border border-amber-500/40 text-left flex gap-3">
            <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-[11px] text-amber-200 leading-relaxed">
              <strong className="block text-amber-300 font-bold mb-0.5">
                Por enquanto estamos em modo teste.
              </strong>
              O passageiro solicita a categoria Táxi e o valor da corrida será o do taxímetro, legal e regulamentado pelo Inmetro.
            </div>
          </div>

          {/* 3 Value Proposition Cards (Exact copy from user screenshot) */}
          <div className="w-full grid grid-cols-3 gap-2">
            <div className="p-2.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1.5">
              <Gauge className="w-5 h-5 text-[#a3e635]" />
              <span className="text-[10px] text-neutral-300 font-semibold leading-tight">
                Taxímetro legal regulamentado pelo Inmetro
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1.5">
              <UserCheck className="w-5 h-5 text-[#a3e635]" />
              <span className="text-[10px] text-neutral-300 font-semibold leading-tight">
                Motorista profissional
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-neutral-900/90 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1.5">
              <ShieldCheck className="w-5 h-5 text-[#a3e635]" />
              <span className="text-[10px] text-neutral-300 font-semibold leading-tight">
                Viagem segura
              </span>
            </div>
          </div>

          {/* Estimate Display */}
          <div className="w-full p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between">
            <div className="text-left">
              <div className="text-[10px] text-neutral-400 font-medium">Estimativa da corrida</div>
              <div className="text-lg font-black text-[#a3e635]">
                R$ 8,00 <span className="text-[11px] text-neutral-400 font-normal">(taxímetro)</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-neutral-400 font-medium">Tempo estimado</div>
              <div className="text-sm font-bold text-white">⏱️ 5 min</div>
            </div>
          </div>

          {/* Action Button */}
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-sm transition-all shadow-[0_4px_16px_rgba(163,230,53,0.3)] flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Solicitar agora</span>
            <span>➔</span>
          </button>
        </div>
      </div>
    </div>
  );
};
