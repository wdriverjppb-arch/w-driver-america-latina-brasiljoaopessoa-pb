import React, { useState, useEffect } from 'react';
import { QrCode, Copy, CheckCircle2, ArrowLeft, Clock, ShieldCheck, Sparkles, Building2, Landmark, Check, Eye } from 'lucide-react';
import { RideData } from '../types';
import { PIX_CONFIG, generatePixCopiaECola, getPixQrCodeUrl } from '../utils/pix';

interface PixPaymentModalProps {
  ride: RideData;
  onPaymentSuccess: () => void;
  onBack: () => void;
}

export const PixPaymentModal: React.FC<PixPaymentModalProps> = ({
  ride,
  onPaymentSuccess,
  onBack,
}) => {
  const [activeView, setActiveView] = useState<'qrcode' | 'copiacola'>('qrcode');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedCnpj, setCopiedCnpj] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(900); // 15 mins
  const [isProcessing, setIsProcessing] = useState(false);

  // Verifica se o Administrador carregou um QR Code personalizado no Firebase/Configurações
  const customUploadedQr = localStorage.getItem('wdriver_custom_pix_qr_code');

  // Calcula o código Pix EMV oficial com o valor da corrida e a chave CNPJ oficial da empresa
  const pixCode = ride.codigoPix && ride.codigoPix.includes('br.gov.bcb.pix')
    ? ride.codigoPix
    : generatePixCopiaECola(ride.valorTotal, ride.id.slice(-6));

  const qrCodeUrl = customUploadedQr || getPixQrCodeUrl(pixCode, 320);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(pixCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const handleCopyCnpj = () => {
    navigator.clipboard.writeText(PIX_CONFIG.cnpjFormatado);
    setCopiedCnpj(true);
    setTimeout(() => setCopiedCnpj(false), 3000);
  };

  const handleSimulatePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onPaymentSuccess();
    }, 800);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-[#0d120d] border border-neutral-800 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col space-y-3.5 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800/80 pb-3">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar</span>
        </button>
        <div className="flex items-center gap-1 text-xs font-bold text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>PIX Oficial • W-DRIVER</span>
        </div>
      </div>

      {/* Ride Summary Pill */}
      <div className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-xs">
        <div className="flex justify-between items-center text-neutral-400 mb-1">
          <span className="font-bold text-white">{ride.categoria.name}</span>
          <span>{ride.distanciaKm.toFixed(1)} km • {ride.tempoEstimadoMin} min</span>
        </div>
        <div className="text-neutral-300 font-medium truncate">
          {ride.origem.split(',')[0]} ➔ {ride.destino.split(',')[0]}
        </div>
      </div>

      {/* Amount Display */}
      <div className="text-center py-2.5 bg-gradient-to-b from-[#142308] to-transparent rounded-2xl border border-[#a3e635]/30">
        <div className="text-xs text-neutral-400 font-medium">Valor total da viagem</div>
        <div className="text-3xl font-black text-[#a3e635] tracking-tight">
          R$ {ride.valorTotal.toFixed(2).replace('.', ',')}
        </div>
        <div className="flex items-center justify-center gap-2 mt-1 text-[11px] text-neutral-400">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>Vencimento em: <strong className="text-white font-mono">{formatTimer(secondsLeft)}</strong></span>
        </div>
      </div>

      {/* SELETORES OFICIAIS EXIGIDOS: EXIBIR QR CODE vs COPIAR PIX */}
      <div className="grid grid-cols-2 gap-2 bg-neutral-950 p-1.5 rounded-2xl border border-neutral-800">
        <button
          type="button"
          onClick={() => setActiveView('qrcode')}
          className={`py-2.5 px-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeView === 'qrcode'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/50 shadow-[0_0_15px_rgba(163,230,53,0.2)]'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>EXIBIR QR CODE</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveView('copiacola')}
          className={`py-2.5 px-3 rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeView === 'copiacola'
              ? 'bg-[#1a2e05] text-[#a3e635] border border-[#a3e635]/50 shadow-[0_0_15px_rgba(163,230,53,0.2)]'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Copy className="w-4 h-4" />
          <span>COPIAR PIX</span>
        </button>
      </div>

      {/* ÁREA VISUAL DO QR CODE (Ocupando aprox. 50% da área útil do card em celulares) */}
      {activeView === 'qrcode' ? (
        <div className="flex flex-col items-center justify-center p-4 sm:p-5 bg-white rounded-3xl shadow-2xl mx-auto w-full min-h-[300px] border-4 border-[#a3e635]/30">
          <div className="relative p-2.5 border-2 border-neutral-900 rounded-2xl bg-white flex items-center justify-center shadow-md">
            <img
              src={qrCodeUrl}
              alt="QR Code Pix Oficial W-DRIVER"
              className="w-56 h-56 sm:w-60 sm:h-60 object-contain rounded-lg"
              onError={(e) => {
                // Fallback para caso ocorra falha de rede
                e.currentTarget.src = getPixQrCodeUrl(pixCode, 280);
              }}
            />
          </div>
          <span className="text-xs text-neutral-900 font-black mt-2.5 text-center flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Aponte a câmera do app do seu banco</span>
          </span>
          <span className="text-[10px] text-neutral-600 font-semibold text-center mt-0.5">
            Pagamento instantâneo para a conta oficial da empresa
          </span>
        </div>
      ) : (
        /* ÁREA VISUAL DO COPIAR PIX */
        <div className="space-y-3 p-4 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="flex justify-between items-center text-xs">
            <label className="font-bold text-neutral-300 block">
              Código PIX Copia e Cola Oficial:
            </label>
            <span className="text-[10px] text-[#a3e635] font-bold">
              Padrão BR Code EMV
            </span>
          </div>

          <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded-xl p-2.5">
            <input
              type="text"
              readOnly
              value={pixCode}
              className="bg-transparent text-xs text-emerald-300 font-mono flex-1 outline-none truncate select-all"
            />
          </div>

          <button
            type="button"
            onClick={handleCopyCode}
            className="w-full py-3 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
          >
            {copiedCode ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>CÓDIGO PIX COPIADO COM SUCESSO!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>COPIAR CÓDIGO PIX AGORA</span>
              </>
            )}
          </button>

          <p className="text-[10px] text-neutral-400 text-center leading-relaxed">
            Abra o aplicativo do seu banco, escolha a opção <strong>Pix Copia e Cola</strong> e cole o código acima.
          </p>
        </div>
      )}

      {/* Dados Oficiais da Empresa e Favorecido */}
      <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-1.5 text-xs">
        <div className="flex items-center gap-2 text-neutral-300 font-bold border-b border-neutral-800 pb-1.5">
          <Landmark className="w-3.5 h-3.5 text-[#a3e635]" />
          <span>Dados do Recebedor Oficial</span>
        </div>

        <div className="space-y-1 text-[11px]">
          <div className="flex justify-between items-start gap-2">
            <span className="text-neutral-500 shrink-0">Favorecido:</span>
            <span className="text-neutral-200 font-bold text-right truncate">
              {PIX_CONFIG.favorecido}
            </span>
          </div>

          <div className="flex justify-between items-center gap-2">
            <span className="text-neutral-500">Chave CNPJ:</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[#a3e635] font-mono font-bold">
                {PIX_CONFIG.cnpjFormatado}
              </span>
              <button
                type="button"
                onClick={handleCopyCnpj}
                className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                title="Copiar CNPJ"
              >
                {copiedCnpj ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Repasse Division Info (90% / 10%) */}
      <div className="p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/20 text-xs flex items-center justify-between text-neutral-300">
        <div className="flex items-center gap-2">
          <Building2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px]">Repasse Líquido Motorista (90%):</span>
        </div>
        <strong className="text-emerald-300 font-bold text-xs">
          R$ {ride.repasseMotorista.toFixed(2).replace('.', ',')}
        </strong>
      </div>

      {/* Confirmation Button */}
      <button
        onClick={handleSimulatePayment}
        disabled={isProcessing}
        className="w-full py-3.5 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-all shadow-[0_4px_16px_rgba(163,230,53,0.3)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
      >
        {isProcessing ? (
          <span className="flex items-center gap-2">
            <span className="w-4 h-4 rounded-full border-2 border-neutral-950 border-t-transparent animate-spin" />
            Confirmando com a Central W-DRIVER...
          </span>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span>Confirmar Pagamento e Despachar</span>
          </>
        )}
      </button>
    </div>
  );
};
