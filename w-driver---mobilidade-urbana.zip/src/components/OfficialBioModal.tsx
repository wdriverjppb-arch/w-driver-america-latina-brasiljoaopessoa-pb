import React from 'react';
import { X, Heart, Shield, Award, MapPin, Sparkles, BookOpen } from 'lucide-react';
import { WDriverLogo } from './WDriverLogo';

interface OfficialBioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OfficialBioModal: React.FC<OfficialBioModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-2xl bg-[#0d120d] border-2 border-[#a3e635]/40 rounded-3xl p-5 sm:p-7 shadow-[0_0_50px_rgba(163,230,53,0.25)] text-neutral-100 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-neutral-800 pb-4 mb-4 shrink-0">
          <div className="flex items-center gap-3">
            <WDriverLogo size="md" />
            <div>
              <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-tight flex items-center gap-2">
                <span>Biografia Oficial W-DRIVER</span>
                <span className="px-2 py-0.5 rounded-md bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[10px] font-bold">
                  Fundador Wollace
                </span>
              </h2>
              <p className="text-[11px] text-neutral-400">
                W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB • CNPJ: 55.348.639/0001-54
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Scrollable */}
        <div className="overflow-y-auto pr-2 space-y-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
          {/* Badge Origin */}
          <div className="p-3 rounded-2xl bg-[#142308]/60 border border-[#a3e635]/30 flex items-center gap-2.5">
            <MapPin className="w-5 h-5 text-[#a3e635] shrink-0" />
            <span className="text-xs text-neutral-200">
              <strong>Registro Matriz:</strong> Rua José Severino Massa Spinelli, 836, Bairro da Torre, João Pessoa - PB.
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800 italic text-neutral-300 text-center font-medium">
            <span className="text-[#a3e635] font-black text-sm block not-italic mb-1">
              "Quem escolhe preço corre riscos. Quem escolhe a W-DRIVER escolhe chegar bem!"
            </span>
            Slogan Oficial Registrado
          </div>

          <h3 className="text-sm font-black text-[#a3e635] uppercase tracking-wider pt-2 border-t border-neutral-900">
            A História por Trás da W-DRIVER: Da Dor da Rejeição à Liderança com Propósito
          </h3>

          <p>
            A história da <strong>W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB</strong> não nasceu em um escritório de tecnologia ou em um berço de ouro. Ela começou na dor, no trânsito, na fé e no legado de uma família que ensinou o verdadeiro valor do trabalho, da honestidade e do amor.
          </p>

          <p>
            Natural de João Pessoa, Paraíba, nascido e criado no Bairro da Torre — na <strong>Rua José Severino Massa Spinelli, 836</strong>, local onde a empresa está oficialmente registrada —, <strong>Wollace</strong> traz no DNA a essência de sua terra. A partir dessa matriz, projeta o futuro da empresa, que em breve contará com pontos de apoio e escritórios estratégicos espalhados por diversos bairros, regiões e cidades de todo o Brasil.
          </p>

          <p>
            Nascido em <strong>29 de novembro de 1985</strong>, a própria marca carrega a assinatura e a alma de seu criador: o <strong>"W"</strong> vem de Wollace (de pronúncia britânica Wollace ou Uóllace, como sua mãe com tanto carinho o ensinou), e <strong>"Driver"</strong> significa motorista. W-DRIVER, portanto, traz o significado literal e orgulhoso de <strong>"Wollace Motorista"</strong> — a união da identidade de quem esteve ao volante com a profissão de milhares de parceiros pelo país.
          </p>

          <h4 className="text-xs font-bold text-white uppercase tracking-wider text-amber-400">
            O Início no Asfalto e a Forja do Caráter
          </h4>
          <p>
            Ainda na infância, a ausência e o sentimento de rejeição do pai biológico deixaram marcas profundas. Ao descobrir que o pai era taxista em João Pessoa, o desejo de se aproximar fez com que a profissão de motorista se tornasse um objetivo de vida. Aos 12 anos de idade, Wollace já havia começado a aprender a dirigir. Ele aprendeu observando atentamente os motoristas dentro dos carros, vizinhos com quem saía para trabalhar como ajudante na pintura de paredes.
          </p>

          <p>
            No final de semana, quando voltavam para a rua de casa, ia conduzindo o veículo e, depois, de madrugada, na <strong>Avenida Ministro José Américo de Almeida</strong> — quando o trânsito era calmo, mal existiam carros e a madrugada era completamente vazia —, aperfeiçoava a direção, sonhando com o dia em que estaria ao lado do pai no trabalho para compartilhar um abraço e uma bênção que nunca vieram. Antes disso, ainda correu e operou em depósito de gás GLP, tendo trabalhado por muitos anos entregando água mineral e gás GLP.
          </p>

          <p>
            Aos 21 anos, buscando o sustento de sua família e um espaço no transporte, enfrentou a frieza de uma relação não correspondida e descobriu a existência de 11 irmãos. Recentemente, teve o privilégio e a dor de viver intensamente, cuidar e realizar o sepultamento e o velório de um irmão muito querido, <strong>Wellington, de apelido carinhoso Careca</strong>. Eles se abençoaram muito e curtiram a vida juntos; Wollace pôde ajudá-lo no tratamento da perda da vista e na luta contra o câncer, embora ele infelizmente não tenha resistido. Restaram sua mãe, seus irmãos, irmãs, sobrinhos e sobrinhas.
          </p>

          <p>
            Em um momento de profunda iluminação e fé em <strong>YHWH (YAHU)</strong> e em seu irmão mais velho espiritualmente, <strong>Yeshua (Jesus Cristo)</strong> — cujo sangue e ensinamentos guiam sua vida —, o sentimento de idolatria que antes nutria pelo pai biológico deu lugar a uma profunda cura interior, compreendendo que sua vocação e propósito eram maiores.
          </p>

          <h4 className="text-xs font-bold text-white uppercase tracking-wider text-[#a3e635]">
            O Legado de Amor: Vovô Vasco, Vovó Gil e Dona Jandacira
          </h4>
          <p>
            Sua base moral e educacional veio do amor verdadeiro de sua família. Seus avós maternos, um casal exemplar formado por <strong>Vovó Gil (Giselda de Lima Vasconcelos)</strong> e <strong>Vovô Vasco (José João de Lima Vasconcelos)</strong>, deram-lhe a criação, a educação e os valores que carrega no sangue até hoje. O avô — um homem deficiente visual extraordinário, professor de Braille e francês, aposentado pela <strong>Rádio Tabajara</strong> — tocava e afinava todos os instrumentos de corda (com exceção do baixo) e ensinou Wollace a tocar cavaquinho.
          </p>

          <p>
            Vovô Vasco participou do grupo Peneira e afinava os violões do famoso compositor <strong>Livardo Alves</strong> — autor da famosa "Marcha da Cueca", marchinha de carnaval que toca até hoje no programa de Silvio Santos —, que era seu vizinho no bairro da Torre. Desde pequeno, Wollace ia à casa dele para comprar cigarro e trazia as compras de dona Nita, esposa de Livardo, ajudando-a a carregar tudo para casa. Até hoje, ele mantém forte amizade e carinho por toda aquela família, que mora no mesmo lugar, vizinha à casa de seus avós na Torre.
          </p>

          <p>
            A <strong>Vovó Gil</strong> também construiu uma linda história na inclusão e na educação: foi professora no Instituto dos Cegos da Paraíba (onde o Vovô Vasco também lecionou) e prestou relevantes serviços à <strong>FUNAD</strong> (Fundação Centro Integrado de Apoio à Pessoa com Deficiência). Esse legado de amor, ensino e dignidade deixou uma marca eterna em sua vida.
          </p>

          <p>
            Ao lado deles, sua mãe, <strong>Jandacira Geusa de Lima Vasconcelos</strong>, sempre foi uma grande, protetora mãe e amiga. Ela tentou todos os dias fazer com que Wollace fosse feliz e protegido, sendo uma criança normal mesmo sabendo da existência da dor de seu filho — sem saber exatamente o tamanho da saudade do pai e a dor da rejeição, mas sentindo que algo o machucava e fazendo de tudo para que ele ficasse bem todos os dias, com carinho, beijos, abraços, brincadeiras e presentes. Ela não deixava faltar o chokito que ele comprava no fiteiro em frente ao Senac. Sua mãe trabalhou por 17 anos e hoje, aos 65 anos e aposentada, continua trabalhando na melhor idade na <strong>AeC Mangabeira</strong>, sendo um verdadeiro exemplo de trabalho, amor, carinho, dedicação e respeito ao próximo.
          </p>

          <p>
            A restauração familiar também se manifestou do lado paterno: o carinho e o apoio vieram através de sua avó paterna, <strong>Vovó Zezé</strong>, e do <strong>Vovô Roberto</strong> (seu companheiro). Hoje, a cada visita, eles o abençoam e oram por sua vida, cobrindo seus caminhos com fé e amor intercessor.
          </p>

          <h4 className="text-xs font-bold text-white uppercase tracking-wider text-sky-400">
            Família, Ministério e a Luta Contra a Exploração
          </h4>
          <p>
            No início de sua trajetória no transporte legal de passageiros em 2009 — quando tirou a CNH com Atividade Remunerada (EAR) —, Wollace trabalhou com transporte de supermercado e táxi. Depois, ao migrar para as plataformas de transporte por aplicativo, conheceu de perto as injustiças de empresas tradicionais do setor que exploram o trabalhador com repasses de ganhos abusivos e jornadas exaustivas de 20 horas diárias, dormindo apenas 4 horas no veículo para conseguir pagar diárias de locadoras e sustentar o lar. Sentiu a humilhação de perto, mas também contou com a solidariedade de irmãos de fé — vindos do Brasil e do mundo, pois seu Criador sempre usou pessoas de perto e de longe para lhe abençoar nos momentos mais difíceis.
          </p>

          <p>
            Casado há mais de duas décadas com a missionária <strong>Gilmara Vasconcelos</strong>, Wollace conheceu sua esposa quando ela já era mãe de dois filhos (um menino e uma menina), que ele acolheu com todo o amor de pai quando eles tinham 8 e 9 anos de idade. Juntos, tiveram mais três filhos, formando uma abençoada família com cinco filhos. <strong>Tornou-se pastor em 2012</strong> e transformou a dor do passado em um compromisso de amor e paternidade presente. Decidiu fazer da própria vida um exemplo: dar aos seus filhos e à sua comunidade o afeto e o amparo que não teve do pai biológico.
          </p>

          <p>
            Hoje, esses enteados já cresceram e constituíram suas próprias famílias: o enteado é pai de um casal e mora com a esposa e filha em Portugal, enquanto o filho dele reside na Paraíba, em Guarabira; a enteada é mãe de uma menina que mora com ela e é pai da neta no bairro do Jardim Oceania. Ao todo, já são três netos (duas netas e um neto).
          </p>

          <div className="p-4 rounded-2xl bg-neutral-900 border border-[#a3e635]/40 text-neutral-100">
            <h4 className="font-black text-[#a3e635] text-sm mb-1 uppercase">
              O Nascimento da W-DRIVER
            </h4>
            <p className="text-xs text-neutral-300 mb-0">
              Foi assim, transformando <em>"um limão azedo em uma limonada"</em>, que nasceu a <strong>W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB</strong>.
              Fundada por Wollace Motorista, alguém que viveu a realidade da rua e entende o suor de quem está no volante, no guidão ou no taxímetro, a W-DRIVER é mais que uma plataforma de mobilidade e entregas. É um projeto de valorização do trabalhador brasileiro, com taxa justa, repasse digno e respeito humano.
              Iniciando por João Pessoa e pela Paraíba, o objetivo é expandir para o Nordeste, o Brasil e o mundo, provando que é possível liderar com tecnologia, justiça e fé.
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-neutral-800 mt-4 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-neutral-400">
            CNPJ: 55.348.639/0001-54
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            Fechar Biografia
          </button>
        </div>
      </div>
    </div>
  );
};
