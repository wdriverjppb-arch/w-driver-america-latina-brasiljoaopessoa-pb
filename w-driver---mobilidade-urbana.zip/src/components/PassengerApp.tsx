import React, { useState } from 'react';
import { 
  Menu, Bell, User, Star, ArrowUpDown, MapPin, Navigation, 
  Home, Briefcase, Heart, Gift, Compass, Search, ChevronRight,
  Zap, Info, Check, Shield, Crosshair, RefreshCw, ArrowRight,
  Clock, MessageSquare, Tag, Crown, Car
} from 'lucide-react';
import { CategoryInfo, ServiceCategory, AdBanner, CentralAlert, SavedPlace, LuxuryContract, LostItemReport, RefundRequest, RideData } from '../types';
import { CATEGORIES, JOAO_PESSOA_LOCATIONS } from '../data/categories';
import { VehicleGraphic } from './VehicleGraphic';
import { InteractiveMap } from './InteractiveMap';
import { TaxiDetailModal } from './TaxiDetailModal';
import { CategoryDetailModal } from './CategoryDetailModal';
import { WDriverLogo } from './WDriverLogo';
import { SosModal } from './SosModal';
import { PassengerMenuDrawer } from './passenger/PassengerMenuDrawer';
import { LuxuryContractModal } from './passenger/LuxuryContractModal';
import { SavedPlacesModal } from './passenger/SavedPlacesModal';
import { 
  CreditsModal, RefundModal, LostItemsModal, ReferralModal, 
  PromotionsModal, HelpCenterModal 
} from './passenger/PassengerFeatureModals';

interface PassengerAppProps {
  origem: string;
  setOrigem: (val: string) => void;
  destino: string;
  setDestino: (val: string) => void;
  distanciaKm: number;
  setDistanciaKm: (val: number) => void;
  selectedCategory: CategoryInfo;
  setSelectedCategory: (cat: CategoryInfo) => void;
  categories?: CategoryInfo[];
  surgeActive: boolean;
  setSurgeActive: (val: boolean) => void;
  onProceedToPayment: () => void;
  onActivateSurgeAndGoToCentral?: () => void;
  alerts?: CentralAlert[];
  ads?: AdBanner[];
  onGoToHome?: () => void;
  onGoToWBank?: () => void;
  onGoToBio?: () => void;
  allRides?: RideData[];
  currentRide?: RideData | null;
  onGoToPayment?: () => void;
  onSubmitContract?: (contract: LuxuryContract) => void;
  onSubmitRefund?: (refund: RefundRequest) => void;
  onSubmitLostItem?: (report: LostItemReport) => void;
}

export const PassengerApp: React.FC<PassengerAppProps> = ({
  origem,
  setOrigem,
  destino,
  setDestino,
  distanciaKm,
  setDistanciaKm,
  selectedCategory,
  setSelectedCategory,
  categories = CATEGORIES,
  surgeActive,
  setSurgeActive,
  onProceedToPayment,
  onActivateSurgeAndGoToCentral,
  alerts = [],
  ads = [],
  onGoToHome,
  onGoToWBank,
  onGoToBio,
  allRides = [],
  currentRide,
  onGoToPayment,
  onSubmitContract,
  onSubmitRefund,
  onSubmitLostItem,
}) => {
  // Modal states
  const [showTaxiModal, setShowTaxiModal] = useState(false);
  const [selectedModalCategory, setSelectedModalCategory] = useState<CategoryInfo | null>(null);
  const [showSosModal, setShowSosModal] = useState(false);
  const [showMenuDrawer, setShowMenuDrawer] = useState(false);
  const [showLuxuryContractModal, setShowLuxuryContractModal] = useState(false);
  const [showSavedPlacesModal, setShowSavedPlacesModal] = useState(false);
  const [showCreditsModal, setShowCreditsModal] = useState(false);
  const [showRefundModal, setShowRefundModal] = useState(false);
  const [showLostItemsModal, setShowLostItemsModal] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const [showPromotionsModal, setShowPromotionsModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showNotificationPopup, setShowNotificationPopup] = useState(false);

  // User state
  const [userCredits, setUserCredits] = useState(15.0);
  const [activeBottomNav, setActiveBottomNav] = useState<'inicio' | 'historico' | 'favoritos' | 'mensagens' | 'perfil'>('inicio');
  const [isLocatingOrigin, setIsLocatingOrigin] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Saved places state
  const [savedPlaces, setSavedPlaces] = useState<SavedPlace[]>([
    { id: 'p-1', type: 'casa', title: 'Casa', address: 'Av. Cabo Branco, 1500, João Pessoa - PB' },
    { id: 'p-2', type: 'trabalho', title: 'Trabalho', address: 'Manaíra Shopping, Av. Flávio R. Coutinho, 805, JP' },
    { id: 'p-3', type: 'favorito', title: 'Orla de Tambaú', address: 'Busto de Tamandaré, Tambaú, João Pessoa - PB' },
  ]);

  // Geocoordinates (Torre to Tambaú)
  const [origemCoords, setOrigemCoords] = useState<[number, number]>([-7.1238, -34.8647]);
  const [destinoCoords, setDestinoCoords] = useState<[number, number]>([-7.1166, -34.8242]);

  // Official W-DRIVER Calculation:
  // Regra 1: Até 4 km = Taxa Fixa da categoria
  // Regra 2: Acima de 4 km = Taxa Fixa + ((km - 4) * kmAdicional)
  // W-TÁXI: Até 1 km = R$ 10,00; Demais viagens: Taxímetro legal
  // W-LUXO: Exclusivamente por contrato
  const calculateTotal = (cat: CategoryInfo) => {
    if (cat.id === 'w_luxo') {
      return 0; // Sob contrato
    }
    if (cat.id === 'taxi') {
      if (distanciaKm <= 1) return 10.0;
      return Math.round((5.5 + distanciaKm * 3.20) * 100) / 100;
    }
    let fare = cat.baseFare;
    if (distanciaKm > 4) {
      const extraKm = distanciaKm - 4;
      fare += extraKm * cat.kmAdicional;
    }
    if (surgeActive) {
      fare *= 3.5;
    }
    return Math.round(fare * 100) / 100;
  };

  const currentTotal = calculateTotal(selectedCategory);

  const swapLocations = () => {
    const tempOrigem = origem;
    const tempCoords = origemCoords;
    setOrigem(destino);
    setOrigemCoords(destinoCoords);
    setDestino(tempOrigem);
    setDestinoCoords(tempCoords);
  };

  const handleSelectPreset = (bairro: string, coords: [number, number], km?: number) => {
    setDestino(`João Pessoa, ${bairro}`);
    setDestinoCoords(coords);
    if (km) {
      setDistanciaKm(km);
    } else {
      const dLat = coords[0] - origemCoords[0];
      const dLng = coords[1] - origemCoords[1];
      const approxKm = Math.max(2.5, Math.round(Math.sqrt(dLat * dLat + dLng * dLng) * 111 * 10) / 10);
      setDistanciaKm(approxKm);
    }
  };

  const handleCategoryCardClick = (cat: CategoryInfo) => {
    if (cat.id === 'w_luxo') {
      setShowLuxuryContractModal(true);
      return;
    }
    if (cat.id === 'taxi') {
      setSelectedCategory(cat);
      setShowTaxiModal(true);
      return;
    }
    setSelectedCategory(cat);
  };

  const handleMapUpdateCoords = (newOrigemCoords: [number, number], newDestinoCoords: [number, number]) => {
    setOrigemCoords(newOrigemCoords);
    setDestinoCoords(newDestinoCoords);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-[#0a0a0a] text-neutral-100 rounded-3xl overflow-hidden border border-neutral-800 shadow-2xl flex flex-col relative pb-20 select-none">
      
      {/* 1. TOP HEADER (Exact matching Image 1: Hamburger Menu, Logo, Bell Notification) */}
      <div className="p-3.5 bg-neutral-900/90 border-b border-neutral-800 backdrop-blur-md flex items-center justify-between sticky top-0 z-30">
        <button
          type="button"
          onClick={() => setShowMenuDrawer(true)}
          className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
          title="Abrir Menu W-DRIVER"
        >
          <Menu className="w-5 h-5 text-[#a3e635]" />
        </button>

        <div className="flex flex-col items-center">
          <WDriverLogo size="sm" />
          <span className="text-[10px] font-black text-[#a3e635] tracking-wide mt-0.5">
            Transporte legal de passageiros
          </span>
        </div>

        <div className="relative">
          <button
            type="button"
            onClick={() => setShowNotificationPopup(!showNotificationPopup)}
            className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors relative cursor-pointer"
            title="Notificações"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-[#a3e635] border-2 border-neutral-900 animate-pulse" />
          </button>

          {showNotificationPopup && (
            <div className="absolute right-0 top-12 w-64 p-3 bg-neutral-900 border border-neutral-800 rounded-2xl shadow-xl z-50 text-xs space-y-2 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-1.5">
                <strong className="text-white">Notificações</strong>
                <span className="text-[10px] text-[#a3e635] font-bold">João Pessoa</span>
              </div>
              <div className="p-2 rounded-xl bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-300">
                ⭐ Bem-vindo ao W-DRIVER Oficial! Corridas com tarifa justa e segurança garantida.
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-3.5 space-y-3.5">
        
        {/* LIVE ACTIVE RIDE & 4-DIGIT PIN BANNER */}
        {currentRide && currentRide.status !== 'concluida' && currentRide.status !== 'cancelada' && (
          <div className="p-4 rounded-3xl bg-gradient-to-b from-[#142608] to-neutral-900 border-2 border-[#a3e635] shadow-[0_0_24px_rgba(163,230,53,0.25)] space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#a3e635] animate-ping" />
                <span className="text-xs font-black text-white uppercase tracking-wide">
                  {currentRide.status === 'aguardando_pix' && '💳 Pagamento Pix Pendente'}
                  {currentRide.status === 'paga_central' && '⏳ Pix Pago • Em Análise na Central'}
                  {currentRide.status === 'despachada' && '📡 Central Despachando Motorista'}
                  {currentRide.status === 'motorista_a_caminho' && '🚗 Motorista a Caminho'}
                  {currentRide.status === 'motorista_no_local' && '📍 Motorista Chegou ao Local!'}
                  {currentRide.status === 'em_viagem' && '🚀 Viagem em Andamento'}
                </span>
              </div>
              <span className="text-xs font-black text-[#a3e635]">
                R$ {currentRide.valorTotal.toFixed(2).replace('.', ',')}
              </span>
            </div>

            {/* PIN DE SEGURANÇA 4 DÍGITOS */}
            <div className="p-3 rounded-2xl bg-neutral-950 border border-[#a3e635]/50 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-extrabold text-neutral-400 tracking-wider block">
                  CÓDIGO DE EMBARQUE (PIN):
                </span>
                <span className="text-[11px] text-neutral-300">
                  Apresente ao motorista para iniciar a corrida
                </span>
              </div>
              <div className="px-3.5 py-1.5 rounded-xl bg-[#a3e635] text-neutral-950 font-mono font-black text-base tracking-widest shadow-md">
                {currentRide.pin || '4821'}
              </div>
            </div>

            {/* Detalhes da viagem */}
            <div className="text-xs text-neutral-300 flex items-center justify-between">
              <div>
                <strong className="text-white block">{currentRide.categoria.name}</strong>
                <span className="text-[11px] text-neutral-400">
                  {currentRide.origem.split(',')[0]} ➔ {currentRide.destino.split(',')[0]}
                </span>
              </div>
              {currentRide.status === 'aguardando_pix' && onGoToPayment && (
                <button
                  type="button"
                  onClick={onGoToPayment}
                  className="px-3 py-1.5 rounded-xl bg-[#a3e635] text-neutral-950 font-black text-xs cursor-pointer shadow-md"
                >
                  Pagar PIX
                </button>
              )}
            </div>
          </div>
        )}

        {/* 2. LOCATION INPUT CARD (Matching Image 1: Green dot "De onde você está?", Dotted line, Pin "Para onde vamos?", Green swap button) */}
        <div className="p-3.5 rounded-3xl bg-neutral-900 border border-neutral-800 shadow-md space-y-2 relative">
          
          {/* Origem */}
          <div className="flex items-center gap-2.5">
            <span className="w-3 h-3 rounded-full bg-[#a3e635] shrink-0 shadow-[0_0_8px_#a3e635]" />
            <div className="flex-1 min-w-0">
              <div className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                De onde você está?
              </div>
              <input
                type="text"
                value={origem}
                onChange={(e) => setOrigem(e.target.value)}
                placeholder="Minha localização atual"
                className="w-full bg-transparent text-xs font-black text-white outline-none placeholder:text-neutral-600 truncate"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowSavedPlacesModal(true)}
              className="px-2 py-1 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-[10px] font-bold text-[#a3e635] flex items-center gap-1 shrink-0"
              title="Locais Salvos"
            >
              <Star className="w-3 h-3" />
              <span>Favoritos</span>
            </button>
          </div>

          {/* Dotted separator & Swap button */}
          <div className="relative flex items-center my-0.5">
            <div className="w-3 flex justify-center">
              <div className="w-0.5 h-4 border-l-2 border-dotted border-neutral-700" />
            </div>
            <div className="flex-1 border-t border-neutral-800/80 ml-2.5" />
            <button
              type="button"
              onClick={swapLocations}
              className="absolute right-2 p-1.5 rounded-full bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 shadow-md transition-transform hover:scale-110 cursor-pointer"
              title="Inverter origem e destino"
            >
              <ArrowUpDown className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
          </div>

          {/* Destino */}
          <div className="flex items-center gap-2.5">
            <MapPin className="w-3.5 h-3.5 text-[#a3e635] shrink-0 fill-[#a3e635]" />
            <div className="flex-1 min-w-0 pr-8">
              <div className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                Para onde vamos?
              </div>
              <input
                type="text"
                value={destino}
                onChange={(e) => setDestino(e.target.value)}
                placeholder="Digite seu destino em João Pessoa"
                className="w-full bg-transparent text-xs font-black text-[#a3e635] outline-none placeholder:text-neutral-600 truncate"
              />
            </div>
          </div>

          {/* Quick preset chips */}
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pt-1.5 border-t border-neutral-800/60">
            {JOAO_PESSOA_LOCATIONS.map((loc) => (
              <button
                key={loc.bairro}
                type="button"
                onClick={() => handleSelectPreset(loc.bairro, loc.coords)}
                className="px-2.5 py-1 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-[10px] font-bold text-neutral-300 hover:text-white whitespace-nowrap transition-colors"
              >
                📍 {loc.bairro}
              </button>
            ))}
          </div>
        </div>

        {/* 3. INTERACTIVE MAP AREA (With route, floating pill 15 min • 5.2 km | R$ 15,50 Estimado) */}
        <div className="relative rounded-3xl overflow-hidden border border-neutral-800 shadow-lg">
          <InteractiveMap
            origem={origem}
            destino={destino}
            distanciaKm={distanciaKm}
            tempoMin={Math.max(5, Math.round(distanciaKm * 2.2))}
            valorEstimado={currentTotal}
            origemCoords={origemCoords}
            destinoCoords={destinoCoords}
            onUpdateCoords={handleMapUpdateCoords}
            onUpdateDistance={(km) => setDistanciaKm(km)}
          />

          {/* Top floating pill badge (Matching Image 1: Target icon + W 100% Shield) */}
          <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5 bg-neutral-950/85 backdrop-blur-md px-2.5 py-1 rounded-full border border-neutral-800 text-[10px] font-bold shadow-md">
            <Crosshair className="w-3 h-3 text-[#a3e635]" />
            <span className="text-white">W 100%</span>
            <Shield className="w-3 h-3 text-[#a3e635]" />
          </div>

          {/* Bottom floating pill inside map (Matching Image 1: 🕒 15 min • 🚗 5.2 km | R$ 15,50 Estimado) */}
          <div className="absolute bottom-3 left-3 right-3 z-10 bg-neutral-950/90 backdrop-blur-md px-3 py-2 rounded-2xl border border-neutral-800/90 shadow-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-neutral-300 font-semibold">
              <span className="flex items-center gap-1 text-[11px]">
                <Clock className="w-3.5 h-3.5 text-[#a3e635]" />
                {Math.max(5, Math.round(distanciaKm * 2.2))} min
              </span>
              <span className="text-neutral-600">•</span>
              <span className="flex items-center gap-1 text-[11px]">
                <Car className="w-3.5 h-3.5 text-[#a3e635]" />
                {distanciaKm.toFixed(1)} km
              </span>
            </div>

            <div className="text-right">
              <span className="font-black text-sm text-[#a3e635]">
                {selectedCategory.id === 'w_luxo' ? 'Sob Contrato' : `R$ ${currentTotal.toFixed(2).replace('.', ',')}`}
              </span>
              <span className="text-[9px] text-neutral-400 block -mt-0.5">Estimado</span>
            </div>
          </div>
        </div>

        {/* 4. LUGARES SALVOS (Matching Image 1: Casa, Trabalho, Favoritos) */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-neutral-300 uppercase tracking-wider">
              Lugares salvos
            </h3>
            <button
              type="button"
              onClick={() => setShowSavedPlacesModal(true)}
              className="text-[11px] font-bold text-[#a3e635] hover:underline cursor-pointer"
            >
              Ver todos
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {/* Casa */}
            <div
              onClick={() => {
                const p = savedPlaces.find((x) => x.type === 'casa');
                if (p) setDestino(p.address);
                else setShowSavedPlacesModal(true);
              }}
              className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1 cursor-pointer hover:border-neutral-700 transition-colors"
            >
              <Home className="w-5 h-5 text-[#a3e635]" />
              <span className="text-xs font-bold text-white">Casa</span>
              <span className="text-[9px] text-neutral-400 leading-tight">Adicionar endereço</span>
            </div>

            {/* Trabalho */}
            <div
              onClick={() => {
                const p = savedPlaces.find((x) => x.type === 'trabalho');
                if (p) setDestino(p.address);
                else setShowSavedPlacesModal(true);
              }}
              className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1 cursor-pointer hover:border-neutral-700 transition-colors"
            >
              <Briefcase className="w-5 h-5 text-[#a3e635]" />
              <span className="text-xs font-bold text-white">Trabalho</span>
              <span className="text-[9px] text-neutral-400 leading-tight">Adicionar endereço</span>
            </div>

            {/* Favoritos */}
            <div
              onClick={() => setShowSavedPlacesModal(true)}
              className="p-3 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col items-center justify-center text-center gap-1 cursor-pointer hover:border-neutral-700 transition-colors"
            >
              <Star className="w-5 h-5 text-[#a3e635]" />
              <span className="text-xs font-bold text-white">Favoritos</span>
              <span className="text-[9px] text-neutral-400 leading-tight">Seus lugares salvos</span>
            </div>
          </div>
        </div>

        {/* 5. ESCOLHA O SERVIÇO / 8 OFFICIAL CATEGORIES (Exact matching Image 1: 2 columns x 4 rows) */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-neutral-300 uppercase tracking-wider">
              Escolha o serviço
            </h3>
            <button
              type="button"
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="text-[11px] font-bold text-[#a3e635] hover:underline cursor-pointer"
            >
              {viewMode === 'grid' ? 'Ver lista' : 'Ver grade'}
            </button>
          </div>

          {/* 8 OFFICIAL CATEGORY CARDS (Grid 2 cols x 4 rows) */}
          <div className="grid grid-cols-2 gap-2.5">
            {categories.map((cat) => {
              const isSelected = selectedCategory.id === cat.id;
              const fare = calculateTotal(cat);
              const isLuxury = cat.id === 'w_luxo';
              const isTaxi = cat.id === 'taxi';

              return (
                <div
                  key={cat.id}
                  onClick={() => handleCategoryCardClick(cat)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative ${
                    isSelected
                      ? 'bg-neutral-900 border-[#a3e635] shadow-[0_0_18px_rgba(163,230,53,0.25)]'
                      : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  {/* Crown or Tag Badge */}
                  {cat.tag && (
                    <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-full bg-[#1a2e05] border border-[#a3e635]/40 text-[#a3e635] text-[8px] font-black flex items-center gap-0.5">
                      {cat.tag.includes('PRIME') || cat.tag.includes('VIP') ? <Crown className="w-2.5 h-2.5 text-amber-400" /> : null}
                      <span>{cat.tag}</span>
                    </span>
                  )}

                  {/* Name */}
                  <div className="mb-1">
                    <span className="text-xs font-black text-white block truncate max-w-[70%]">
                      {cat.name}
                    </span>
                  </div>

                  {/* Vehicle Graphic */}
                  <div className="my-1.5 flex justify-center py-1">
                    <VehicleGraphic type={cat.iconType} size="md" />
                  </div>

                  {/* Pricing specs */}
                  <div className="mt-1.5 pt-2 border-t border-neutral-800/80">
                    {isLuxury ? (
                      <div className="space-y-1">
                        <div className="text-[10px] text-amber-300 font-bold leading-tight">
                          Disponível apenas por contrato.
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowLuxuryContractModal(true);
                          }}
                          className="w-full py-1 px-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 font-black text-[9px] uppercase tracking-tight flex items-center justify-center gap-1"
                        >
                          <Crown className="w-2.5 h-2.5" />
                          <span>Solicitar Contrato</span>
                        </button>
                      </div>
                    ) : isTaxi ? (
                      <div className="space-y-0.5">
                        <div className="text-[10px] text-neutral-400 leading-tight">
                          Até 1 km: <strong className="text-white">R$ 10,00</strong>
                        </div>
                        <div className="text-[9px] text-neutral-400 leading-tight">
                          Demais: Taxímetro (Inmetro)
                        </div>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-[9px] text-neutral-400">Total Est.:</span>
                          <strong className="text-xs font-black text-amber-400">
                            R$ {fare.toFixed(2).replace('.', ',')}
                          </strong>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-0.5">
                        <div className="text-[10px] text-neutral-400 leading-tight">
                          Taxa fixa (até 4 km): <strong className="text-white">R$ {cat.baseFare.toFixed(2).replace('.', ',')}</strong>
                        </div>
                        <div className="text-[10px] text-neutral-400 leading-tight">
                          Km adicional: <strong className="text-white">R$ {cat.kmAdicional.toFixed(2).replace('.', ',')}</strong>
                        </div>
                        <div className="flex items-baseline justify-between mt-1">
                          <span className="text-[9px] text-neutral-400">Total:</span>
                          <strong className="text-xs font-black text-[#a3e635]">
                            R$ {fare.toFixed(2).replace('.', ',')}
                          </strong>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 6. INDIQUE AMIGOS E GANHE CRÉDITOS BANNER (Matching Image 1) */}
        <div
          onClick={() => setShowReferralModal(true)}
          className="p-3.5 rounded-2xl bg-gradient-to-r from-[#172b05] via-[#0d1a03] to-[#172b05] border border-[#a3e635]/40 flex items-center justify-between cursor-pointer hover:scale-[1.01] transition-transform shadow-md"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-[#a3e635] text-neutral-950 shadow-[0_0_12px_rgba(163,230,53,0.4)]">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-black text-white">
                Indique amigos e ganhe créditos!
              </div>
              <div className="text-[10px] text-neutral-300 leading-tight">
                A cada 10 viagens do indicado, você ganha R$ 5,00 em créditos.
              </div>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-[#a3e635] shrink-0" />
        </div>

        {/* 7. CONFIRM RIDE BUTTON (Proceed to payment) */}
        <button
          type="button"
          onClick={() => {
            if (!destino || destino.trim() === '') {
              alert('Por favor, informe o endereço de destino.');
              return;
            }
            if (selectedCategory.id === 'w_luxo') {
              setShowLuxuryContractModal(true);
              return;
            }
            onProceedToPayment();
          }}
          className="w-full py-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] active:scale-[0.99] text-neutral-950 font-black text-sm tracking-tight transition-all shadow-[0_4px_20px_rgba(163,230,53,0.35)] flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>
            {selectedCategory.id === 'w_luxo'
              ? 'Solicitar Contrato W-LUXO'
              : `Confirmar ${selectedCategory.name} • R$ ${currentTotal.toFixed(2).replace('.', ',')}`}
          </span>
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </button>
      </div>

      {/* 8. BOTTOM NAVIGATION BAR (Exact matching Image 1: Início, Histórico, Favoritos, Mensagens, Perfil) */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-[#0a0a0a]/95 border-t border-neutral-800/80 backdrop-blur-md grid grid-cols-5 items-center z-40">
        {/* Início */}
        <button
          type="button"
          onClick={() => {
            setActiveBottomNav('inicio');
            if (onGoToHome) onGoToHome();
          }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'inicio' ? 'text-[#a3e635]' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-bold">Início</span>
        </button>

        {/* Histórico */}
        <button
          type="button"
          onClick={() => {
            setActiveBottomNav('historico');
            setShowMenuDrawer(true);
          }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'historico' ? 'text-[#a3e635]' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Histórico</span>
        </button>

        {/* Favoritos */}
        <button
          type="button"
          onClick={() => {
            setActiveBottomNav('favoritos');
            setShowSavedPlacesModal(true);
          }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'favoritos' ? 'text-[#a3e635]' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <Star className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Favoritos</span>
        </button>

        {/* Mensagens */}
        <button
          type="button"
          onClick={() => {
            setActiveBottomNav('mensagens');
            setShowHelpModal(true);
          }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'mensagens' ? 'text-[#a3e635]' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Mensagens</span>
        </button>

        {/* Perfil */}
        <button
          type="button"
          onClick={() => {
            setActiveBottomNav('perfil');
            setShowMenuDrawer(true);
          }}
          className={`flex flex-col items-center justify-center gap-1 ${
            activeBottomNav === 'perfil' ? 'text-[#a3e635]' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Perfil</span>
        </button>
      </div>

      {/* MODALS */}
      <PassengerMenuDrawer
        isOpen={showMenuDrawer}
        onClose={() => setShowMenuDrawer(false)}
        onOpenSavedPlaces={() => setShowSavedPlacesModal(true)}
        onOpenHistory={() => {}}
        onOpenCredits={() => setShowCreditsModal(true)}
        onOpenRefund={() => setShowRefundModal(true)}
        onOpenRatings={() => {}}
        onShareRide={() => {
          navigator.clipboard.writeText(`Acompanhe minha viagem no W-DRIVER João Pessoa em tempo real: https://wdriver.app/live/${Date.now()}`);
          alert('Link seguro de rastreamento copiado!');
        }}
        onOpenLostItems={() => setShowLostItemsModal(true)}
        onOpenReferral={() => setShowReferralModal(true)}
        onOpenPromotions={() => setShowPromotionsModal(true)}
        onOpenContracts={() => setShowLuxuryContractModal(true)}
        onOpenHelp={() => setShowHelpModal(true)}
        onOpenTerms={() => {}}
        onOpenBio={() => {
          if (onGoToBio) onGoToBio();
        }}
        userCredits={userCredits}
      />

      <LuxuryContractModal
        isOpen={showLuxuryContractModal}
        onClose={() => setShowLuxuryContractModal(false)}
        onSubmitContract={(ctr) => {
          if (onSubmitContract) onSubmitContract(ctr);
        }}
      />

      <SavedPlacesModal
        isOpen={showSavedPlacesModal}
        onClose={() => setShowSavedPlacesModal(false)}
        savedPlaces={savedPlaces}
        onSelectPlace={(addr) => setDestino(addr)}
        onSavePlace={(p) => {
          setSavedPlaces((prev) => {
            const exists = prev.some((x) => x.id === p.id);
            if (exists) return prev.map((x) => (x.id === p.id ? p : x));
            return [...prev, p];
          });
        }}
        onDeletePlace={(id) => setSavedPlaces((prev) => prev.filter((p) => p.id !== id))}
      />

      <CreditsModal
        isOpen={showCreditsModal}
        onClose={() => setShowCreditsModal(false)}
        balance={userCredits}
        onAddCredits={(val) => setUserCredits((prev) => prev + val)}
      />

      <RefundModal
        isOpen={showRefundModal}
        onClose={() => setShowRefundModal(false)}
        rides={allRides}
        onSubmitRefund={(ref) => {
          if (onSubmitRefund) onSubmitRefund(ref);
        }}
      />

      <LostItemsModal
        isOpen={showLostItemsModal}
        onClose={() => setShowLostItemsModal(false)}
        onSubmitReport={(rep) => {
          if (onSubmitLostItem) onSubmitLostItem(rep);
        }}
      />

      <ReferralModal
        isOpen={showReferralModal}
        onClose={() => setShowReferralModal(false)}
      />

      <PromotionsModal
        isOpen={showPromotionsModal}
        onClose={() => setShowPromotionsModal(false)}
        onApplyCoupon={(code) => {}}
      />

      <HelpCenterModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
      />

      <TaxiDetailModal
        onClose={() => setShowTaxiModal(false)}
        onConfirm={() => {
          setShowTaxiModal(false);
          onProceedToPayment();
        }}
      />

      <SosModal
        isOpen={showSosModal}
        onClose={() => setShowSosModal(false)}
        userRole="passageiro"
      />
    </div>
  );
};
