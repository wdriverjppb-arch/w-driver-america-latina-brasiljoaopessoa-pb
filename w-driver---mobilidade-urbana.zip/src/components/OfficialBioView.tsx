import React from 'react';
import { 
  BookOpen, ShieldCheck, Heart, Award, Landmark, Building2, 
  CheckCircle2, ArrowLeft, ArrowRight, UserCheck, Scale
} from 'lucide-react';
import { WDriverLogo } from './WDriverLogo';
import { PIX_CONFIG } from '../utils/pix';
import { FullFounderStory } from './FullFounderStory';
import { FounderOfficialPhoto } from './FounderOfficialPhoto';

interface OfficialBioViewProps {
  onBackToHome: () => void;
  onGoToRegistration: () => void;
  onGoToPassengerApp: () => void;
}

export const OfficialBioView: React.FC<OfficialBioViewProps> = ({
  onBackToHome,
  onGoToRegistration,
  onGoToPassengerApp,
}) => {
  return (
    <div className="w-full space-y-5 animate-fadeIn pb-6">
      {/* HEADER DE NAVEGAÇÃO INTERNA */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToHome}
          className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Início</span>
        </button>

        <span className="text-[10px] font-mono text-[#a3e635] bg-[#1a2e05] px-2.5 py-1 rounded-full border border-[#a3e635]/40 font-bold">
          Documento Institucional Oficial
        </span>
      </div>

      {/* HERO DA BIOGRAFIA COM FOTO OFICIAL DO FUNDADOR */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-[#132209] via-neutral-900 to-neutral-950 border border-[#a3e635]/40 shadow-2xl space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800/80 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-[#1a2e05] border border-[#a3e635]/50 flex items-center justify-center text-[#a3e635]">
              <BookOpen className="w-7 h-7" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase text-[#a3e635] tracking-widest block">
                História Oficial & Governança Corporativa
              </span>
              <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white">
                W-DRIVER
              </h1>
              <p className="text-xs sm:text-sm font-black text-[#a3e635] tracking-wider uppercase">
                AMÉRICA LATINA BRASIL JOÃO PESSOA-PB
              </p>
              <p className="text-[11px] text-neutral-400 mt-0.5">
                Fundação, valores morais e a revolução da mobilidade segura na Paraíba
              </p>
            </div>
          </div>
          <WDriverLogo size="md" />
        </div>

        {/* FOTO OFICIAL & ORIGINAL DO FUNDADOR WOLLACE MOTORISTA */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center bg-neutral-950/90 p-4 sm:p-6 rounded-3xl border border-neutral-800/80">
          <div className="lg:col-span-5">
            <FounderOfficialPhoto variant="full" />
          </div>

          <div className="lg:col-span-7 space-y-3.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#182907] border border-[#a3e635]/30 text-[#a3e635] text-[11px] font-bold">
              <Award className="w-3.5 h-3.5" />
              <span>Trajetória de Luta & Superação Paraibana</span>
            </div>

            <h2 className="text-lg sm:text-xl font-black text-white leading-snug">
              Da pilotagem nas ruas de João Pessoa à fundação da plataforma mais segura do Nordeste
            </h2>

            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              A W-DRIVER nasceu nas ruas da capital paraibana pela coragem e determinação do seu fundador, <strong>Diego Wallace (Wollace)</strong>. Conhecedor profundo das agruras, dos riscos de calote e das taxas abusivas praticadas por corporações estrangeiras contra motociclistas e motoristas de aplicativo, Wollace decidiu criar uma solução própria, jurídica e humana.
            </p>

            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
              O ecossistema W-DRIVER estabeleceu um marco histórico: <strong>90% de repasse líquido aos parceiros</strong>, validação documental antifraude com selfie biométrica e certidão de antecedentes, e canal direto com a Central Operacional 24 horas sediada na Torre, em João Pessoa.
            </p>

            <div className="flex flex-wrap gap-2 pt-1">
              <span className="px-2.5 py-1 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#a3e635]" />
                CNPJ 55.348.639/0001-54 Ativo
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#a3e635]" />
                Sede em João Pessoa / PB
              </span>
              <span className="px-2.5 py-1 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-300 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#a3e635]" />
                Operação 100% Legalizada
              </span>
            </div>
          </div>
        </div>

        {/* REGISTRO DE GOVERNANÇA E CNPJ */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-neutral-950/80 p-4 rounded-2xl border border-neutral-800">
          <div>
            <span className="text-[10px] text-neutral-500 block uppercase font-bold">Razão Social / CNPJ:</span>
            <strong className="text-white text-xs block">{PIX_CONFIG.favorecido}</strong>
            <span className="text-[#a3e635] font-mono text-xs font-black">{PIX_CONFIG.cnpjFormatado}</span>
          </div>
          <div>
            <span className="text-[10px] text-neutral-500 block uppercase font-bold">Fundador & Idealizador:</span>
            <strong className="text-white text-xs block">Wollace Diego de Lima Vasconcelos</strong>
            <span className="text-neutral-400 text-[11px]">Empreendedor & Defensor dos Condutores</span>
          </div>
          <div>
            <span className="text-[10px] text-neutral-500 block uppercase font-bold">Sede Matriz:</span>
            <strong className="text-white text-xs block">João Pessoa - Paraíba</strong>
            <span className="text-neutral-400 text-[11px]">Bairro da Torre / Operação Estadual</span>
          </div>
        </div>
      </div>

      {/* CANTINHO RESERVADO ÚNICO: BIOGRAFIA OFICIAL COMPLETA & EXPERIÊNCIA NA PRÁTICA */}
      <FullFounderStory />

      {/* OS 4 PILARES INSTITUCIONAIS */}
      <div className="space-y-3">
        <h2 className="text-sm font-black text-white uppercase tracking-wider">
          Os Pilares Fundamentais do W-DRIVER
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {/* PILAR 1: REPASSE DIGNO DE 90% */}
          <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400">
              <Heart className="w-5 h-5" />
              <h3 className="text-xs font-black uppercase text-white">
                1. Repasse Líquido Garantido de 90%
              </h3>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Enquanto multinacionais estrangeiras confiscam até 40% dos ganhos suados de quem pilota o dia inteiro sob sol e chuva, a W-DRIVER nasceu com um pacto inegociável: <strong>90% de todo valor pago vai diretamente para o bolso do motorista parceiro</strong> via W-BANK.
            </p>
          </div>

          {/* PILAR 2: BLINDAGEM ANTIFRAUDE E ANTI-CALOTE */}
          <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-2">
            <div className="flex items-center gap-2 text-[#a3e635]">
              <ShieldCheck className="w-5 h-5" />
              <h3 className="text-xs font-black uppercase text-white">
                2. Blindagem Antifraude & Anti-Calote
              </h3>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Acabou o calote no desembarque e o golpe do Pix falso. No ecossistema W-DRIVER, a viagem só é autorizada após a conferência e custódia da Central 24h na conta jurídica oficial da empresa. O motorista roda com a certeza matemática do pagamento.
            </p>
          </div>

          {/* PILAR 3: BIOMETRIA E CERTIDÕES POLICIAIS */}
          <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-2">
            <div className="flex items-center gap-2 text-sky-400">
              <UserCheck className="w-5 h-5" />
              <h3 className="text-xs font-black uppercase text-white">
                3. Biometria Facial & Antecedentes
              </h3>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Passageiros e motoristas passam por auditoria documental prévia: selfie biométrica, CNH/RG autêntico, certidão negativa de antecedentes criminais e autenticação pelo gov.br. Aqui não há perfis anônimos nem contas fakes.
            </p>
          </div>

          {/* PILAR 4: SUPORTE HUMANO E CENTRAL 24H */}
          <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-2">
            <div className="flex items-center gap-2 text-amber-400">
              <Building2 className="w-5 h-5" />
              <h3 className="text-xs font-black uppercase text-white">
                4. Central Humana de Despacho 24h
              </h3>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Você nunca falará com um robô burro ou formulário esquecido. Nossa Central em João Pessoa monitora cada chamada, ajusta a dinâmica regional e despacha as corridas com suporte por voz e telemetria em tempo real.
            </p>
          </div>
        </div>
      </div>

      {/* MANIFESTO DO FUNDADOR WOLLACE */}
      <div className="p-5 sm:p-6 rounded-3xl bg-neutral-900 border border-[#a3e635]/30 space-y-3">
        <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-2">
          <Scale className="w-4 h-4 text-[#a3e635]" />
          Mensagem da Presidência Fundadora
        </h3>
        <blockquote className="border-l-2 border-[#a3e635] pl-4 text-xs sm:text-sm text-neutral-300 italic leading-relaxed">
          "A W-DRIVER não é apenas um aplicativo. É um escudo para os trabalhadores paraibanos e um porto seguro para as famílias que precisam voltar para casa com tranquilidade. Construímos este sistema com recursos próprios, suor e a certeza de que a dignidade humana não se negocia. Quem escolhe preço corre riscos. Quem escolhe a W-DRIVER escolhe chegar bem!"
        </blockquote>
        <div className="text-right pt-2">
          <span className="text-xs font-black text-white block">Wollace Diego de Lima Vasconcelos</span>
          <span className="text-[10px] text-neutral-400">Presidente Executivo • W-DRIVER América Latina Brasil</span>
        </div>
      </div>

      {/* CTAS DE AÇÃO */}
      <div className="flex flex-col sm:flex-row gap-3 pt-2">
        <button
          onClick={onGoToPassengerApp}
          className="flex-1 py-3.5 px-4 rounded-2xl bg-[#a3e635] hover:bg-[#bef264] text-neutral-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer"
        >
          <span>Experimentar a Mobilidade W-DRIVER</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={onGoToRegistration}
          className="flex-1 py-3.5 px-4 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <span>Fazer Cadastro Antifraude</span>
        </button>
      </div>
    </div>
  );
};
