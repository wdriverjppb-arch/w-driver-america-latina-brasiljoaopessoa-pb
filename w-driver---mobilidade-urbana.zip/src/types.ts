export type ServiceCategory = 
  | 'w_bike'
  | 'w_moto_comum'
  | 'w_moto_prime'
  | 'w_carro_comum'
  | 'w_carro_prime'
  | 'w_carro_exec'
  | 'w_carro_exec_comum'
  | 'w_carro_exec_prime'
  | 'w_luxo'
  | 'taxi';

export interface CategoryInfo {
  id: ServiceCategory;
  name: string;
  subtitle: string;
  baseFare: number; // Tarifa fixa até 4km
  kmAdicional: number; // Por km excedente
  iconType: 'bike' | 'moto' | 'moto_prime' | 'car_white' | 'car_blue' | 'car_black' | 'car_exec' | 'luxury' | 'taxi';
  tag?: string;
  isContractOnly?: boolean;
  isTaxiMeter?: boolean;
  capacity: string;
  etaMins: number;
}

export type RideStatus = 
  | 'solicitada'
  | 'aguardando_pix'
  | 'paga_central'
  | 'despachada'
  | 'motorista_a_caminho'
  | 'motorista_no_local'
  | 'em_viagem'
  | 'concluida'
  | 'cancelada';

export interface RideData {
  id: string;
  origem: string;
  origemBairro: string;
  destino: string;
  destinoBairro: string;
  distanciaKm: number;
  tempoEstimadoMin: number;
  categoria: CategoryInfo;
  valorBase: number;
  dinamicaAtiva: boolean;
  multiplicadorDinamica: number;
  valorTotal: number;
  repasseMotorista: number; // 90%
  taxaPlataforma: number; // 10%
  status: RideStatus;
  criadoEm: string;
  chavePix: string;
  codigoPix: string;
  passageiroNome: string;
  motoristaNome?: string;
  motoristaVeiculo?: string;
  motoristaPlaca?: string;
  pin?: string;
}

export type ActiveTab = 
  | 'inicio'
  | 'biografia'
  | 'cadastro'
  | 'passageiro'
  | 'pagamento'
  | 'wbank'
  | 'central'
  | 'motorista';

export type RegistrationStatus = 'nao_iniciado' | 'em_analise' | 'aprovado' | 'bloqueado';

export type RegistrationCategory = 'w_bike' | 'w_moto' | 'w_carro' | 'w_taxi' | 'w_luxo';

export interface UserRegistration {
  nome: string;
  cpf: string;
  telefone: string;
  email?: string;
  naturalidade: string;
  bairro?: string;
  categoriaPretendida: RegistrationCategory;
  selfieEnviada: boolean;
  selfieUrl?: string;
  documentoEnviado: boolean;
  documentoUrl?: string;
  antecedentesEnviados: boolean;
  antecedentesUrl?: string;
  comprovanteResidenciaEnviado: boolean;
  comprovanteResidenciaUrl?: string;
  govBrAssinado: boolean;
  termosAceitos: boolean;
  status: RegistrationStatus;
  dataSubmissao?: string;
}

export type AdCategory = 'posto' | 'farmacia' | 'espetinho' | 'mercado' | 'outro';

export interface AdBanner {
  id: string;
  titulo: string;
  empresa: string;
  categoria: AdCategory;
  categoriaLabel: string;
  imagemUrl: string;
  linkWhatsApp?: string;
  cupom?: string;
  descricao: string;
  ativo: boolean;
  cliques: number;
  visualizacoes: number;
  criadoEm: string;
}

export interface CentralAlert {
  id: string;
  tipo: 'urgente' | 'transito' | 'seguranca' | 'geral';
  titulo: string;
  mensagem: string;
  destinatario: 'todos' | 'passageiros' | 'motoristas';
  criadoEm: string;
  ativo: boolean;
}

export interface ManagedUser {
  id: string;
  nome: string;
  tipo: 'passageiro' | 'motorista';
  cpf: string;
  imei: string;
  telefone?: string;
  status: 'aprovado' | 'em_analise' | 'suspenso' | 'banido';
  veiculo?: string;
  cidade: string;
  dataCadastro: string;
  motivoBloqueio?: string;
  fotoUrl?: string;
  documentoUrl?: string;
}

export interface BankTransaction {
  id: string;
  tipo: 'repasse_corrida' | 'saque_pix' | 'recarga_saldo' | 'taxa_plataforma';
  descricao: string;
  valor: number;
  dataHora: string;
  status: 'concluido' | 'processando' | 'estornado';
  chavePixDestino?: string;
  comprovanteId?: string;
  corridaId?: string;
}

export interface SavedPlace {
  id: string;
  type: 'casa' | 'trabalho' | 'favorito';
  title: string;
  address: string;
}

export interface LostItemReport {
  id: string;
  corridaId: string;
  item: string;
  descricao: string;
  telefoneContato: string;
  data: string;
  status: 'aberto' | 'localizado' | 'entregue';
}

export interface RefundRequest {
  id: string;
  corridaId: string;
  motivo: string;
  valor: number;
  data: string;
  status: 'em_analise' | 'aprovado' | 'recusado';
}

export interface LuxuryContract {
  id: string;
  clienteNome: string;
  telefone: string;
  veiculo: string;
  tipoViagem: string; // 'passeio_turistico' | 'litoral_norte' | 'litoral_sul' | 'estadual' | 'interestadual' | 'executivo'
  dataInicio: string;
  diarias: number;
  valorEstimado: number;
  status: 'solicitado' | 'em_analise' | 'confirmado';
  observacoes?: string;
}

