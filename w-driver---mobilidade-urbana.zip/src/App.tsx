import React, { useState, useEffect } from 'react';
import { 
  Smartphone, CreditCard, Building2, Radio, Wallet, 
  ShieldCheck, HelpCircle, Check, Sparkles, Navigation2, Lock, Bell, BookOpen, ExternalLink
} from 'lucide-react';
import { 
  ActiveTab, CategoryInfo, RideData, RideStatus, UserRegistration, 
  AdBanner, CentralAlert, ManagedUser, LuxuryContract, RefundRequest, LostItemReport 
} from './types';
import { CATEGORIES } from './data/categories';
import { PIX_CONFIG, generatePixCopiaECola } from './utils/pix';
import { INITIAL_ADS, INITIAL_ALERTS, INITIAL_MANAGED_USERS } from './data/adsAndUsers';
import { WDriverLogo } from './components/WDriverLogo';
import { PassengerApp } from './components/PassengerApp';
import { PixPaymentModal } from './components/PixPaymentModal';
import { CentralControl } from './components/CentralControl';
import { DriverApp } from './components/DriverApp';
import { WBankDrawer } from './components/WBankDrawer';
import { SecurityRegistration } from './components/SecurityRegistration';
import { OfficialBioModal } from './components/OfficialBioModal';
import { WelcomeHome } from './components/WelcomeHome';
import { OfficialBioView } from './components/OfficialBioView';
import { WBankView } from './components/WBankView';
import { CentralAuthGate } from './components/CentralAuthGate';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('inicio');
  const [showWBankModal, setShowWBankModal] = useState<boolean>(false);
  const [showBioModal, setShowBioModal] = useState<boolean>(false);
  const [surgeMultiplier, setSurgeMultiplier] = useState<number>(1.0);
  const [isCentralAuthenticated, setIsCentralAuthenticated] = useState<boolean>(false);

  // Dynamic Categories and Rates (managed by Central)
  const [categories, setCategories] = useState<CategoryInfo[]>(CATEGORIES);

  // Central Management State: Publicidade, Alertas e Cadastros
  const [ads, setAds] = useState<AdBanner[]>(INITIAL_ADS);
  const [alerts, setAlerts] = useState<CentralAlert[]>(INITIAL_ALERTS);
  const [managedUsers, setManagedUsers] = useState<ManagedUser[]>(INITIAL_MANAGED_USERS);

  // Category handlers
  const handleUpdateCategories = (updatedCats: CategoryInfo[]) => {
    setCategories(updatedCats);
  };

  // Ad handlers
  const handleAddAd = (ad: Omit<AdBanner, 'id' | 'cliques' | 'visualizacoes' | 'criadoEm'>) => {
    const newAd: AdBanner = {
      ...ad,
      id: `ad-${Date.now()}`,
      cliques: 0,
      visualizacoes: 1,
      criadoEm: new Date().toLocaleDateString('pt-BR'),
    };
    setAds((prev) => [newAd, ...prev]);
  };

  const handleUpdateAd = (ad: AdBanner) => {
    setAds((prev) => prev.map((a) => (a.id === ad.id ? ad : a)));
  };

  const handleToggleAd = (id: string) => {
    setAds((prev) => prev.map((a) => (a.id === id ? { ...a, ativo: !a.ativo } : a)));
  };

  const handleDeleteAd = (id: string) => {
    setAds((prev) => prev.filter((a) => a.id !== id));
  };

  // Alert handlers
  const handleAddAlert = (alert: Omit<CentralAlert, 'id' | 'criadoEm'>) => {
    const newAlert: CentralAlert = {
      ...alert,
      id: `alert-${Date.now()}`,
      criadoEm: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    };
    setAlerts((prev) => [newAlert, ...prev]);
  };

  const handleUpdateAlert = (alert: CentralAlert) => {
    setAlerts((prev) => prev.map((a) => (a.id === alert.id ? alert : a)));
  };

  const handleToggleAlert = (id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, ativo: !a.ativo } : a)));
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  // Managed user handlers
  const handleAddUser = (user: ManagedUser) => {
    setManagedUsers((prev) => [user, ...prev]);
  };

  const handleEditUser = (user: ManagedUser) => {
    setManagedUsers((prev) => prev.map((u) => (u.id === user.id ? user : u)));
  };

  const handleDeleteUser = (id: string) => {
    setManagedUsers((prev) => prev.filter((u) => u.id !== id));
  };

  const handleUpdateUserStatus = (id: string, status: ManagedUser['status']) => {
    setManagedUsers((prev) => prev.map((u) => (u.id === id ? { ...u, status } : u)));
  };

  const handleAddBan = (user: Omit<ManagedUser, 'id' | 'dataCadastro' | 'status'> & { motivo: string }) => {
    const newUser: ManagedUser = {
      id: `usr-${Date.now()}`,
      nome: user.nome,
      cpf: user.cpf,
      tipo: user.tipo,
      status: 'banido',
      motivoBloqueio: user.motivo,
      imei: user.imei,
      cidade: user.cidade || 'João Pessoa / PB',
      dataCadastro: new Date().toLocaleDateString('pt-BR'),
    };
    setManagedUsers((prev) => [newUser, ...prev]);
  };

  // User Security Registration State (Diego Wallace de Lima Vasconcelos - Fundador W-DRIVER)
  const [registration, setRegistration] = useState<UserRegistration>({
    nome: 'Diego Wallace de Lima Vasconcelos',
    cpf: '55.348.639/0001-54',
    telefone: '(83) 98117-9524',
    naturalidade: 'João Pessoa / PB',
    selfieEnviada: true,
    documentoEnviado: true,
    antecedentesEnviados: true,
    govBrAssinado: true,
    termosAceitos: true,
    status: 'aprovado',
  });

  const handleUpdateRegistration = (data: Partial<UserRegistration>) => {
    setRegistration((prev) => ({ ...prev, ...data }));
  };

  // Core Passenger inputs
  const [origem, setOrigem] = useState('Busto de Tamandaré, Cabo Branco');
  const [destino, setDestino] = useState('Manaíra Shopping, Zona Leste');
  const [distanciaKm, setDistanciaKm] = useState(8.3);
  const [selectedCategory, setSelectedCategory] = useState<CategoryInfo>(CATEGORIES[1]); // W-MOTO Comum
  const [surgeActive, setSurgeActive] = useState<boolean>(false);

  // Default initial rides
  const DEFAULT_INITIAL_RIDES: RideData[] = [
    {
      id: 'wd-8391',
      origem: 'Av. Cabo Branco, 1500',
      origemBairro: 'Cabo Branco',
      destino: 'Praça da Paz, Bancários',
      destinoBairro: 'Bancários',
      distanciaKm: 6.8,
      tempoEstimadoMin: 14,
      categoria: CATEGORIES[3], // W-CARRO Comum
      valorBase: 8.0,
      dinamicaAtiva: false,
      multiplicadorDinamica: 1.0,
      valorTotal: 12.9,
      repasseMotorista: 11.61,
      taxaPlataforma: 1.29,
      status: 'concluida',
      criadoEm: '10:40',
      chavePix: PIX_CONFIG.cnpjFormatado,
      codigoPix: generatePixCopiaECola(12.9, '8391'),
      passageiroNome: 'Mariana Costa',
      motoristaNome: 'Carlos E. da Silva',
      motoristaVeiculo: 'Honda CB 500F',
      motoristaPlaca: 'QFA-9921',
      pin: '4821',
    },
  ];

  // Active Ride state with localStorage persistence
  const [currentRide, setCurrentRide] = useState<RideData | null>(() => {
    try {
      const saved = localStorage.getItem('wdriver_current_ride');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Historical rides for Central and W-BANK with localStorage persistence
  const [allRides, setAllRides] = useState<RideData[]>(() => {
    try {
      const saved = localStorage.getItem('wdriver_all_rides');
      return saved ? JSON.parse(saved) : DEFAULT_INITIAL_RIDES;
    } catch {
      return DEFAULT_INITIAL_RIDES;
    }
  });

  // Sincronização multi-aba e persistência instantânea
  useEffect(() => {
    try {
      localStorage.setItem('wdriver_all_rides', JSON.stringify(allRides));
    } catch {}
  }, [allRides]);

  useEffect(() => {
    try {
      if (currentRide) {
        localStorage.setItem('wdriver_current_ride', JSON.stringify(currentRide));
      } else {
        localStorage.removeItem('wdriver_current_ride');
      }
    } catch {}
  }, [currentRide]);

  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'wdriver_all_rides' && e.newValue) {
        try {
          setAllRides(JSON.parse(e.newValue));
        } catch {}
      }
      if (e.key === 'wdriver_current_ride') {
        try {
          setCurrentRide(e.newValue ? JSON.parse(e.newValue) : null);
        } catch {}
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  // Contratos W-LUXO, Reembolsos e Achados e Perdidos
  const [contracts, setContracts] = useState<LuxuryContract[]>([
    {
      id: 'ctr-101',
      clienteNome: 'Mariana Costa',
      telefone: '(83) 98888-1234',
      veiculo: 'Mercedes-Benz Classe E Blindada',
      tipoViagem: 'Diária Executiva / Evento',
      dataInicio: '15/10/2026',
      diarias: 2,
      valorEstimado: 3800.0,
      status: 'aprovado',
      observacoes: 'Motorista bilíngue trajado social',
    },
  ]);

  const [refundRequests, setRefundRequests] = useState<RefundRequest[]>([]);
  const [lostItemReports, setLostItemReports] = useState<LostItemReport[]>([]);

  // Calculate fare helper
  const calculateTotalFare = (cat: CategoryInfo, km: number, surge: boolean) => {
    let fare = cat.baseFare;
    if (km > 4) {
      fare += (km - 4) * cat.kmAdicional;
    }
    if (surge) {
      fare *= 3.5;
    }
    return Math.round(fare * 100) / 100;
  };

  // Create new ride and move to payment
  const handleProceedToPayment = () => {
    const total = calculateTotalFare(selectedCategory, distanciaKm, surgeActive);
    const repasse = Math.round(total * 0.9 * 100) / 100;
    const taxa = Math.round((total - repasse) * 100) / 100;
    const newRideId = `wd-${Math.floor(1000 + Math.random() * 9000)}`;
    const pin = Math.floor(1000 + Math.random() * 9000).toString();

    const newRide: RideData = {
      id: newRideId,
      origem,
      origemBairro: origem.split(',')[1]?.trim() || 'João Pessoa',
      destino,
      destinoBairro: destino.split(',')[1]?.trim() || 'João Pessoa',
      distanciaKm,
      tempoEstimadoMin: Math.max(5, Math.round(distanciaKm * 2.2)),
      categoria: selectedCategory,
      valorBase: selectedCategory.baseFare,
      dinamicaAtiva: surgeActive,
      multiplicadorDinamica: surgeActive ? 3.5 : 1.0,
      valorTotal: total,
      repasseMotorista: repasse,
      taxaPlataforma: taxa,
      status: 'aguardando_pix',
      criadoEm: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      chavePix: PIX_CONFIG.cnpjFormatado,
      codigoPix: generatePixCopiaECola(total, newRideId.slice(-6)),
      passageiroNome: 'Você (Passageiro)',
      motoristaNome: 'Carlos E. da Silva',
      motoristaVeiculo: 'Honda CB 500F',
      motoristaPlaca: 'QFA-9921',
      pin,
    };

    setCurrentRide(newRide);
    setAllRides((prev) => [newRide, ...prev]);
    setActiveTab('pagamento');
  };

  // Simulate PIX confirmation from bank to Central
  const handlePaymentSuccess = () => {
    if (!currentRide) return;
    const updated: RideData = {
      ...currentRide,
      status: 'paga_central',
    };
    setCurrentRide(updated);
    setAllRides((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    setActiveTab('central');
  };

  // Ativa Trilha Dinâmica 3.5 e transfere imediatamente para a Central Operacional
  const handleActivateSurgeAndGoToCentral = () => {
    setSurgeMultiplier(3.5);
    setSurgeActive(true);
    setActiveTab('central');
  };

  // Central authorizes and dispatches to Driver
  const handleApproveAndDispatch = (rideId: string) => {
    setAllRides((prev) =>
      prev.map((r) => {
        if (r.id === rideId) {
          const dispatched: RideData = { ...r, status: 'despachada' };
          if (currentRide?.id === rideId) {
            setCurrentRide(dispatched);
          }
          return dispatched;
        }
        return r;
      })
    );
    setActiveTab('motorista');
  };

  // Driver accepts ride
  const handleAcceptRide = (rideId: string) => {
    const updatedStatus: RideStatus = 'motorista_a_caminho';
    setAllRides((prev) =>
      prev.map((r) => (r.id === rideId ? { ...r, status: updatedStatus } : r))
    );
    if (currentRide?.id === rideId) {
      setCurrentRide((prev) => (prev ? { ...prev, status: updatedStatus } : null));
    }
  };

  // Update status along driver workflow
  const handleUpdateRideStatus = (rideId: string, status: RideStatus) => {
    setAllRides((prev) =>
      prev.map((r) => (r.id === rideId ? { ...r, status } : r))
    );
    if (currentRide?.id === rideId) {
      setCurrentRide((prev) => (prev ? { ...prev, status } : null));
    }
  };

  const completedRides = allRides.filter((r) => r.status === 'concluida');

  return (
    <div className="fixed inset-0 w-screen h-screen flex flex-col overflow-hidden bg-[#070908] text-neutral-100 selection:bg-[#a3e635] selection:text-black">
      {/* MAIN TOPBAR */}
      <header className="sticky top-0 z-40 bg-[#0a0e0a]/95 backdrop-blur-md border-b border-neutral-800/80 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <WDriverLogo size="md" />
          <div className="hidden sm:block border-l border-neutral-800 pl-3">
            <span className="text-[10px] uppercase font-extrabold tracking-wider text-[#b2ec5d] block">
              AMÉRICA LATINA BRASIL JOÃO PESSOA-PB
            </span>
            <span className="text-xs text-neutral-400 font-semibold block">
              Sistema Blindado Anti-Fraude e Anti-Calote
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900 border border-neutral-800 text-xs">
            <span className="w-2 h-2 rounded-full bg-[#a3e635] animate-ping" />
            <span className="text-neutral-300 font-medium">João Pessoa - PB</span>
            <span className="text-neutral-500">•</span>
            <span className="text-[#a3e635] font-bold">Central 24h Ativa</span>
          </div>

          <button
            onClick={() => alert('Central W-DRIVER: Nenhuma notificação crítica no momento. Operação segura e blindada ativa.')}
            className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 transition-colors cursor-pointer relative"
            title="Notificações da Central"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#b2ec5d]" />
          </button>

          <button
            onClick={() => setShowBioModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-neutral-200 hover:text-white font-bold text-xs transition-colors shadow-sm cursor-pointer"
            title="Ler Biografia Oficial do Fundador Wollace"
          >
            <BookOpen className="w-4 h-4 text-[#a3e635]" />
            <span className="hidden sm:inline">Biografia Oficial</span>
          </button>

          <button
            onClick={() => setShowWBankModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#142607] hover:bg-[#1a330a] border border-[#a3e635]/40 text-[#a3e635] font-bold text-xs transition-colors shadow-sm cursor-pointer"
          >
            <Wallet className="w-4 h-4" />
            <span>W-BANK</span>
          </button>
        </div>
      </header>

      {/* NAVIGATION TABS (Arquitetura Fluida W-DRIVER) */}
      <div className="bg-[#111611] border-b border-neutral-800 px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar sticky top-[61px] z-30">
        <button
          onClick={() => setActiveTab('inicio')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'inicio'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <span>🏠 Início (Boas-Vindas)</span>
        </button>

        <button
          onClick={() => setActiveTab('biografia')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'biografia'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>📖 Biografia Oficial</span>
        </button>

        <button
          onClick={() => setActiveTab('cadastro')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'cadastro'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>🛡️ Cadastro & Blindagem</span>
          {registration.status === 'em_analise' && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('passageiro')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'passageiro'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>📱 4. Solicitar Viagem</span>
          {surgeActive && (
            <span className="px-1.5 py-0.2 rounded bg-amber-400 text-neutral-950 text-[9px] font-black">
              3.5x
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('motorista')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'motorista'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          <span>🏍️ 5. Receber Viagens (Motorista)</span>
        </button>

        <button
          onClick={() => setActiveTab('wbank')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'wbank'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-emerald-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>🏦 6. W-BANK (Extratos & Repasse 90%)</span>
        </button>

        <button
          onClick={() => setActiveTab('central')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'central'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>🔒 7. Central Protegida (Login Restrito)</span>
          {allRides.some((r) => r.status === 'paga_central') && (
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => {
            if (!currentRide) {
              handleProceedToPayment();
            } else {
              setActiveTab('pagamento');
            }
          }}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'pagamento'
              ? 'bg-[#a3e635] text-neutral-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
              : 'bg-neutral-900 text-neutral-400 hover:text-white hover:bg-neutral-800'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>💳 PIX</span>
          {currentRide?.status === 'aguardando_pix' && (
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>
      </div>

      {/* Slogan Banner */}
      <div className="bg-gradient-to-r from-neutral-950 via-[#122306] to-neutral-950 border-b border-[#a3e635]/20 py-2 px-4 text-center">
        <p className="text-xs sm:text-sm font-semibold text-[#a3e635] tracking-wide">
          "Quem escolhe preço corre riscos. Quem escolhe a W-DRIVER escolhe chegar bem!"
        </p>
      </div>

      {/* MAIN CONTENT WORKSPACE - TELA CHEIA NATIVA SEM MOLDURAS */}
      <main className="flex-1 w-full overflow-y-auto p-3 sm:p-5">
        {/* VIEW 1: PÁGINA INICIAL DE BOAS-VINDAS */}
        {activeTab === 'inicio' && (
          <div className="max-w-6xl w-full mx-auto">
            <WelcomeHome
              onStartRide={() => setActiveTab('passageiro')}
              onStartRegister={() => setActiveTab('cadastro')}
              onOpenWBank={() => setActiveTab('wbank')}
              onOpenBio={() => setActiveTab('biografia')}
              ads={ads}
            />
          </div>
        )}

        {/* VIEW 2: BIOGRAFIA OFICIAL */}
        {activeTab === 'biografia' && (
          <div className="max-w-5xl w-full mx-auto">
            <OfficialBioView onBack={() => setActiveTab('inicio')} />
          </div>
        )}

        {/* VIEW 3: W-BANK PAINEL FINANCEIRO */}
        {activeTab === 'wbank' && (
          <div className="max-w-6xl w-full mx-auto">
            <WBankView
              completedRides={completedRides}
              onBack={() => setActiveTab('inicio')}
            />
          </div>
        )}

        {/* VIEW 4: CENTRAL DE CONTROLE 24H (PROTEGIDA POR AUTENTICAÇÃO COM LOGIN E RECUPERAÇÃO DE SENHA) */}
        {activeTab === 'central' && (
          <div className="max-w-6xl w-full mx-auto">
            <CentralAuthGate
              isAuthenticated={isCentralAuthenticated}
              onLoginSuccess={() => setIsCentralAuthenticated(true)}
              onLogout={() => setIsCentralAuthenticated(false)}
            >
              <CentralControl
                rides={allRides}
                onApproveAndDispatch={handleApproveAndDispatch}
                onGoToDriverRadar={() => setActiveTab('motorista')}
                surgeMultiplier={surgeMultiplier}
                onChangeSurgeMultiplier={(val) => {
                  setSurgeMultiplier(val);
                  setSurgeActive(val > 1.0);
                }}
                registration={registration}
                onUpdateRegistration={handleUpdateRegistration}
                categories={categories}
                onUpdateCategories={handleUpdateCategories}
                ads={ads}
                onAddAd={handleAddAd}
                onEditAd={handleUpdateAd}
                onToggleAd={handleToggleAd}
                onDeleteAd={handleDeleteAd}
                alerts={alerts}
                onAddAlert={handleAddAlert}
                onEditAlert={handleUpdateAlert}
                onToggleAlert={handleToggleAlert}
                onDeleteAlert={handleDeleteAlert}
                managedUsers={managedUsers}
                onAddUser={handleAddUser}
                onEditUser={handleEditUser}
                onDeleteUser={handleDeleteUser}
                onUpdateUserStatus={handleUpdateUserStatus}
                onAddBan={handleAddBan}
              />
            </CentralAuthGate>
          </div>
        )}

        {/* VIEW 5, 6, 7, 8: PASSAGEIRO, CADASTRO, PAGAMENTO PIX, MOTORISTA (COM PAINEL LATERAL TÉCNICO) */}
        {(activeTab === 'passageiro' || activeTab === 'cadastro' || activeTab === 'pagamento' || activeTab === 'motorista') && (
          <div className="max-w-7xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* LEFT COLUMN: ACTIVE INTERACTIVE WORKFLOW */}
            <div className="lg:col-span-8 w-full flex flex-col items-center">
              <div className="w-full max-w-2xl bg-neutral-950/90 border border-neutral-800/90 rounded-3xl p-3 sm:p-5 shadow-2xl backdrop-blur-sm">
                {activeTab === 'passageiro' && (
                  <PassengerApp
                    origem={origem}
                    setOrigem={setOrigem}
                    destino={destino}
                    setDestino={setDestino}
                    distanciaKm={distanciaKm}
                    setDistanciaKm={setDistanciaKm}
                    selectedCategory={selectedCategory}
                    setSelectedCategory={setSelectedCategory}
                    categories={categories}
                    surgeActive={surgeActive}
                    setSurgeActive={setSurgeActive}
                    onProceedToPayment={handleProceedToPayment}
                    onActivateSurgeAndGoToCentral={handleActivateSurgeAndGoToCentral}
                    alerts={alerts}
                    ads={ads}
                    onGoToHome={() => setActiveTab('inicio')}
                    onGoToWBank={() => setActiveTab('wbank')}
                    onGoToBio={() => setActiveTab('biografia')}
                    allRides={allRides}
                    currentRide={currentRide}
                    onGoToPayment={() => setActiveTab('pagamento')}
                    onSubmitContract={(ctr) => {
                      setContracts((prev) => [ctr, ...prev]);
                      alert(`✅ Solicitação de contrato para ${ctr.veiculo} enviada para a Central W-DRIVER!`);
                    }}
                    onSubmitRefund={(ref) => {
                      setRefundRequests((prev) => [ref, ...prev]);
                      alert('✅ Solicitação de estorno enviada para auditoria da Central W-DRIVER.');
                    }}
                    onSubmitLostItem={(rep) => {
                      setLostItemReports((prev) => [rep, ...prev]);
                      alert(`✅ Alerta de objeto perdido registrado: "${rep.item}". A Central contactará o motorista.`);
                    }}
                  />
                )}

                {activeTab === 'cadastro' && (
                  <div className="w-full">
                    <SecurityRegistration
                      registration={registration}
                      onUpdateRegistration={handleUpdateRegistration}
                      onGoToPassengerApp={() => setActiveTab('passageiro')}
                    />
                  </div>
                )}

                {activeTab === 'pagamento' && (
                  <div className="w-full">
                    {currentRide ? (
                      <PixPaymentModal
                        ride={currentRide}
                        onPaymentSuccess={handlePaymentSuccess}
                        onBack={() => setActiveTab('passageiro')}
                      />
                    ) : (
                      <div className="text-center p-8 bg-neutral-900 rounded-3xl border border-neutral-800">
                        <p className="text-xs text-neutral-400 mb-3">
                          Nenhuma corrida selecionada para pagamento no momento.
                        </p>
                        <button
                          onClick={() => setActiveTab('passageiro')}
                          className="px-4 py-2 rounded-xl bg-[#a3e635] text-neutral-950 font-bold text-xs cursor-pointer"
                        >
                          Voltar ao App Passageiro
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'motorista' && (
                  <div className="w-full">
                    <DriverApp
                      activeRide={
                        allRides.find(
                          (r) =>
                            r.status === 'despachada' ||
                            r.status === 'motorista_a_caminho' ||
                            r.status === 'motorista_no_local' ||
                            r.status === 'em_viagem'
                        ) || null
                      }
                      surgeActive={surgeActive}
                      onToggleSurge={() => setSurgeActive(!surgeActive)}
                      onAcceptRide={handleAcceptRide}
                      onUpdateRideStatus={handleUpdateRideStatus}
                      onOpenWBank={() => setActiveTab('wbank')}
                    />
                  </div>
                )}
              </div>
            </div>

        {/* RIGHT COLUMN: TECHNICAL DIRECTIVES, ACTIVE SIMULATION SPECS & W-BANK OVERVIEW */}
        <div className="lg:col-span-4 w-full space-y-4">
          {/* Active Simulation Summary Card */}
          <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-neutral-800 pb-3">
              <ShieldCheck className="w-5 h-5 text-[#a3e635]" />
              <div>
                <h2 className="text-sm font-black text-white">
                  Sistema Blindado W-DRIVER
                </h2>
                <span className="text-[10px] text-[#a3e635] font-semibold block">
                  Segurança Máxima Anti-Fraude e Anti-Calote
                </span>
              </div>
            </div>

            <ul className="space-y-3 text-xs text-neutral-300">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Biometria Facial & Prova de Vida:</strong>
                  Reconhecimento facial obrigatório de passageiros e motoristas para erradicar contas falsas e perfis fantasmas.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Antecedentes & Assinatura gov.br:</strong>
                  Checagem rigorosa de antecedentes criminais e autenticação jurídica com validade federal via gov.br.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Botão de Emergência W-SOS 24h:</strong>
                  Acionamento instantâneo com envio de telemetria, áudio ambiente e alerta prioritário para a Central e segurança pública.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Gravação 360° em No-Show:</strong>
                  Após 03:00 min de espera no local de embarque, o motorista grava evidência em 360° com crédito automático da taxa de deslocamento no W-BANK.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">W-BANK (90% Repasse Líquido):</strong>
                  O motorista recebe 90% diretamente em sua conta digital W-BANK com transferência PIX imediata e proteção anti-calote.
                </div>
              </li>

              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-lg bg-[#1a2e05] border border-[#a3e635]/40 flex items-center justify-center text-[#a3e635] font-bold text-xs shrink-0 mt-0.5">
                  ✓
                </span>
                <div>
                  <strong className="text-white block font-bold">Radar Dinâmico & Modo Táxi Inmetro:</strong>
                  Acréscimos proporcionais para valorizar o motorista e suporte ao Modo Táxi com medição por taxímetro regulamentado.
                </div>
              </li>
            </ul>
          </div>

          {/* Quick Tariff Breakdown Card */}
          <div className="p-5 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span className="text-xs font-bold text-white">Tabela de Tarifas Atuais</span>
              <span className="text-[10px] text-[#a3e635] font-semibold">Até 4km | Adicional</span>
            </div>

            <div className="space-y-1.5 text-xs">
              {CATEGORIES.slice(0, 6).map((cat) => (
                <div key={cat.id} className="flex justify-between items-center py-1 border-b border-neutral-800/40">
                  <span className="text-neutral-300 font-medium">{cat.name}</span>
                  <div className="text-right">
                    <span className="text-[#a3e635] font-bold">R$ {cat.baseFare.toFixed(2).replace('.', ',')}</span>
                    <span className="text-neutral-500 text-[10px] ml-1">
                      (+R$ {cat.kmAdicional.toFixed(2).replace('.', ',')}/km)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* W-BANK Quick Access Card */}
          <div
            onClick={() => setShowWBankModal(true)}
            className="p-5 rounded-3xl bg-gradient-to-br from-[#122407] to-[#0a1204] border border-[#a3e635]/30 cursor-pointer hover:border-[#a3e635] transition-all shadow-xl group"
          >
            <div className="flex items-center justify-between mb-2">
              <WDriverLogo variant="wbank" size="sm" />
              <span className="text-xs text-[#a3e635] group-hover:translate-x-1 transition-transform">➔</span>
            </div>
            <p className="text-xs text-neutral-300 mb-3">
              Abra a carteira digital para consultar saldo de repasses e efetuar transferências PIX instantâneas.
            </p>
            <div className="flex items-center justify-between text-xs font-bold text-white bg-black/40 p-2.5 rounded-xl border border-white/5">
              <span>Repasses Concluídos:</span>
              <span className="text-[#a3e635] font-black">{completedRides.length} corridas</span>
            </div>
          </div>
        </div>
        </div>
      )}
      </main>

      {/* FOOTER OFICIAL W-DRIVER */}
      <footer className="mt-8 border-t border-neutral-800/80 bg-[#080b08] py-6 px-4 text-center text-xs text-neutral-400">
        <div className="max-w-4xl mx-auto space-y-2">
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-4 font-semibold text-neutral-300">
            <span className="text-[#a3e635]">W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB</span>
            <span className="hidden sm:inline text-neutral-600">•</span>
            <span>CNPJ: 55.348.639/0001-54</span>
          </div>
          <p className="text-[11px] text-neutral-500">
            Matriz: Rua José Severino Massa Spinelli, 836 - Bairro da Torre, João Pessoa - PB • CEP 58040-490
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-3 text-xs">
            <button
              onClick={() => setShowBioModal(true)}
              className="text-[#a3e635] hover:underline flex items-center gap-1 font-bold cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Ler Biografia Oficial de Wollace</span>
            </button>
            <span className="text-neutral-700">|</span>
            <a
              href="/standalone.html"
              target="_blank"
              rel="noreferrer"
              className="text-neutral-400 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <span>Abrir Modo Standalone (HTML Puro)</span>
              <ExternalLink className="w-3 h-3 text-neutral-500" />
            </a>
          </div>
          <p className="text-[10px] text-neutral-600 pt-2">
            Plataforma homologada com repasse garantido de 90% ao motorista, validação facial biométrica e Pix direto Banco Central.
          </p>
        </div>
      </footer>

      {/* W-BANK DRAWER MODAL */}
      {showWBankModal && (
        <WBankDrawer
          onClose={() => setShowWBankModal(false)}
          completedRides={completedRides}
        />
      )}

      {/* BIOGRAFIA OFICIAL MODAL */}
      <OfficialBioModal
        isOpen={showBioModal}
        onClose={() => setShowBioModal(false)}
      />
    </div>
  );
}
