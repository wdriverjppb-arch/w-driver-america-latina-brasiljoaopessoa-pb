// Utilitário de Geração de Pix Oficial - Banco Central do Brasil
// W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB
// CNPJ: 55.348.639/0001-54
// Favorecido: 55348339 Diego Wallace de Lima Vasconcelos

export const PIX_CONFIG = {
  cnpjFormatado: '55.348.639/0001-54',
  chavePix: '55348639000154', // Chave Pix CNPJ sem máscara
  favorecido: '55348339 Diego Wallace de Lima Vasconcelos',
  cidade: 'JOAO PESSOA',
  banco: 'Banco Central do Brasil - Conta W-DRIVER LTDA',
  enderecoMatriz: 'Rua José Severino Massa Spinelli, 836 - Bairro da Torre, João Pessoa - PB',
};

// Algoritmo CRC16-CCITT (0xFFFF, 0x1021) do Banco Central para BR Code
function crc16(str: string): string {
  let crc = 0xffff;
  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = ((crc << 1) ^ 0x1021) & 0xffff;
      } else {
        crc = (crc << 1) & 0xffff;
      }
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

function formatEmvField(id: string, value: string): string {
  const len = value.length.toString().padStart(2, '0');
  return `${id}${len}${value}`;
}

/**
 * Gera a string Pix Copia e Cola padrão BR Code do Banco Central
 * direcionando o pagamento diretamente para a conta da empresa
 */
export function generatePixCopiaECola(valor: number, txId: string = '***'): string {
  const valorFormatado = valor.toFixed(2);
  
  // Tag 26: Merchant Account Information (GUI + Chave)
  const gui = formatEmvField('00', 'br.gov.bcb.pix');
  const chave = formatEmvField('01', PIX_CONFIG.chavePix);
  const merchantAccount = formatEmvField('26', `${gui}${chave}`);

  // Tag 52: Merchant Category Code (0000)
  const mcc = formatEmvField('52', '0000');

  // Tag 53: Currency (986 = BRL)
  const currency = formatEmvField('53', '986');

  // Tag 54: Amount
  const amountField = formatEmvField('54', valorFormatado);

  // Tag 58: Country Code (BR)
  const country = formatEmvField('58', 'BR');

  // Tag 59: Merchant Name (Máximo 25 chars no padrão EMV)
  const merchantNameRaw = '55348339 DIEGO WALLACE D';
  const merchantName = formatEmvField('59', merchantNameRaw);

  // Tag 60: Merchant City
  const merchantCity = formatEmvField('60', PIX_CONFIG.cidade);

  // Tag 62: Additional Data Field (TxID)
  const txField = formatEmvField('05', txId);
  const additionalData = formatEmvField('62', txField);

  // Payload sem o CRC16
  const payloadBeforeCrc = `000201${merchantAccount}${mcc}${currency}${amountField}${country}${merchantName}${merchantCity}${additionalData}6304`;
  const checksum = crc16(payloadBeforeCrc);

  return `${payloadBeforeCrc}${checksum}`;
}

/**
 * URL do QR Code via serviço padrão de renderização
 */
export function getPixQrCodeUrl(copiaECola: string, size: number = 240): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=10&data=${encodeURIComponent(copiaECola)}`;
}
