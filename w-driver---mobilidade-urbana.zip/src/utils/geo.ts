// Utilitário de Geolocalização e Rotas Livres (OpenStreetMap / Leaflet)
// W-DRIVER AMÉRICA LATINA BRASIL JOÃO PESSOA-PB

export interface LatLng {
  lat: number;
  lng: number;
}

/**
 * Calcula a distância em KM entre duas coordenadas geográficas usando Haversine
 */
export function calculateHaversineDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Raio da Terra em KM
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const dist = R * c;
  // Fator de rota urbana real (curvas e avenidas geralmente adicionam ~20% em João Pessoa)
  return Math.max(1, Math.round(dist * 1.25 * 10) / 10);
}

/**
 * Gera URL oficial universal do Google Maps com Origem e Destino
 */
export function getUniversalGoogleMapsRouteUrl(origem: string, destino: string): string {
  return `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(
    origem
  )}&destination=${encodeURIComponent(destino)}&travelmode=driving`;
}

/**
 * Gera URL oficial do Waze com Destino
 */
export function getWazeRouteUrl(destino: string): string {
  return `https://waze.com/ul?q=${encodeURIComponent(destino)}&navigate=yes`;
}
